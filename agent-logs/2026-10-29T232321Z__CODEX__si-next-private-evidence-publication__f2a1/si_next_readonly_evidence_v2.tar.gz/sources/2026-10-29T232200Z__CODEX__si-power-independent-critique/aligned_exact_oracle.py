import json,math
from pathlib import Path
rows=json.loads(Path("/home/lizening/research-notes/agent-logs/2026-10-29T231518Z__CODEX__si-u1-power-feasibility__independent/power_sensitivity.json").read_text())["rows"]
def exact(n,delta,q):
  wp=(q+delta)/(2*q)
  total=0.0
  for m in range(n+1):
    pm=math.comb(n,m)*q**m*(1-q)**(n-m)
    cum=0
    tails=[]
    for k in range(m//2+1):
      cum+=math.comb(m,k)
      tails.append(min(1.0,(2*cum)/(2**m)))
    for wins in range(m+1):
      if 10*(2*wins-m)<n or tails[min(wins,m-wins)]>0.025:
        continue
      total+=pm*math.comb(m,wins)*wp**wins*(1-wp)**(m-wins)
  return total
for row in rows:
 if row["conditional_dependence"]=="aligned" and row["n"] in (82,164,328):
  e=exact(row["n"],row["true_delta_each"],row["discordance_each"])
  mc=row["estimates"]["both_holm_and_observed_10pp"]
  print(json.dumps({"N":row["n"],"delta":row["true_delta_each"],"q":row["discordance_each"],"exact":e,"MC":mc,"MC95_halfwidth":row["joint_mc_95_normal_halfwidth"],"absolute_difference":abs(mc-e),"z_difference":abs(mc-e)/(row["joint_mc_95_normal_halfwidth"]/1.96)}))
