"""One independent, budgeted pair using the historical DEV episode ports.

No CLI or resource access occurs on import. The caller must provide an external
budget owner and verified legacy components, P0 loader and exact case inputs.
"""

from pathlib import Path

from .paired_pilot import run_pair


PAIR_CAPS = {
    "materialize": 1, "env_construct": 2, "env_init": 2, "reset": 2,
    "model_load": 2, "generation": 100, "step": 100,
}


def run_stage(
    *, output, budget_fd, case, inputs, seed, journal_class, owner_class,
    controller_class, materialize, verify_materialized, environment_class,
    step_wrapper, episode, projection, source_worker, load_p0, parser,
    parse_value, state_factory, expected_eos, expected_pad,
):
    """Execute a pair only when called by a configured external supervisor.

    EffectOwner reserves each operation with the independently running budget
    owner before calling it. The caller owns deadlines, device admission,
    source and input identity, process cleanup, and prior-pair ordering.
    """
    if set(inputs) != {"game", "routing", "config"}:
        raise ValueError("exact three input identities required")
    if {key: value["sha256"] for key, value in inputs.items()} != case["input_sha256"]:
        raise ValueError("case input hash mismatch")
    if seed != 42 or tuple(case["order"]) not in (
        ("original", "clarified"), ("clarified", "original")
    ):
        raise ValueError("seed or arm order mismatch")
    output = Path(output)
    journal = journal_class(output / "worker_events.jsonl", 64 * 1024 * 1024)
    owner = owner_class(budget_fd, journal, PAIR_CAPS)
    controller = controller_class(owner)
    materialized = None
    post_verified = False
    finished = False
    try:
        journal.emit("pilot_pair_started", {
            "case": case["case"], "order": case["order"], "seed": seed,
            "scope": "EXPOSED_AUTHORED_DEV", "horizon": 50,
        })
        game, config, data_root = controller.effect(
            "materialize",
            lambda: materialize(output, inputs, journal.emit, family="two"),
            lambda values: {"game": str(values[0]), "config": str(values[1]),
                            "data_root": str(values[2])},
        )
        materialized = (game, config, data_root)
        verify_materialized(game, config, data_root, inputs, journal.emit, "pre")

        class GoalBoundEnvironment:
            def __init__(self):
                self.inner = step_wrapper(environment_class(
                    game, config, data_root, seed, family="two", case_id=case["case"]
                ))

            def initialize(self):
                return self.inner.initialize()

            def reset(self):
                result = self.inner.reset()
                if (type(result) is not tuple or len(result) != 3
                        or getattr(result[0], "goal", None) != case["public_goal"]
                        or getattr(result[0], "family", None) != "pick_two_obj_and_place"):
                    raise ValueError("runtime public goal or family mismatch")
                return result

            def step(self, action):
                return self.inner.step(action)

            def close(self):
                return self.inner.close()

        def env_factory():
            return GoalBoundEnvironment()

        pair = run_pair(
            episode=episode, projection=projection, expected_goal=case["public_goal"],
            arm_order=tuple(case["order"]), load_p0=load_p0,
            controller=controller, env_factory=env_factory,
            source_worker=source_worker, parser=parser, parse_value=parse_value,
            state_factory=state_factory, expected_game=str(game),
            expected_eos=expected_eos, expected_pad=expected_pad,
        )
        verify_materialized(game, config, data_root, inputs, journal.emit, "post")
        post_verified = True
        journal.emit("pilot_pair_result", pair)
        owner.finish("COMPLETED")
        finished = True
        return pair
    except BaseException as error:
        if materialized is not None and not post_verified:
            try:
                verify_materialized(*materialized, inputs, journal.emit, "post")
            except BaseException as verification_error:
                try:
                    journal.emit("input_post_verification_failed", {
                        "type": type(verification_error).__name__
                    })
                except BaseException:
                    pass
        try:
            journal.emit("pilot_pair_stopped", {
                "type": type(error).__name__, "effects": "UNKNOWN_AS_NEEDED"
            })
        except BaseException:
            pass
        if not finished:
            try:
                owner.finish("STOPPED")
            except BaseException:
                pass
        raise
    finally:
        try:
            owner.close()
        finally:
            journal.close()
