"""Connect two actual episode calls while preserving their own trajectories.

The caller supplies the existing episode implementation and its controller,
environment and producer ports. This function neither configures nor starts a
model or environment on its own; budgets and inputs must be bound by a caller.
"""

from typing import Any, Callable


def run_pair(*, episode: Callable[..., dict[str, Any]],
             arm_order: tuple[str, str], controller: Any,
             env_factory: Callable[..., Any], load_producer: Callable[..., Any],
             source_worker: Any, projection: Callable[..., Any],
             parser: Callable[..., Any], parse_value: Callable[..., Any],
             state_factory: Callable[..., Any], expected_game: str,
             expected_eos: Any, expected_pad: Any) -> dict[str, Any]:
    """Run the two declared episodes, using the original episode interface.

    The second episode receives only the first public initial state for the
    existing observable reset check. Each episode creates its own environment
    and maintains its own history. A technical exception propagates immediately;
    it is never converted to a scientific failure or automatically retried.
    """
    if arm_order not in (("P0", "CANDIDATE"), ("CANDIDATE", "P0")):
        raise ValueError("one P0 and one CANDIDATE in declared order required")
    if not isinstance(expected_game, str) or not expected_game:
        raise ValueError("expected native game required")
    shared = dict(controller=controller, env_factory=env_factory,
                  load_producer=load_producer, source_worker=source_worker,
                  projection=projection, parser=parser, parse_value=parse_value,
                  state_factory=state_factory, expected_game=expected_game,
                  expected_eos=expected_eos, expected_pad=expected_pad)
    results = {}
    initial = None
    for arm in arm_order:
        result = episode(arm=arm, previous_initial=initial, **shared)
        if not isinstance(result, dict) or result.get("arm") != arm:
            raise ValueError("episode returned wrong arm")
        if not isinstance(result.get("initial_public"), dict):
            raise ValueError("missing observable initial state")
        # Persist a completed arm before starting the next one. A journal error
        # stops the batch; it must not be treated as a completed pair.
        controller.journal.emit("fixed_product_episode_returned", result)
        results[arm] = result
        initial = result["initial_public"]
    return {"arm_order": list(arm_order), "P0": results["P0"],
            "CANDIDATE": results["CANDIDATE"],
            "hidden_state_equivalence": "UNKNOWN"}
