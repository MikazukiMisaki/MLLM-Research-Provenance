"""Composition port for a future two-arm DEV episode runner; no executable CLI.

The caller must supply a separately configured episode function, actual P0
loader, environment, authenticated controller, input bindings, and budget. No
such machinery is provided or invoked by importing this module.
"""

from typing import Any, Callable

from .goal_projection import FAMILY, goal_projection


def run_pair(
    *, episode: Callable[..., dict[str, Any]], projection: Callable[..., Any],
    expected_goal: str, arm_order: tuple[str, str], load_p0: Callable[[], Any],
    controller: Any, env_factory: Callable[..., Any], source_worker: Any,
    parser: Callable[..., Any], parse_value: Callable[..., Any],
    state_factory: Callable[..., Any], expected_game: str,
    expected_eos: Any, expected_pad: Any,
) -> dict[str, Any]:
    """Run each full episode once, provided an independently bounded caller.

    The existing episode contract records each operation and compares the second
    observable initial state with the first. It does not prove equality of
    hidden state. The caller must establish that the fixed clarification is
    true for the *specific* public task and bind exact resources before calling.
    """
    if arm_order not in (("original", "clarified"), ("clarified", "original")):
        raise ValueError("one original and one clarified arm required")
    if not isinstance(expected_goal, str) or not expected_goal.strip():
        raise ValueError("expected public goal must be bound")

    def projection_for(arm: str) -> Callable[..., Any]:
        projected = goal_projection(projection, clarify=arm == "clarified")

        def checked_projection(state: Any, history: Any) -> Any:
            if getattr(state, "family", None) != FAMILY:
                raise ValueError("unexpected task family")
            if getattr(state, "goal", None) != expected_goal:
                raise ValueError("public goal changed or does not match binding")
            return projected(state, history)

        return checked_projection

    def same_product(arm: str) -> Any:
        if arm not in arm_order:
            raise ValueError("unexpected arm")
        return load_p0()

    shared = dict(
        controller=controller, env_factory=env_factory,
        load_producer=same_product, source_worker=source_worker, parser=parser,
        parse_value=parse_value, state_factory=state_factory,
        expected_game=expected_game, expected_eos=expected_eos,
        expected_pad=expected_pad,
    )
    results: dict[str, Any] = {}
    previous_initial = None
    for arm in arm_order:
        result = episode(
            arm=arm, previous_initial=previous_initial,
            projection=projection_for(arm),
            **shared,
        )
        results[arm] = result
        previous_initial = result["initial_public"]
    return {
        "status": "DEV_PAIR_REQUIRES_INDEPENDENT_REVIEW",
        "arm_order": list(arm_order),
        "original": results["original"],
        "clarified": results["clarified"],
        "hidden_state_equivalence": "UNKNOWN",
    }
