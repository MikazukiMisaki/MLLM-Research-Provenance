"""Bounded serial supervisor for four authored DEV pairs.

Requires a separately prepared private batch config; importing does nothing.
The advisory device lock only coordinates processes that honor the same lock.
"""

import argparse
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import socket
import subprocess
import sys
import time


PAIR_SECONDS = 1800
BATCH_SECONDS = 7200
OUTPUT_LIMIT = 1024 * 1024
FREE_BEFORE_LOAD_MIB = 28 * 1024
FREE_RUNNING_MIB = 2048
MAX_GPU_UTIL_BEFORE_LOAD = 5
_STOP_SIGNAL = None


def request_stop(signum, _frame):
    global _STOP_SIGNAL
    _STOP_SIGNAL = signal.Signals(signum).name


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode()


def write_new(path, data):
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW,
                 0o600)
    try:
        view = memoryview(data)
        while view:
            n = os.write(fd, view)
            if n <= 0:
                raise OSError("short write")
            view = view[n:]
        os.fsync(fd)
    finally:
        os.close(fd)


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def gpu_sample(uuid):
    output = subprocess.check_output([
        "nvidia-smi", "--query-gpu=uuid,memory.free,utilization.gpu",
        "--format=csv,noheader,nounits"], text=True, timeout=5)
    rows = [tuple(x.strip() for x in line.split(",")) for line in output.splitlines()]
    rows = [row for row in rows if len(row) == 3 and row[0] == uuid]
    if len(rows) != 1:
        raise RuntimeError("GPU identity unavailable")
    return {"uuid": rows[0][0], "free_mib": int(rows[0][1]),
            "utilization": int(rows[0][2])}


def gpu_pids():
    output = subprocess.check_output([
        "nvidia-smi", "--query-compute-apps=pid",
        "--format=csv,noheader,nounits"], text=True, timeout=5)
    lines = [line.strip() for line in output.splitlines() if line.strip()]
    if any(not line.isdigit() for line in lines):
        raise RuntimeError("GPU process list unavailable")
    return {int(line) for line in lines}


def verified_worker_gpu_pids(worker_pid, reported):
    """A fresh one-arm worker is allowed one load before any CUDA context.

    No numerical cross-namespace PID inference is made. Any reported GPU PID
    blocks admission; it is not killed, attributed, or silently ignored.
    """
    return set()


def enable_subreaper():
    """Adopt orphaned descendants, including those that create new sessions."""
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), "cannot enable child subreaper")
    value = ctypes.c_int()
    if libc.prctl(37, ctypes.byref(value), 0, 0, 0) != 0 or value.value != 1:
        raise RuntimeError("child subreaper not confirmed")


def no_direct_children():
    """Reap already-exited adopted children and detect any still alive."""
    reaped = []
    while True:
        try:
            pid, status = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            return {"no_remaining_children": True, "reaped": reaped}
        if pid == 0:
            return {"no_remaining_children": False, "reaped": reaped}
        reaped.append({"pid": pid, "status": status})


def stop_adopted_children():
    """Stop direct adopted children only after parent, UID and start checks."""
    signals = []
    children_path = Path("/proc/self/task") / str(os.getpid()) / "children"
    for sig in (signal.SIGTERM, signal.SIGKILL):
        end = time.monotonic() + 2
        while time.monotonic() < end:
            state = no_direct_children()
            if state["no_remaining_children"]:
                return {"no_remaining_children": True, "signals": signals}
            try:
                pids = [int(x) for x in children_path.read_text().split()]
            except (OSError, ValueError):
                return {"no_remaining_children": False, "signals": signals}
            for pid in pids:
                try:
                    proc = Path("/proc") / str(pid)
                    raw = (proc / "stat").read_text()
                    fields = raw[raw.rfind(")") + 2:].split()
                    parent, start = int(fields[1]), int(fields[19])
                    if parent != os.getpid() or proc.stat().st_uid != os.getuid():
                        continue
                    again = (proc / "stat").read_text()
                    second = again[again.rfind(")") + 2:].split()
                    if int(second[1]) == parent and int(second[19]) == start:
                        os.kill(pid, sig)
                        signals.append({"pid": pid, "start_tick": start, "signal": sig.name})
                except (OSError, ValueError, IndexError):
                    continue
            time.sleep(0.05)
    return {"no_remaining_children": no_direct_children()["no_remaining_children"],
            "signals": signals}


def stop_child(child):
    if child.poll() is not None:
        return child.wait()
    # Only signal the session created directly for this child.
    try:
        if os.getpgid(child.pid) == child.pid and os.getsid(child.pid) == child.pid:
            os.killpg(child.pid, signal.SIGTERM)
        else:
            child.terminate()
        return child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        if os.getpgid(child.pid) == child.pid and os.getsid(child.pid) == child.pid:
            os.killpg(child.pid, signal.SIGKILL)
        else:
            child.kill()
        return child.wait(timeout=5)
    except ProcessLookupError:
        return child.wait(timeout=5)


def run_pair(*, config, config_path, output, worker, interpreter, gpu_uuid,
             budget_class, journal_class, batch_deadline):
    owner_log = journal_class(output / "supervisor_events.jsonl")
    config_bytes = canonical(config) + b"\n"
    write_new(config_path, config_bytes)
    config_sha = hashlib.sha256(config_bytes).hexdigest()
    parent, child_socket = socket.socketpair()
    child = None
    selector = selectors.DefaultSelector()
    streams = {}
    stream_counts = {}
    budget = budget_class("EVAL", parent, owner_log)
    reason = "UNKNOWN"
    start = time.monotonic()
    deadline = min(start + PAIR_SECONDS, batch_deadline)
    try:
        enable_subreaper()
        if not no_direct_children()["no_remaining_children"]:
            raise RuntimeError("preexisting child prevents descendant attribution")
        owner_log.emit("subreaper_enabled", {"scope": "worker_descendants"})
        if _STOP_SIGNAL:
            raise RuntimeError("stop requested: " + _STOP_SIGNAL)
        current = gpu_sample(gpu_uuid)
        if (current["free_mib"] < FREE_BEFORE_LOAD_MIB
                or current["utilization"] > MAX_GPU_UTIL_BEFORE_LOAD
                or gpu_pids()):
            raise RuntimeError("GPU admission unavailable")
        owner_log.emit("gpu_admission", current)
        if _STOP_SIGNAL:
            raise RuntimeError("stop requested: " + _STOP_SIGNAL)
        child = subprocess.Popen(
            [interpreter, "-I", "-B", str(worker), "--config", str(config_path),
             "--config-sha256", config_sha, "--budget-fd", str(child_socket.fileno())],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            pass_fds=(child_socket.fileno(),), start_new_session=True,
        )
        child_socket.close()
        parent.setblocking(False)
        selector.register(parent, selectors.EVENT_READ, "budget")
        for name, stream in (("stdout", child.stdout), ("stderr", child.stderr)):
            os.set_blocking(stream.fileno(), False)
            fd = os.open(output / ("worker." + name),
                         os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            streams[stream] = fd
            stream_counts[stream] = 0
            selector.register(stream, selectors.EVENT_READ, name)
        next_gpu = time.monotonic()
        exited_at = None
        while True:
            now = time.monotonic()
            if _STOP_SIGNAL:
                reason = "signal_" + _STOP_SIGNAL
                break
            if now >= deadline:
                reason = "deadline"
                break
            if budget.ack_deadline is not None and now >= budget.ack_deadline:
                reason = "budget_ack_timeout"
                break
            if now >= next_gpu:
                sample = gpu_sample(gpu_uuid)
                owner_log.emit("gpu_sample", sample)
                if sample["free_mib"] < FREE_RUNNING_MIB:
                    reason = "gpu_low_memory"
                    break
                if shutil.disk_usage(output).free < 2 * 1024**3:
                    reason = "disk_free_floor"
                    break
                next_gpu = now + 5
                if _STOP_SIGNAL or time.monotonic() >= deadline:
                    reason = "signal_" + _STOP_SIGNAL if _STOP_SIGNAL else "deadline"
                    break
            for key, _ in selector.select(0.25):
                stream = key.fileobj
                if key.data == "budget":
                    chunk = parent.recv(4096)
                    if not chunk:
                        selector.unregister(parent)
                        budget.eof()
                        continue
                    request = budget.buffer + chunk
                    if request.endswith(b"\n") and request.count(b"\n") == 1:
                        frame = json.loads(request)
                        if isinstance(frame, dict) and frame.get("kind") == "reserve" and frame.get("operation") == "model_load":
                            sample = gpu_sample(gpu_uuid)
                            reported = gpu_pids()
                            owned = verified_worker_gpu_pids(child.pid, reported)
                            others = reported - owned
                            owner_log.emit("model_load_admission", dict(sample, other_gpu_pids=len(others)))
                            if (sample["free_mib"] < FREE_BEFORE_LOAD_MIB
                                    or sample["utilization"] > MAX_GPU_UTIL_BEFORE_LOAD or others):
                                raise RuntimeError("GPU unavailable before model load")
                            if _STOP_SIGNAL or time.monotonic() >= deadline:
                                raise RuntimeError("stop or deadline before model-load admission")
                    budget.receive(chunk)
                    if budget.pending_ack:
                        if _STOP_SIGNAL or time.monotonic() >= deadline:
                            raise RuntimeError("stop or deadline before budget ACK")
                        budget.write_ack()
                else:
                    block = os.read(stream.fileno(), 65536)
                    if not block:
                        selector.unregister(stream)
                        continue
                    stream_counts[stream] += len(block)
                    if stream_counts[stream] > OUTPUT_LIMIT:
                        raise RuntimeError("worker output cap")
                    view = memoryview(block)
                    while view:
                        view = view[os.write(streams[stream], view):]
            if budget.pending_ack:
                if _STOP_SIGNAL or time.monotonic() >= deadline:
                    raise RuntimeError("stop or deadline before budget ACK")
                budget.write_ack()
            if child.poll() is not None and len(selector.get_map()) == 0:
                reason = "completed" if child.returncode == 0 and budget.finished == "COMPLETED" and not budget.unknown else "worker_stopped"
                break
            if child.poll() is not None:
                exited_at = exited_at or time.monotonic()
                if time.monotonic() - exited_at > 5:
                    reason = "worker_exited_with_open_pipes"
                    break
        rc = stop_child(child)
        descendants = no_direct_children()
        if not descendants["no_remaining_children"]:
            cleanup = stop_adopted_children()
            owner_log.emit("adopted_descendant_cleanup", cleanup)
            reason = "worker_left_descendants"
            descendants = no_direct_children()
        owner_log.emit("pair_stopped", {"reason": reason, "returncode": rc,
                                       "counts": budget.counts,
                                       "elapsed_seconds": time.monotonic() - start,
                                       "subreaper_children": descendants,
                                       "external_process_delegation": "UNKNOWN"})
        if reason != "completed":
            raise RuntimeError("pair did not complete: " + reason)
        return dict(budget.counts)
    except BaseException as error:
        try:
            owner_log.emit("supervisor_exception", {"type": type(error).__name__,
                                                   "message": str(error),
                                                   "effects": "UNKNOWN_AS_NEEDED"})
        except BaseException:
            pass
        raise
    finally:
        cleanup_unknown = False
        if child is not None and child.poll() is None:
            stop_child(child)
        if child is not None:
            try:
                cleanup = stop_adopted_children()
                owner_log.emit("final_descendant_cleanup", cleanup)
                cleanup_unknown = not cleanup["no_remaining_children"]
            except BaseException as error:
                cleanup_unknown = True
                try:
                    owner_log.emit("final_descendant_cleanup_unknown", {
                        "type": type(error).__name__
                    })
                except BaseException:
                    pass
        for stream, fd in streams.items():
            try:
                stream.close()
            finally:
                os.close(fd)
        selector.close()
        parent.close()
        child_socket.close()
        owner_log.close()
        if cleanup_unknown:
            raise RuntimeError("descendant cleanup not confirmed")


def read_arm_outcome(worker_output, expected_arm):
    """Read exactly one persisted completed arm after its owner has closed."""
    path = worker_output / "worker_events.jsonl"
    if not path.is_file() or path.stat().st_size > 64 * 1024 * 1024:
        raise RuntimeError("arm journal missing or too large")
    outcomes = []
    with path.open("r", encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            if row.get("kind") == "fixed_product_arm_result":
                outcomes.append(row.get("payload"))
    if len(outcomes) != 1 or not isinstance(outcomes[0], dict):
        raise RuntimeError("arm result missing or ambiguous")
    result = outcomes[0]
    if (result.get("arm") != expected_arm or type(result.get("won")) is not bool
            or not isinstance(result.get("initial_public"), dict)
            or type(result.get("steps")) is not int or not 0 <= result["steps"] <= 50):
        raise RuntimeError("arm result invalid")
    return result


def check_paired_initial(previous_initial, result):
    if previous_initial is not None and canonical(result["initial_public"]) != canonical(previous_initial):
        raise RuntimeError("public initial state differs between arms")


def main():
    for sig in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT):
        signal.signal(sig, request_stop)
    ap = argparse.ArgumentParser()
    ap.add_argument("--batch-config", required=True)
    ap.add_argument("--batch-config-sha256", required=True)
    args = ap.parse_args()
    config_path = Path(args.batch_config)
    if digest(config_path) != args.batch_config_sha256:
        raise ValueError("batch config digest")
    config = json.loads(config_path.read_bytes())
    manifest_path = Path(config["manifest_path"])
    if digest(manifest_path) != config["manifest_sha256"]:
        raise ValueError("manifest digest")
    manifest = json.loads(manifest_path.read_bytes())
    if manifest["schema"] != "FIXED_PRODUCT_FOUR_PAIR_DEV_V1":
        raise ValueError("manifest schema")
    if len(manifest["cases"]) != 4 or len(config["cases"]) != 4:
        raise ValueError("fixed four cases required")
    if [x["case"] for x in manifest["cases"]] != [x["case"] for x in config["cases"]]:
        raise ValueError("fixed case order required")
    if manifest["limits"] != config["limits"]:
        raise ValueError("fixed batch limits required")
    if config["worker_common"]["runtime"]["gpu_uuid"] != config["gpu_uuid"]:
        raise ValueError("device binding mismatch")
    if config["worker_common"]["legacy_dir"] != config["legacy_dir"]:
        raise ValueError("legacy code root mismatch")
    source = Path(config["worker_common"]["source_root"])
    actual_revision = subprocess.check_output(
        ["git", "-C", str(source), "rev-parse", "HEAD"], text=True, timeout=10).strip()
    if actual_revision != manifest["source_revision"]:
        raise ValueError("source revision mismatch")
    dirty = subprocess.check_output(
        ["git", "-C", str(source), "status", "--porcelain", "--untracked-files=all", "--", "src"],
        text=True, timeout=20)
    if dirty:
        raise ValueError("runtime source is not clean")
    bound = {str(Path(x["path"]).resolve()): x["sha256"]
             for x in config["worker_common"]["code_files"]}
    legacy_files = {str(path.resolve()) for path in Path(config["legacy_dir"]).glob("*.py")}
    own_files = {str(path.resolve()) for path in Path(__file__).resolve().parent.glob("*.py")}
    if not legacy_files or not (legacy_files | own_files) <= set(bound):
        raise ValueError("incomplete code identity list")
    if any(digest(path) != expected for path, expected in bound.items()):
        raise ValueError("code identity mismatch")
    root = Path(config["output_root"])
    if not root.is_absolute() or root.exists():
        raise ValueError("fresh absolute output root required")
    device_lock = os.open(config["device_lock"], os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(device_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        root.mkdir(mode=0o700)
        legacy = Path(config["legacy_dir"])
        sys.path.insert(0, str(legacy))
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from fixed_product_dev.arm_budget import StageBudgetChannel
        from owner import Journal
        started = time.monotonic()
        counts = []
        pair_results = []
        for index, row in enumerate(config["cases"]):
            if _STOP_SIGNAL:
                raise RuntimeError("stop requested: " + _STOP_SIGNAL)
            expected_order = (["P0", "CANDIDATE"] if index % 2 == 0
                              else ["CANDIDATE", "P0"])
            if manifest["cases"][index]["order"] != expected_order:
                raise ValueError("arm order mismatch")
            pair_root = root / row["case"]
            pair_root.mkdir(mode=0o700)
            pair_deadline = min(time.monotonic() + PAIR_SECONDS, started + BATCH_SECONDS)
            previous_initial = None
            pair_outcomes = {}
            for arm_index, arm in enumerate(expected_order):
                arm_root = pair_root / (str(arm_index + 1) + "-" + arm)
                arm_root.mkdir(mode=0o700)
                owner_output, worker_output = arm_root / "owner", arm_root / "worker"
                owner_output.mkdir(mode=0o700)
                worker_output.mkdir(mode=0o700)
                worker_config = dict(config["worker_common"], case=row["case"], arm=arm,
                                     previous_initial=previous_initial,
                                     inputs=row["inputs"], output=str(worker_output),
                                     manifest_path=str(manifest_path),
                                     manifest_sha256=config["manifest_sha256"],
                                     limits=config["limits"])
                counts.append(run_pair(
                    config=worker_config, config_path=arm_root / "worker_config.json",
                    output=owner_output, worker=Path(config["worker_path"]),
                    interpreter=config["interpreter"], gpu_uuid=config["gpu_uuid"],
                    budget_class=StageBudgetChannel, journal_class=Journal,
                    batch_deadline=pair_deadline,
                ))
                result = read_arm_outcome(worker_output, arm)
                check_paired_initial(previous_initial, result)
                pair_outcomes[arm] = result
                previous_initial = result["initial_public"]
            pair_results.append({"case": row["case"], "order": expected_order,
                                 "P0_won": pair_outcomes["P0"]["won"],
                                 "candidate_won": pair_outcomes["CANDIDATE"]["won"],
                                 "hidden_state_equivalence": "UNKNOWN"})
        total = {key: sum(row[key] for row in counts) for key in counts[0]}
        for key in ("materialize", "env_construct", "env_init", "model_load", "reset", "generation", "step"):
            if total[key] > manifest["limits"][key]:
                raise RuntimeError("batch budget exceeded: " + key)
        write_new(root / "batch_result.json", canonical({
            "status": "COMPLETED_REQUIRES_EVIDENCE_REVIEW", "counts": counts, "total": total,
            "pairs": pair_results, "elapsed_seconds": time.monotonic() - started,
        }) + b"\n")
    finally:
        os.close(device_lock)


if __name__ == "__main__":
    main()
