"""Bounded, identity-scoped cleanup helpers; no GPU or scientific imports."""
import ctypes,os,platform,signal,subprocess,time
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class Identity:
    pid:int
    start_tick:int
    uid:int
    pgid:int
    sid:int
    ppid:int

def read_identity(pid):
    p=Path('/proc')/str(pid)
    try:
        f=(p/'stat').read_text().rsplit(')',1)[1].split()
        uid=int(next(x for x in (p/'status').read_text().splitlines() if x.startswith('Uid:')).split()[1])
        return Identity(pid,int(f[19]),uid,int(f[2]),int(f[3]),int(f[1])),f[0]
    except FileNotFoundError:return None,'gone'
    except (OSError,ValueError,IndexError,StopIteration):return None,'unknown'

def state(identity):
    now,status=read_identity(identity.pid)
    if now is None:return status
    if (now.start_tick,now.uid,now.pgid,now.sid)!=(identity.start_tick,identity.uid,identity.pgid,identity.sid):return 'mismatch'
    return 'zombie' if status=='Z' else 'alive'

def establish_supervisor(pid, expected_uid, expected_ppid):
    """Return an anchor only after complete direct-child and session proof."""
    candidate, status=read_identity(pid)
    if candidate is None or status in ('gone','unknown','Z') or candidate.uid!=expected_uid or candidate.pgid!=pid or candidate.sid!=pid or candidate.ppid!=expected_ppid:
        return None
    return candidate

def completed_status(returncode, error, timeout, cleanup, receipt, auth_sha, within_deadline):
    native_success=bool(type(receipt) is dict and receipt.get('execution_status')=='EXIT_RECORDED' and type(receipt.get('authentic_returncode')) is int and receipt.get('authentic_returncode')==0 and receipt.get('cleanup_established') is True and receipt.get('within_time_cap') is True and receipt.get('retry_authorized') is False and receipt.get('authorization_sha256')==auth_sha)
    completed=type(returncode) is int and returncode==0 and error is None and not timeout and cleanup is None and native_success and within_deadline
    return completed,native_success

def snapshot_descendants(anchors,known):
    """Prove ownership through current PID/start-tick/UID authenticated parent chains."""
    table={}
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            identity,status=read_identity(int(p.name))
            if identity is not None:table[identity.pid]=identity
    verified={i.pid:i for i in list(anchors)+list(known.values()) if state(i)=='alive'}
    changed=True
    while changed:
        changed=False
        for pid,i in table.items():
            if pid not in verified and i.ppid in verified and i.uid==verified[i.ppid].uid:
                verified[pid]=i;known[pid]=i;changed=True
    return known

def pidfd_open(pid):
    if hasattr(os,'pidfd_open'):return os.pidfd_open(pid,0)
    if platform.system()!='Linux' or platform.machine()!='x86_64':raise OSError('pidfd_open unavailable on this architecture')
    libc=ctypes.CDLL(None,use_errno=True);fd=libc.syscall(434,pid,0)
    if fd<0:raise OSError(ctypes.get_errno(),'pidfd_open failed')
    return fd

def signal_scoped(identity,sig,events,signaler=signal.pidfd_send_signal):
    """Pin kernel PID identity before checking /proc, avoiding reuse races."""
    before=state(identity)
    if before!='alive':
        events.append({'pid':identity.pid,'start_tick':identity.start_tick,'signal':sig,'state_before':before,'sent':False});return False
    try:
        fd=pidfd_open(identity.pid)
    except OSError as exc:
        events.append({'pid':identity.pid,'start_tick':identity.start_tick,'signal':sig,'state_before':'pidfd_unavailable_or_gone','error':type(exc).__name__,'sent':False});return False
    try:
        before=state(identity)
        if before!='alive':
            events.append({'pid':identity.pid,'start_tick':identity.start_tick,'signal':sig,'state_before':before,'sent':False});return False
        signaler(fd,sig);events.append({'pid':identity.pid,'start_tick':identity.start_tick,'signal':sig,'state_before':before,'sent':True,'pidfd_pinned':True});return True
    except ProcessLookupError:events.append({'pid':identity.pid,'start_tick':identity.start_tick,'signal':sig,'state_before':'disappeared_before_signal','sent':False});return False
    except (PermissionError,OSError) as exc:events.append({'pid':identity.pid,'start_tick':identity.start_tick,'signal':sig,'state_before':'signal_error','error':type(exc).__name__,'sent':False});return False
    finally:os.close(fd)

def bounded_cleanup(supervisor,known,hard_deadline,soft_grace=3.0,term_grace=2.0,poll_interval=.05):
    """Never signal by name/group; only identities previously proved by parent chain.

    Returns explicit unknown/inconclusive states. Deadlines bound sleep and polling;
    OS filesystem calls and signals are not hard real-time guarantees.
    """
    events=[];unknown=False
    try:snapshot_descendants([supervisor],known)
    except OSError:unknown=True
    if time.monotonic()<hard_deadline:signal_scoped(supervisor,signal.SIGINT,events)
    soft_until=min(hard_deadline,time.monotonic()+max(0,soft_grace))
    while time.monotonic()<soft_until:
        try:snapshot_descendants([supervisor],known)
        except OSError:unknown=True
        if all(state(i) in ('gone','zombie') for i in [supervisor,*known.values()]):break
        time.sleep(min(poll_interval,max(0,soft_until-time.monotonic())))
    try:snapshot_descendants([supervisor],known)
    except OSError:unknown=True
    for i in sorted(known.values(),key=lambda x:x.start_tick,reverse=True)+[supervisor]:
        if time.monotonic()>=hard_deadline:unknown=True;break
        signal_scoped(i,signal.SIGTERM,events)
    term_until=min(hard_deadline,time.monotonic()+max(0,term_grace))
    while time.monotonic()<term_until:
        try:snapshot_descendants([supervisor],known)
        except OSError:unknown=True
        if all(state(i) in ('gone','zombie') for i in [supervisor,*known.values()]):break
        time.sleep(min(poll_interval,max(0,term_until-time.monotonic())))
    try:snapshot_descendants([supervisor],known)
    except OSError:unknown=True
    for i in sorted(known.values(),key=lambda x:x.start_tick,reverse=True)+[supervisor]:
        if time.monotonic()>=hard_deadline:unknown=True;break
        signal_scoped(i,signal.SIGKILL,events)
    while time.monotonic()<hard_deadline:
        statuses={str(i.pid):state(i) for i in [supervisor,*known.values()]}
        if all(s in ('gone','zombie') for s in statuses.values()):break
        time.sleep(min(poll_interval,max(0,hard_deadline-time.monotonic())))
    statuses={str(i.pid):state(i) for i in [supervisor,*known.values()]}
    confirmed=not unknown and all(s in ('gone','zombie') for s in statuses.values())
    return {'cleanup_confirmed':confirmed,'unknown_or_unresolved':not confirmed,'states':statuses,'signals':events,'known_identities':[vars(x) for x in known.values()]}

def supervise_bounded(process,supervisor,output,hard_deadline,cleanup_start,poll_interval=.5,soft_grace=3,term_grace=2):
    """Actual wrapper control loop. Never launches or accesses science outcomes."""
    rc=None;error=None;cleanup=None;known={};timed_out=False
    try:
        while time.monotonic()<cleanup_start:
            snapshot_descendants([supervisor],known)
            rc=process.poll()
            if rc is not None:break
            time.sleep(min(poll_interval,max(0,cleanup_start-time.monotonic())))
        if rc is None:
            timed_out=True;cleanup=bounded_cleanup(supervisor,known,hard_deadline,soft_grace=soft_grace,term_grace=term_grace)
            rc=process.poll()
        elif any(state(i)=='alive' for i in known.values()):
            cleanup=bounded_cleanup(supervisor,known,hard_deadline,soft_grace=0,term_grace=term_grace)
    except BaseException as exc:
        error={'type':type(exc).__name__,'message':str(exc)}
        if time.monotonic()<hard_deadline:
            cleanup=bounded_cleanup(supervisor,known,hard_deadline,soft_grace=soft_grace,term_grace=term_grace)
        rc=process.poll()
    if rc is None and time.monotonic()<hard_deadline:
        try:rc=process.wait(timeout=max(0,hard_deadline-time.monotonic()))
        except subprocess.TimeoutExpired:rc=None
    if cleanup is not None:
        import json
        worker_record=Path(output)/'worker_start.json'
        if worker_record.is_file():
            try:
                w=json.loads(worker_record.read_text());observed=known.get(w['pid'])
                if observed is None or observed.start_tick!=w['start_tick'] or observed.uid!=w['uid'] or observed.pgid!=w['pgid'] or observed.sid!=w['sid']:
                    cleanup['cleanup_confirmed']=False;cleanup['unknown_or_unresolved']=True;cleanup['unproven_worker_identity']=True
            except (OSError,ValueError,KeyError,TypeError):cleanup['cleanup_confirmed']=False;cleanup['unknown_or_unresolved']=True;cleanup['unproven_worker_identity']=True
        cleanup['scope']='Previously observed same-UID parent-proven identities only; unobserved descendants cannot be excluded.'
    return {'returncode':rc,'error':error,'timed_out':timed_out,'cleanup':cleanup,'known':known}
