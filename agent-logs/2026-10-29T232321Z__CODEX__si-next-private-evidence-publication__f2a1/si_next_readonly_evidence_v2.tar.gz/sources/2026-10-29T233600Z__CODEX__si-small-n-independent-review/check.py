import math,json,hashlib
from pathlib import Path
src=Path('/home/lizening/research-notes/agent-logs/2026-10-29T232019Z__CODEX__si-u1-small-n-power__independent')
out=Path(__file__).parent
raw=(src/'small_n_power.json').read_bytes();h=hashlib.sha256(raw).hexdigest();assert h=='c7979eee667075882e187fbec19f35e12f035d7c132b6ce9aaf418af6ea90224'
j=json.loads(raw)
def exact(n,d,q):
 wp=(q+d)/(2*q);total=0.
 for m in range(n+1):
  pm=math.comb(n,m)*q**m*(1-q)**(n-m)
  for w in range(m+1):
   tail=sum(math.comb(m,i) for i in range(min(w,m-w)+1))
   pp=min(1.,2*tail/(2**m))
   if pp<=.025 and 10*(2*w-m)>=n:
    total+=pm*math.comb(m,w)*wp**w*(1-wp)**(m-w)
 return total
rows=[]
for r in j['rows']:
 if r['conditional_dependence']=='aligned':
  e=exact(r['n'],r['true_delta_each'],r['discordance_each']);v=r['estimates']['both_holm_and_observed_10pp'];h=r['joint_mc_95_normal_halfwidth']
  rows.append({'n':r['n'],'delta':r['true_delta_each'],'q':r['discordance_each'],'exact':e,'monte_carlo':v,'halfwidth':h,'difference':abs(e-v),'within_individual_95_mc_interval':abs(e-v)<=h})
minp=min(min(1.,2*sum(math.comb(m,i) for i in range(min(w,m-w)+1))/2**m) for m in range(7) for w in range(m+1))
res={'status':'CONDITIONAL_ILLUSTRATION_INDEPENDENTLY_CHECKED_NOT_THREE_SEED_OR_FULL_RULE','source_sha256':{'data':hashlib.sha256(raw).hexdigest(),'report':hashlib.sha256((src/'SMALL_N_POWER_REVIEW.md').read_bytes()).hexdigest(),'script':hashlib.sha256((src/'small_n_power.py').read_bytes()).hexdigest(),'base_simulator':hashlib.sha256((src/'paired_power.py').read_bytes()).hexdigest()},'n6_exact_min_p':minp,'n6_holm_two_comparison_pass_possible':minp<=.025,'aligned_checks':rows,'all_aligned_within_individual_mc_95_interval':all(r['within_individual_95_mc_interval'] for r in rows),'scope':'Independent enumeration assumes both comparisons identical; only the perfectly aligned conditional dependence case is checked; statistical scenarios assume fixed model per arm and IID tasks, same effects and discordance. The bound does not apply to three-seed or alternative methods. Selected correlation structures are not a universal interval; family/NA/aborts not simulated. A per-scenario 95% interval is not a familywise grid confidence band.'}
(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({'n6_min_p':minp,'aligned_n40_q20':next(r for r in rows if r['n']==40 and r['delta']==.1 and r['q']==.2),'num_checks':len(rows),'all_within':res['all_aligned_within_individual_mc_95_interval']}))
