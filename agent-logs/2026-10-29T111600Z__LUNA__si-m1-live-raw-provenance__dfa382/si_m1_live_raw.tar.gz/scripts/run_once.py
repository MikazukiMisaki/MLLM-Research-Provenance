#!/usr/bin/env python3
"""Run exactly one bound preflight OR one separately-cleared supervised live command.
Use only after independently verifying authorization and (for live) clearance.
No auto-retry; dispatch claims persist even if process creation fails.
"""
import argparse,hashlib,json,os,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('/home/lizening/wt-si-five-case-probe')
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(c,m):
 if not c: raise ValueError(m)
def fresh(path,data):
 data=(json.dumps(data,sort_keys=True,indent=2)+'\n').encode();fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f: f.write(data);f.flush();os.fsync(f.fileno())
 return hashlib.sha256(data).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--authorization',required=True,type=Path);p.add_argument('--authorization-sha256',required=True);p.add_argument('--mode',choices=('preflight','live'),required=True);p.add_argument('--clearance',type=Path);p.add_argument('--clearance-sha256');args=p.parse_args()
 os.umask(0o077);auth=args.authorization.resolve();require(args.authorization==auth and sha(auth)==args.authorization_sha256,'authorization path/hash mismatch');a=json.loads(auth.read_bytes());control=Path(a['preflight_receipt_path']).parent
 require(control.is_absolute() and control.is_dir() and control.stat().st_uid==os.getuid() and control.stat().st_mode&0o077==0,'private owned control')
 require(a['source_sha']=='dfa382ad0ab604746690e96537dc4009cfeeefd0' and a['maximum_launches']==1 and a['evidence_class']=='live_single_step_probe','approved scope')
 source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();clean=not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True);require(source==a['source_sha'] and clean,'exact clean source')
 render=lambda argv:[args.authorization_sha256 if x=='@AUTHORIZATION_SHA256@' else x for x in argv]
 if args.mode=='preflight':
  require(args.clearance is None and args.clearance_sha256 is None,'preflight does not accept clearance');command=render(a['preflight_argv'])
 else:
  require(args.clearance is not None and args.clearance_sha256 is not None,'independent clearance required');cl=args.clearance.resolve();require(args.clearance==cl and sha(cl)==args.clearance_sha256,'clearance path/hash mismatch');c=json.loads(cl.read_bytes());require(c['schema']=='SI_M1_CLEARANCE_V1' and c['decision']=='RELEASE_ONE_PROBE' and c['maximum_launches']==1 and c['retry_authorized'] is False,'one-shot clearance')
  require(c['argv'][:len(render(a['launch_argv']))]==render(a['launch_argv']) and c['argv'][len(render(a['launch_argv'])):]==['--clearance',str(cl),'--clearance-sha256','@CLEARANCE_SHA256@'],'bound live argv')
  command=[args.clearance_sha256 if x=='@CLEARANCE_SHA256@' else x for x in c['argv']]
 claim=control/(args.mode+'_dispatch_claim.json');fresh(claim,{'mode':args.mode,'authorization_sha256':args.authorization_sha256,'clearance_sha256':args.clearance_sha256,'run_id':a['run_id'],'no_retry':True,'created_utc':datetime.now(timezone.utc).isoformat()})
 out=control/(args.mode+'.stdout');err=control/(args.mode+'.stderr');receipt=control/(args.mode+'_invocation_exit.json');started=time.monotonic();process=None
 try:
  with out.open('xb') as stdout,err.open('xb') as stderr:
   process=subprocess.Popen(command,cwd=ROOT,env=a['environment'],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
   try: starttick=int((Path('/proc')/str(process.pid)/'stat').read_text().rsplit(')',1)[1].split()[19])
   except (FileNotFoundError,ProcessLookupError):starttick=None
   fresh(control/(args.mode+'_invocation_start.json'),{'mode':args.mode,'pid':process.pid,'start_tick':starttick,'authorization_sha256':args.authorization_sha256,'started_utc':datetime.now(timezone.utc).isoformat(),'note':'local supervisor/preflight process; no host PID attribution'})
   rc=process.wait()
  value={'mode':args.mode,'pid':process.pid,'start_tick':starttick,'returncode':rc,'elapsed_seconds':time.monotonic()-started,'authorization_sha256':args.authorization_sha256,'clearance_sha256':args.clearance_sha256,'stdout_sha256':sha(out),'stderr_sha256':sha(err),'no_retry':True,'completed_utc':datetime.now(timezone.utc).isoformat()}
  fresh(receipt,value);print(json.dumps(value,sort_keys=True));return rc
 except BaseException as error:
  if process is None:
   fresh(receipt,{'mode':args.mode,'returncode':None,'spawn_error':{'type':type(error).__name__,'message':str(error)},'no_retry':True})
  raise
if __name__=='__main__':raise SystemExit(main())
