#!/usr/bin/env python3
"""Illustrative one-training-seed two-comparison power; not protocol power."""
import argparse
import json
import math
import platform
import sys
import numpy as np


def pvalue_table(n):
    # Each row contains exact doubled binomial tail probabilities, indexed by
    # discordances and min(wins, losses). Recurrence avoids 2**(-n) underflow.
    out = np.ones((n + 1, n // 2 + 1), dtype=np.float64)
    for m in range(1, n + 1):
        mid = m // 2
        mass = math.exp(math.lgamma(m + 1) - math.lgamma(mid + 1)
                        - math.lgamma(m - mid + 1) - m * math.log(2))
        tmp = np.zeros(mid + 1)
        tmp[mid] = mass
        for k in range(mid, 0, -1):
            tmp[k - 1] = tmp[k] * k / (m - k + 1)
        out[m, :mid + 1] = np.minimum(1., 2. * np.cumsum(tmp))
    return out


def joint_probs(p_c, delta, discord, dependence):
    win = (discord + delta) / 2
    loss = (discord - delta) / 2
    assert 0 <= win <= p_c and 0 <= loss <= 1-p_c
    probs = []
    for c in (0, 1):
        pc = p_c if c else 1-p_c
        # Given C, A and B each disagree with C with common probability r.
        r = win / pc if c else loss / pc
        both = {'lower': max(0., 2*r-1), 'independent': r*r,
                'aligned': r}[dependence]
        for a in (0, 1):
            for b in (0, 1):
                da, db = (a != c), (b != c)
                x = both if da and db else (r-both if da or db else 1-2*r+both)
                probs.append(pc*x)
    p = np.array(probs)
    assert min(p) >= -1e-12 and abs(sum(p)-1) < 1e-12
    return p


def evaluate(n, delta, discord, dep, simulations, rng, pvals):
    probs = joint_probs(.8, delta, discord, dep)
    cells = rng.multinomial(n, probs, size=simulations).reshape(-1,2,2,2)
    aw = cells[:,1,0,:].sum(axis=1)
    al = cells[:,0,1,:].sum(axis=1)
    bw = cells[:,1,:,0].sum(axis=1)
    bl = cells[:,0,:,1].sum(axis=1)
    pa = pvals[aw+al, np.minimum(aw,al)]
    pb = pvals[bw+bl, np.minimum(bw,bl)]
    both_holm = (np.minimum(pa,pb) <= .025) & (np.maximum(pa,pb) <= .05)
    point = (10*(aw-al) >= n) & (10*(bw-bl) >= n)
    passed = both_holm & point
    vals = {'one_pair_p_le_0_05':np.mean(pa <= .05),
            'both_holm':np.mean(both_holm), 'both_observed_at_least_10pp':np.mean(point),
            'both_holm_and_observed_10pp':np.mean(passed)}
    return {'n':n, 'true_delta_each':delta, 'discordance_each':discord,
            'conditional_dependence':dep, 'probabilities_c_a_b_000_to_111':probs.tolist(),
            'estimates':{k:float(v) for k,v in vals.items()},
            'joint_mc_95_normal_halfwidth':float(1.96*math.sqrt(vals['both_holm_and_observed_10pp']*(1-vals['both_holm_and_observed_10pp'])/simulations))}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--simulations',type=int,default=20000); ap.add_argument('--seed',type=int,default=1092026)
    a=ap.parse_args(); assert a.simulations > 0
    maximum=1312; table=pvalue_table(maximum)
    assert table[4,1] == .625 and table[0,0] == 1
    rng=np.random.default_rng(a.seed)
    scenarios=[(.10,.20),(.10,.30),(.15,.25),(.15,.35)]
    rows=[evaluate(n,d,q,dep,a.simulations,rng,table) for d,q in scenarios
          for dep in ('lower','independent','aligned') for n in (82,164,328,656,1312)]
    print(json.dumps({'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),
        'rng':'numpy.default_rng / PCG64','seed':a.seed,'simulations_per_scenario':a.simulations,
        'design':'illustration: iid hypothetical tasks, single fixed C, A, B; conditional dependence varies',
        'limitations':'Not multi-seed power, not family warning, no finite population inference; no fitting to outcomes.',
        'rows':rows},indent=2))


if __name__ == '__main__': main()
