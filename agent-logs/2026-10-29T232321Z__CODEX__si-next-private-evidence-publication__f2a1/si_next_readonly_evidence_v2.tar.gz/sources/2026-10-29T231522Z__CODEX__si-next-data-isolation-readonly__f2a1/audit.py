import collections,hashlib,json,os
from pathlib import Path

ROOT=Path('/home/lizening/alfworld_data/json_2.1.1')
N=Path('/home/lizening/research-notes/agent-logs')
OUT=Path(__file__).parent
INPUTS={
 'registry':N/'2026-10-25T065200Z__LUNA__si-p1-isolation-budget__caae4c/KNOWN_USE_IDENTITIES.json',
 'old_candidates':N/'2026-10-25T054106Z__LUNA__sft-raw-evidence-audit__b1c48c/AVAILABLE_IDENTITY_CANDIDATES.json',
 'partition_proposal':N/'2026-10-25T084517Z__LUNA__si-p3-isolation-budget-design__si3_7d91/partition_proposal.json',
 'expert':Path('/home/lizening/Alfworld-Self-Improvement-Project/artifacts/runtime/sft-policy-bootstrap/sft_expert_dataset_balanced.jsonl'),
 'schedule82':N/'2026-10-29T113523Z__ASTRA__three-arm-prospective-design__a55d1af9/PILOT82_PROPOSED_SCHEDULE_PRIVATE.json',
 'bindings82':N/'2026-10-29T120900Z__SOL__si-pilot82-game-byte-isolation/EVAL_BYTE_BINDINGS_PRIVATE.json',
 'Bmanifest':N/'2026-10-29T115700Z__SOL__si-pilot82-dataset-materialization/B_manifest_candidate_PRIVATE.json',
 'Cmanifest':N/'2026-10-29T115700Z__SOL__si-pilot82-dataset-materialization/C_manifest_candidate_PRIVATE.json',
}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(k):return json.loads(INPUTS[k].read_bytes())
def listsha(s):return hashlib.sha256(('\n'.join(sorted(s))+'\n').encode()).hexdigest()
before={k:sha(p) for k,p in INPUTS.items()}
assert before['expert']=='c547e8f0c5988b29288f2a097169c7859741b7d4f53f222af31f5e2889d516cf'
assert before['schedule82']=='c352a0d708b910bb3703c63009aed3a800b5ba4d40f95021f3bd30db0e4823cd'
assert before['bindings82']=='a9e130a33e2ae611563bbbc6dd2afa65f8d711f55631c9aa8b1039b9264379cc'
reg=read('registry');regsets={k:set(v) for k,v in reg['registered_identity_members'].items() if isinstance(v,list)}
known=set().union(*regsets.values())
assert len(regsets['valid_unseen_consumed_G1'])==60
schedule=read('schedule82')['rows'];ev_ids={r['task_id'] for r in schedule};ev_parents={r['parent'] for r in schedule}
assert len(ev_ids)==len(ev_parents)==82
bindings=read('bindings82');assert {r['task_id'] for r in bindings}==ev_ids
ev_game={r['game']['sha256'] for r in bindings};ev_traj={r['traj_data']['sha256'] for r in bindings}
arms={k:set(read(k)['task_exposures']) for k in ('Bmanifest','Cmanifest')}
assert all(len(v)==78 for v in arms.values())
proposal=read('partition_proposal')['rows'];assert len(proposal)==1141
reserved={r['identity'] for r in proposal};reserve_parents={s.split('/')[0] for s in reserved}
expert_ids=set();expert_game=set();expert_traj=set();nr=0
with INPUTS['expert'].open('rb') as f:
 for line in f:
  row=json.loads(line);expert_ids.add(row['task_id']);expert_game.add(row['source_game_sha256']);expert_traj.add(row['source_traj_data_sha256']);nr+=1
assert nr==20967 and len(expert_ids)==1200
expert_parents={x.split('/')[0] for x in expert_ids};assert len(expert_parents)==837
protected_ids=known|expert_ids|ev_ids|reserved
protected_parents={x.split('/')[0] for x in protected_ids}|ev_parents|arms['Bmanifest']|arms['Cmanifest']
records=[]
for split in ('train','valid_train','valid_seen','valid_unseen'):
 for parent in sorted(ROOT.joinpath(split).iterdir()):
  if not parent.is_dir():continue
  for trial in sorted(parent.iterdir()):
   if not trial.is_dir():continue
   ident=parent.name+'/'+trial.name
   game=trial/'game.tw-pddl';traj=trial/'traj_data.json'
   records.append({'split':split,'task':ident,'parent':parent.name,'family':parent.name.split('-')[0],
                   'game':sha(game) if game.is_file() else None,'traj':sha(traj) if traj.is_file() else None})
assert len({(r['split'],r['task']) for r in records})==len(records)
# Derive byte exclusion hashes also from installed historical matches; no task file is interpreted.
known_records=[r for r in records if r['task'] in protected_ids or r['parent'] in protected_parents]
old_game=expert_game|ev_game|{r['game'] for r in known_records if r['game']}
old_traj=expert_traj|ev_traj|{r['traj'] for r in known_records if r['traj']}
eligiblefamilies={'look_at_obj_in_light','pick_and_place_simple','pick_clean_then_place_in_recep','pick_cool_then_place_in_recep','pick_heat_then_place_in_recep','pick_two_obj_and_place'}
result={};candidate=[]
for split in ('train','valid_train','valid_seen','valid_unseen'):
 rr=[r for r in records if r['split']==split]
 complete=[r for r in rr if r['game'] and r['traj']]
 six=[r for r in complete if r['family'] in eligiblefamilies]
 exact_unlisted=[r for r in six if r['task'] not in known]
 parent_unlisted=[r for r in six if r['parent'] not in protected_parents]
 byte_unlisted=[r for r in parent_unlisted if r['game'] not in old_game and r['traj'] not in old_traj]
 for r in byte_unlisted:candidate.append(r)
 result[split]={'all_parent_dirs':len({r['parent'] for r in rr}),'all_trial_dirs':len(rr),
  'game_present':sum(bool(r['game']) for r in rr),'both_game_and_traj_present':len(complete),
  'six_family_with_both_files':len(six),'six_family_trials_not_in_old_exact_registry':len(exact_unlisted),
  'six_family_parent_not_in_any_protected_registry_or_reservation':len({r['parent'] for r in parent_unlisted}),
  'six_family_trials_parent_not_protected':len(parent_unlisted),
  'six_family_parent_and_byte_unlisted_trials':len(byte_unlisted),
  'six_family_parent_and_byte_unlisted_parents':len({r['parent'] for r in byte_unlisted}),
  'candidate_parent_families':dict(sorted(collections.Counter({f:len({r['parent'] for r in byte_unlisted if r['family']==f}) for f in eligiblefamilies}).items())),
  'candidate_task_id_set_sha256':listsha({r['task'] for r in byte_unlisted}),
  'candidate_parent_id_set_sha256':listsha({r['parent'] for r in byte_unlisted}),
  'candidate_status':'UNKNOWN_HISTORY; FILE_PRESENCE_AND_HASH_ONLY; NOT_SELECTED; NOT_EXECUTABILITY_OR_HELDOUT_CERTIFICATION'}
assert before=={k:sha(p) for k,p in INPUTS.items()}
output={'schema':'SI_NEXT_ISOLATION_METADATA_V1','scope':'No task payload parsed or displayed; candidate game and trajectory files streamed for SHA256 only; no outcomes used, no selection, no model/environment/test.','input_hashes':before,'full_registry_total_identity_count':len(known),'expert':{'rows':nr,'trials':len(expert_ids),'parents':len(expert_parents)},'pilot82':{'trials':len(ev_ids),'parents':len(ev_parents),'selected_parents_sharing_reserve':sum(bool(r['shares_unexecuted_reserve_parent']) for r in schedule)},'proposal_trials':len(reserved),'proposal_parents':len(reserve_parents),'B_C_parent_counts':{k:len(v) for k,v in arms.items()},'protected_identity_count':len(protected_ids),'protected_parent_count':len(protected_parents),'splits':result,
 'limitations':['Registry is incomplete outside the enumerated sources, and a failed engineering episode or later historical exposure may be absent; no task is certified unseen or held out.', 'Hashes compare against available expert/evaluation and installed bytes for protected identities/parents only; historical deleted files, changed snapshots, semantic or environment-layout similarity are not excluded.', 'Split names do not establish no prior model pretraining or exposure, and parent naming is an operational not a fully validated semantic scene identifier.', 'Presence of game and trajectory files does not establish valid launch, environment compatibility, sampling independence, or family power.', 'All 1141 reserved proposal tasks conservatively protect their parent; reservation is not evidence they ran, and result is not a prospective sample or schedule.'],
 'effects':{'model_calls':0,'cuda_calls':0,'environment_calls':0,'new_tasks_selected':0,'outcomes_read':0}}
def write(name,x):
 p=OUT/name
 with p.open('x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
 os.chmod(p,0o600)
write('ISOLATION_COUNTS.json',output)
write('CANDIDATE_METADATA_PRIVATE.json',{'warning':'private raw identities; not a schedule or scientific clean-task claim','rows':candidate})
print(json.dumps({'splits':result,'protected_trials':len(protected_ids),'protected_parents':len(protected_parents),'pilot82':output['pilot82']},sort_keys=True))
