#!/usr/bin/env python3
"""SI-M1: explicit static preflight or one externally supervised five-case probe."""
from __future__ import annotations
import argparse,json,sys,time
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from self_improvement.si_m1.contract import require,LIVE
from self_improvement.si_m1.gate import authenticate,preflight,verified_context

def main(argv=None):
    entered=time.monotonic();parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True);mode.add_argument('--preflight-only',action='store_true');mode.add_argument('--live',action='store_true');mode.add_argument('--worker',action='store_true',help=argparse.SUPPRESS)
    parser.add_argument('--authorization',type=Path,required=True);parser.add_argument('--authorization-sha256',required=True);parser.add_argument('--proposal',type=Path,required=True);parser.add_argument('--clearance',type=Path);parser.add_argument('--clearance-sha256');parser.add_argument('--launch-context-sha256',help=argparse.SUPPRESS)
    args=parser.parse_args(argv)
    try:
        require(sys.flags.isolated==1,'requires pinned isolated Python -I')
        mode='preflight' if args.preflight_only else 'worker' if args.worker else 'live'
        permit=authenticate(ROOT,args.authorization,args.authorization_sha256,args.proposal,invocation=list(sys.orig_argv),mode=mode,clearance_path=args.clearance,clearance_sha256=args.clearance_sha256,launch_context_sha256=args.launch_context_sha256)
        if args.preflight_only:print(json.dumps(preflight(permit)));return 0
        if args.worker:
            launch,_=verified_context(permit)
            from self_improvement.si_m1.collector import ProbeRun
            report=ProbeRun(permit,permit.output,started_at=launch['allocation_started_monotonic']).run()
            return int(report['status']!='COMPLETE_FIVE_SINGLE_STEP_PROBE')
        from self_improvement.si_m1.supervisor import supervise
        from self_improvement.si_p3.runtime_gate import utc
        seconds=min(1800,(min(utc(permit.authorization['expires_utc']),utc(permit.clearance['expires_utc']))-datetime.now(timezone.utc)).total_seconds())
        command=['--worker' if x=='--live' else x for x in sys.orig_argv]
        context={'authorization_sha256':permit.authorization_sha256,'source_sha':permit.authorization['source_sha'],'evidence_class':LIVE,'probe_binding':permit.binding(),'clearance_sha256':permit.clearance_sha256,'allocation_started_monotonic':entered,'supervisor_argv':list(sys.orig_argv)}
        receipt=supervise(command,permit.output,context=context,seconds=seconds,environment=permit.authorization['environment'])
        return int(not(receipt['authentic_returncode']==0 and receipt['execution_status']=='EXIT_RECORDED' and receipt['child_report_present']))
    except Exception as error:
        print(json.dumps({'status':'REJECTED_OR_INCONCLUSIVE','exception':type(error).__name__,'message':str(error)}),file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
