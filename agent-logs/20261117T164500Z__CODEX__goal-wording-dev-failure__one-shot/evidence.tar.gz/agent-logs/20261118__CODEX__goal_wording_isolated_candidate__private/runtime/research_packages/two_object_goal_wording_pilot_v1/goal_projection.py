"""Experimental, offline-only projection adapter for an authored DEV pilot.

This module has no CLI and does not load a model, environment, or task files.
It is not connected to an evaluation runner or authorized for execution.
"""

from dataclasses import is_dataclass, replace
from typing import Any, Callable


CLARIFICATION = (
    "The task is complete only when two distinct objects of the required type "
    "are in the designated target receptacle."
)
FAMILY = "pick_two_obj_and_place"


def goal_projection(projection: Callable[..., Any], *, clarify: bool) -> Callable[..., Any]:
    """Wrap a public projection without mutating the environment or base policy.

    In the intervention arm the same fixed, goal-derived sentence is appended to
    the public goal on every decision. History and observations pass unchanged.
    The caller must separately bind the authored task, model, logging, budget,
    and projection identity; this helper cannot establish any of those facts.
    """
    if type(clarify) is not bool:
        raise TypeError("clarify must be a boolean")
    if not callable(projection):
        raise TypeError("projection must be callable")

    def wrapped(state: Any, history: Any) -> Any:
        if not clarify:
            return projection(state, history)
        if not is_dataclass(state) or isinstance(state, type):
            raise TypeError("public state must be a dataclass instance")
        if getattr(state, "family", None) != FAMILY:
            raise ValueError("clarification is restricted to two-object tasks")
        goal = getattr(state, "goal", None)
        if not isinstance(goal, str) or not goal.strip():
            raise ValueError("public goal must be nonempty text")
        if CLARIFICATION in goal:
            raise ValueError("clarification is already present")
        return projection(replace(state, goal=f"{goal}\n{CLARIFICATION}"), history)

    return wrapped
