"""Build a B-bound, C-unavailable SI-U1 review draft from metadata only.

The CLI always emits wrappers marked DRAFT_NOT_EXECUTABLE; it never accepts C,
constructs a gate, reads task files, loads model weights, or runs preflight.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, os, re
from pathlib import Path

SCHEDULE='c352a0d708b910bb3703c63009aed3a800b5ba4d40f95021f3bd30db0e4823cd'
BYTE='a9e130a33e2ae611563bbbc6dd2afa65f8d711f55631c9aa8b1039b9264379cc'
TRAIN='f72e1de1b27659f0c0cb187c276c7c60483af089d4a756fbe3c3d7819dcc5698'
B_REVIEW='32a7b319ea2ed5f865659949ed5a320af5c4fbd435eb737511bad8926252c32d'
B_FINAL='9d8ce785c635db80ddd17999a981f0cee478ccf92d0aeb12eb7812978e441a36'
B_RESULT='e7d304b2a06195ea24555ec95be971b248bf5a9e86a9ee6955396e7f748f1150'
B_EXIT='3310a93cad131b1441136c2f6284b10d01361ea229f12c41d8e0b77ca7363ce0'
B_MANIFEST='d8639217e98b8bc96725408245ab9b59ff53070ae476682fb99ce6ee7ab13e6b'
C_MANIFEST='dcc1c38e4fde2f1751fcf17425a908da9ab8ee3ae9f665cbb2a56f2023d4452e'
P0='6b13612c33d96ae9bbda041c08d33e0e1888406c4782670e90c8ebd27467b5a5'
BASE='0239d34c87594c9d86c2fe5e81e515fa871809fa18b9ed67856fd0dc8e19c00b'
TRAIN_SOURCE='9bbaa12c2d8177a60ec5a74ed2f970ef29a57bce'
EVAL_SOURCE='8532275932dabddc498c23a2b6d9a045647542f0'
ARM={'generations':4100,'environment_operations':4182,'input_tokens':33587200,'output_tokens':65600,'elapsed_seconds':14400}
TOTAL={'generations':12300,'environment_operations':12546,'input_tokens':100761600,'output_tokens':196800,'per_call_input':8192,'elapsed_seconds':43200}
RESOURCE={'policy':'SHARED_CONTAINER_CUDA_V1','contract_sha256':'d908573f0c6d9518aec0a9b6b0a48c24648a26c3c708652b185a7cfe7b7e2489','gpu_uuid':'GPU-b08bc603-ebdb-787d-b5b6-ec796ea3022a','allocator_cap_bytes':24*1024**3,'preweight_global_free_min_bytes':28*1024**3,'later_global_free_min_bytes':2*1024**3}
class Rejected(ValueError):pass

def require(x,why):
    if not x:raise Rejected(why)
def digest(b):return hashlib.sha256(b).hexdigest()
def parse(raw):
    def pairs(items):
        d={}
        for k,v in items:
            require(k not in d,'duplicate JSON key');d[k]=v
        return d
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(Rejected('non-finite JSON')))
def read_json(path,expected):
    p=Path(path);require(p.is_absolute() and p.is_file() and not p.is_symlink(),'metadata file');raw=p.read_bytes();require(digest(raw)==expected,'metadata SHA mismatch');return parse(raw)
def ref(path,expected):return {'path':str(path),'sha256':expected}

def assemble(manifest_draft,runtime_draft,plan_draft,schedule,byte,training,accept,result,exit,b_manifest,refs,*,expected):
    """Pure metadata function; explicit expected hashes enable synthetic tests only."""
    for d in (manifest_draft,runtime_draft,plan_draft):require(type(d) is dict and d.get('status')=='DRAFT_NOT_EXECUTABLE','input draft status')
    m=copy.deepcopy(manifest_draft['template']);r=copy.deepcopy(runtime_draft['template']);p=copy.deepcopy(plan_draft['template']);rows=schedule['rows']
    require(m['schema']=='SI_TRANSFER_EVAL_V1' and m['heldout'] is False and len(m['tasks'])==len(rows)==len(byte)==len(r['games'])==82,'82-task draft')
    require(len({x['task_id'] for x in m['tasks']})==len({x['task_id'].split('/')[0] for x in m['tasks']})==82,'distinct selected identities')
    require(len({x['game']['sha256'] for x in byte})==len({x['traj_data']['sha256'] for x in byte})==82,'distinct selected byte identities')
    require(all(type(s['shares_unexecuted_reserve_parent']) is bool for s in rows) and sum(s['shares_unexecuted_reserve_parent'] for s in rows)==40,'reserve sibling count')
    for i,(t,s,b,g) in enumerate(zip(m['tasks'],rows,byte,r['games'])):
        require((t['task_id'],t['family'],t['seed'])==(s['task_id'],s['family'],2000000+i) and s['schedule_index']==i and s['environment_seed']==2000000+i and s['parent']==t['task_id'].split('/')[0] and s['reservation_partition']=='final_evaluation_train','frozen task/parent/family/seed')
        require((b['task_id'],b['parent'],b['family'])==(t['task_id'],s['parent'],t['family']) and t['game_sha256']==b['game']['sha256'] and g=={'task_id':b['task_id'],'game':b['game'],'traj_data':b['traj_data']},'frozen game/traj metadata')
        require(s['parent'] not in m['excluded_task_parents'],'represented parent exclusion')
    require(m['adapters']=={'A':P0,'B':None,'C':None} and r['adapters']['A']['sha256']==P0 and r['adapters']['B']['sha256'] is None and r['adapters']['C']['sha256'] is None,'fresh unresolved B/C draft')
    require(m['limits']==p['limits']==TOTAL and m['arm_limits']==p['arm_limits']==ARM and p['resource']==RESOURCE and p['horizon']==50 and p['max_new_tokens']==16 and p['arm_order']==['A','B','C'] and p['schedule_sha256']==expected['schedule_sha'] and all(type(v) is int for v in p['limits'].values()) and all(type(v) is int for v in p['arm_limits'].values()),'frozen evaluation plan')
    require(r['training_source_sha']==TRAIN_SOURCE and r['training_protocol_sha256']==expected['train_sha'] and r['training_protocol']['sha256']==expected['train_sha'] and r['base_sha256']==BASE and r['p0_legacy_sha256']=='6e403d85b150a74dfcc176f1f180ce4baf6fdacd922d2f96b3ceef0a21100f11','runtime frozen base/source')
    require(runtime_draft['known_runtime_identity']==training['runtime_identity'] and set(training['runtime_identity']['packages'])=={'torch','peft','transformers','tokenizers','safetensors','accelerate','huggingface_hub'} and set(r['packages'])=={'alfworld','alfworld.agents.environment.alfred_tw_env','peft','textworld','textworld.gym','torch','transformers','yaml'},'pinned interpreter/seven package trees and runtime origin set')
    identity=training['runtime_identity'];interpreter=identity['interpreter'];packages=identity['packages']
    valid=lambda x:type(x) is str and re.fullmatch('[0-9a-f]{64}',x) is not None
    require(type(interpreter) is dict and set(interpreter)=={'path','sha256','python_version'} and Path(interpreter['path']).is_absolute() and valid(interpreter['sha256']) and type(interpreter['python_version']) is str and bool(interpreter['python_version']),'interpreter identity fields')
    for name,entry in packages.items():
        require(type(entry) is dict and set(entry)=={'path','sha256','tree_sha256','version'} and Path(entry['path']).is_absolute() and valid(entry['sha256']) and valid(entry['tree_sha256']) and type(entry['version']) is str and bool(entry['version']),'seven package tree identities')
    for name,entry in r['packages'].items():
        require(type(entry) is dict and set(entry)=={'path','sha256','version'} and Path(entry['path']).is_absolute() and valid(entry['sha256']) and type(entry['version']) is str,'eight runtime module identities')
    for name in ('torch','transformers','peft'):require(r['packages'][name]=={k:packages[name][k] for k in ('path','sha256','version')},'model package identity continuity')
    valid_ref=lambda x:type(x) is dict and set(x)=={'path','sha256'} and type(x['path']) is str and Path(x['path']).is_absolute() and valid(x['sha256'])
    require(valid_ref(r['environment']['config']) and all(valid_ref(v) for v in r['environment']['logic_files'].values()) and valid_ref(r['training_protocol']),'environment/config/input bindings')
    require(r['environment']['pool_seed']==42 and r['environment']['data_root']=='/home/lizening/alfworld_data' and set(r['environment']['logic_files'])=={'domain','grammar'},'frozen environment')
    require(accept.get('schema')=='SI_U1_INDEPENDENT_B_REAL_ACCEPTANCE_V1' and accept.get('decision')=='ACCEPT_B_FIXED_FINAL_CHECKPOINT_AND_C_PREFLIGHT_PREREQUISITE_ONLY' and accept.get('source_sha')==TRAIN_SOURCE and accept.get('final_adapter_tree_sha256')==expected['b_final'] and accept.get('training_result_sha256')==expected['b_result_sha'] and accept.get('supervisor_sha256')==expected['b_exit_sha'] and accept.get('optimizer_updates')==78 and accept.get('microbatches_started_completed')==1248 and accept.get('supervised_tokens')==6240 and type(accept.get('actual_launcher_worker_exit')) is int and accept['actual_launcher_worker_exit']==0,'B independent acceptance')
    require(result.get('schema')=='SI_CONTINUATION_RESULT_V1' and result.get('status')=='COMPLETED' and result.get('arm')=='B' and result.get('base_sha256')==BASE and result.get('p0_adapter_sha256')==P0 and result.get('final_adapter_sha256')==expected['b_final'] and result.get('manifest_sha256')==expected['b_manifest_sha'] and result.get('error') is None and result.get('config')==training['training_config'],'B result lineage')
    counts=result.get('counts',{});require(counts.get('input_tokens')==661620 and counts.get('supervised_tokens')==6240 and counts.get('microbatches_started')==counts.get('microbatches_completed')==1248 and counts.get('optimizer_steps')==78 and all(type(counts.get(k)) is int for k in ('input_tokens','supervised_tokens','microbatches_started','microbatches_completed','optimizer_steps')),'B actual training dose')
    bind=exit.get('binding',{});require(exit.get('schema')=='SI_CONTINUATION_SUPERVISOR_EXIT_V1' and exit.get('status')=='EXIT_RECORDED' and type(exit.get('authentic_returncode')) is int and exit['authentic_returncode']==0 and exit.get('training_result_sha256')==expected['b_result_sha'] and exit.get('cleanup_established') is True and exit.get('within_time_cap') is True and exit.get('retry_authorized') is False and bind.get('source_sha')==TRAIN_SOURCE and bind.get('arm')=='B' and bind.get('manifest_sha256')==expected['b_manifest_sha'] and bind.get('paired_manifest_sha256')==expected['c_manifest_sha'] and bind.get('protocol_sha256')==expected['train_sha'] and bind.get('evidence_class')=='live','B actual supervisor binding')
    require(b_manifest.get('schema')=='SI_CONTINUATION_DATA_V1' and b_manifest.get('arm')=='B' and b_manifest.get('p0_adapter_sha256')==P0 and b_manifest.get('base_sha256')==BASE and b_manifest.get('training_config')==training['training_config'],'B manifest binding')
    m['adapters']['B']=expected['b_final'];r['adapters']['B']={'path':accept['final_adapter_path'],'sha256':expected['b_final'],'training_evidence':{'training_result':refs['b_result'],'supervisor_exit':refs['b_exit'],'manifest':refs['b_manifest']}}
    require(m['adapters']['C'] is None and r['adapters']['C']=={'path':None,'sha256':None,'training_evidence':None} and r['isolation_proof'] is None and r['manifest_sha256'] is None,'C/proof must stay unresolved')
    return {'manifest':{'status':'DRAFT_NOT_EXECUTABLE','template':m},'runtime':{'status':'DRAFT_NOT_EXECUTABLE','template':r,'known_runtime_identity':runtime_draft['known_runtime_identity']},'plan':{'status':'DRAFT_NOT_EXECUTABLE','template':p},'dependency':{'status':'DRAFT_NOT_EXECUTABLE','evaluation_source_sha':EVAL_SOURCE,'b_acceptance':refs['b_accept'],'b_result':refs['b_result'],'b_exit':refs['b_exit'],'b_manifest':refs['b_manifest'],'b_final_tree_sha256':expected['b_final'],'c_final':None,'actual_isolation_review':None,'final_analysis_binding':None,'actual_preflight':None,'clearance':None,'runtime_bytes_rehashed_now':False,'selected_game_bytes_rehashed_now':False,'b_adapter_rehashed_now':False,'review_or_release':False}}

def main():
    a=argparse.ArgumentParser();a.add_argument('--output-dir',required=True);args=a.parse_args();out=Path(args.output_dir)
    require(out.is_absolute() and out.parent.is_dir() and not out.exists() and not out.is_symlink(),'fresh absolute draft output')
    logs=Path('/home/lizening/research-notes/agent-logs');prev=logs/'2026-10-29T135500Z__SOL__si-pilot82-evaluation-preparation__8532275';ast=logs/'2026-10-29T113523Z__ASTRA__three-arm-prospective-design__a55d1af9';run=logs/'2026-10-29T125500Z__SOL__si-pilot82-bc-authorization-drafts__9bbaa/run_parent/B_run_064d0c7f39f14414acf24f399188f85f';mat=logs/'2026-10-29T115700Z__SOL__si-pilot82-dataset-materialization'
    inputs={'manifest':(prev/'MANIFEST_DRAFT_PRIVATE.json','f66cfc3abe2db6128fe18282783e8d0cc5e8fa6294b3160fc1f871180cae62ed'),'runtime':(prev/'RUNTIME_DRAFT_PRIVATE.json','d5093589b7b41b9e6c4139564b3062383fc7c77a2c88710de1f1db59493b75be'),'plan':(prev/'PLAN_DRAFT.json','912fa3f81784db122e14c6d0ec9067f1cc887628d2d3917251fdaefd8d790f42'),'schedule':(ast/'PILOT82_PROPOSED_SCHEDULE_PRIVATE.json',SCHEDULE),'byte':(logs/'2026-10-29T120900Z__SOL__si-pilot82-game-byte-isolation/EVAL_BYTE_BINDINGS_PRIVATE.json',BYTE),'training':(ast/'PILOT82_TRAINING_PROTOCOL.json',TRAIN),'accept':(ast/'B_REAL_INDEPENDENT_ACCEPTANCE_9BBAA.json',B_REVIEW),'result':(run/'training/training_result.json',B_RESULT),'exit':(run/'supervisor_exit.json',B_EXIT),'b_manifest':(mat/'B_manifest_candidate_PRIVATE.json',B_MANIFEST)}
    v={key:read_json(path,h) for key,(path,h) in inputs.items()};refs={name:ref(*inputs[name.replace('b_','') if name in ('b_result','b_exit') else {'b_accept':'accept','b_manifest':'b_manifest'}[name]]) for name in ('b_accept','b_result','b_exit','b_manifest')}
    expected={'schedule_sha':SCHEDULE,'train_sha':TRAIN,'b_final':B_FINAL,'b_result_sha':B_RESULT,'b_exit_sha':B_EXIT,'b_manifest_sha':B_MANIFEST,'c_manifest_sha':C_MANIFEST}
    result=assemble(v['manifest'],v['runtime'],v['plan'],v['schedule'],v['byte'],v['training'],v['accept'],v['result'],v['exit'],v['b_manifest'],refs,expected=expected)
    out.mkdir(mode=0o700)
    for name,obj in result.items():
        with (out/(name.upper()+'_DRAFT.json')).open('x') as f:json.dump(obj,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    print('B_BOUND_C_NULL_DRAFT_ONLY',out)
if __name__=='__main__':main()
