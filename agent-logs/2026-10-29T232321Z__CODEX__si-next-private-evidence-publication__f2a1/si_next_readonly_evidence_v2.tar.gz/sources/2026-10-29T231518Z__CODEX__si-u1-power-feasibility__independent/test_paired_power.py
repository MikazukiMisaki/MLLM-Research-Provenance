import math
import unittest
import numpy as np
from paired_power import pvalue_table, joint_probs, evaluate


class PowerTests(unittest.TestCase):
    def test_exact_binomial_against_integer_combinatorics(self):
        t = pvalue_table(100)
        for n in range(101):
            for k in range(n//2+1):
                expected = min(1, 2*sum(math.comb(n,i) for i in range(k+1))/2**n)
                self.assertAlmostEqual(t[n,k], expected, places=12)

    def test_all_margins_equal_requested_values(self):
        for delta, q in ((.1,.2),(.1,.3),(.15,.25),(.15,.35)):
            for dep in ('lower','independent','aligned'):
                p = joint_probs(.8,delta,q,dep).reshape(2,2,2)
                self.assertAlmostEqual(p[1,:,:].sum(),.8)
                self.assertAlmostEqual(p[:,1,:].sum(),.8-delta)
                self.assertAlmostEqual(p[:,:,1].sum(),.8-delta)
                self.assertAlmostEqual(p[1,0,:].sum()+p[0,1,:].sum(),q)
                self.assertAlmostEqual(p[1,:,0].sum()+p[0,:,1].sum(),q)

    def test_aligned_constructions_match_controls(self):
        p=joint_probs(.8,.1,.2,'aligned').reshape(2,2,2)
        self.assertAlmostEqual(sum(p[c,a,b] for c in (0,1) for a in (0,1) for b in (0,1) if a != b),0)

    def test_reproducible_and_gate_is_subset_of_each(self):
        a=evaluate(82,.1,.2,'independent',1000,np.random.default_rng(7),pvalue_table(82))
        b=evaluate(82,.1,.2,'independent',1000,np.random.default_rng(7),pvalue_table(82))
        self.assertEqual(a,b)
        e=a['estimates'];p=e['both_holm_and_observed_10pp']
        self.assertLessEqual(p,e['both_holm']);self.assertLessEqual(p,e['both_observed_at_least_10pp'])


if __name__ == '__main__': unittest.main()
