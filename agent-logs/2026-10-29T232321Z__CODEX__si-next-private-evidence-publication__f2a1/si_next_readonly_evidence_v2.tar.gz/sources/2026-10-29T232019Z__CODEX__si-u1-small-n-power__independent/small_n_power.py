#!/usr/bin/env python3
"""Hypothetical one-fixed-seed, two-comparison decision sensitivity."""
import json
import math
import platform
import sys
import numpy as np
from paired_power import evaluate, pvalue_table


def main():
    sims=100000
    seed=1092027
    rng=np.random.default_rng(seed)
    lookup=pvalue_table(82)
    # Exhaust all possible win/loss counts in a sample of six. Even the
    # smallest exact double-sided McNemar p cannot satisfy Holm's first .025.
    exact=[min(1., 2*sum(math.comb(m,i) for i in range(min(w,m-w)+1))/2**m)
           for m in range(7) for w in range(m+1)]
    minimum=min(exact)
    assert minimum==.03125 and minimum>.025
    rows=[evaluate(n,delta,q,dep,sims,rng,lookup)
          for delta,q in ((.10,.20),(.10,.35),(.15,.20),(.15,.35))
          for dep in ('lower','independent','aligned') for n in (6,40,82)]
    assert all(r['estimates']['both_holm_and_observed_10pp']==0
               for r in rows if r['n']==6)
    print(json.dumps({'python':sys.version,'numpy':np.__version__,
        'platform':platform.platform(),'random_generator':'PCG64 via numpy.default_rng',
        'seed':seed,'simulations_per_cell':sims,
        'max_normal_95_mc_halfwidth':1.96*math.sqrt(.25/sims),
        'exact_N6_minimum_p':minimum,'exact_N6_holm_and_point_probability':0.,
        'exact_N6_method':'Exhaust all m=0..6 and w=0..m; min two-sided p=2/64, above Holm .025.',
        'scope':'Hypothetical IID tasks, single fixed model per arm, no family/NA rule, not multi-seed power.',
        'rows':rows},indent=2))


if __name__=='__main__': main()
