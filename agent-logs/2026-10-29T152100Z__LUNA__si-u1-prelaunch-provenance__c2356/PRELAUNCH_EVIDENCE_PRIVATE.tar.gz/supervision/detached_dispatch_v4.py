"""One detached launcher. Preparation only until separately authorized.

The independent tool call may return while its detached wrapper remains alive.
No claim is made about survival of app/container/host termination.
"""
import hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
here=Path(__file__).resolve().parent;wrapper=here/'launch_three_arm_v4.py';auth=Path('/home/lizening/wt-si-self-imitation-evaluator/configs/local/si_pilot82_evaluation_authorization_c2356bbda2b44159a333e7c9d24fc2d4.json')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,obj):
 with Path(p).open('x') as f:json.dump(obj,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
if len(sys.argv)!=7:raise SystemExit('clearance path/hash, extraction spec path/hash, extraction approval path/hash required')
if sha(wrapper)!='546d3e63172e9df9f988bd2e6cb126f4f831fad8bdcba2c31802bc66eec7a06a' or sha(auth)!='88c28ca282405a6bcfca6452a7b361b09a01d397d4ed8b32f33d4175cf6c5366':raise SystemExit('reviewed wrapper or auth changed')
paths=[Path(sys.argv[1]),Path(sys.argv[3]),Path(sys.argv[5])];hashes=[sys.argv[2],sys.argv[4],sys.argv[6]]
if not all(p.is_absolute() and sha(p)==h for p,h in zip(paths,hashes)):raise SystemExit('missing or changed finalized clearance/spec/approval')
a=json.loads(auth.read_text());c=json.loads(paths[0].read_text());s=json.loads(paths[1].read_text());ap=json.loads(paths[2].read_text())
if not(c.get('decision')=='RELEASE_ONE_THREE_ARM_EVALUATION' and c.get('run_id')=='c2356bbda2b44159a333e7c9d24fc2d4' and c.get('maximum_launches')==1 and c.get('retry_authorized') is False and c.get('authorization_sha256')==sha(auth) and s.get('authorization')=={'path':str(auth),'sha256':sha(auth)} and s.get('clearance')=={'path':str(paths[0]),'sha256':hashes[0]} and ap.get('decision')=='APPROVED_FOR_POSTRUN_AUDIT_AND_EXTRACTION' and ap.get('spec_sha256')==hashes[1]):raise SystemExit('live or extraction authorization binding absent')
output=Path(a['output_path']);production_claim=output.parent/(output.name+'.launch_claim.json')
if output.exists() or output.is_symlink() or production_claim.exists() or production_claim.is_symlink():raise SystemExit('production identity already consumed; no retry')
argv=[a['interpreter'],'-I',str(wrapper),*sys.argv[1:]]
put(here/'DETACHED_LAUNCH_CLAIM.json',{'schema':'SI_U1_DETACHED_LAUNCH_CLAIM_V1','run_id':c['run_id'],'wrapper_sha256':sha(wrapper),'authorization_sha256':sha(auth),'clearance_sha256':hashes[0],'extraction_spec_sha256':hashes[1],'extraction_approval_sha256':hashes[2],'argv':argv,'utc':datetime.now(timezone.utc).isoformat(),'maximum_launches':1,'retry_authorized':False})
with (here/'detached_wrapper.stdout').open('xb') as out,(here/'detached_wrapper.stderr').open('xb') as err:
 p=subprocess.Popen(argv,cwd=here,env=a['environment'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 try:
  tick=int((Path('/proc')/str(p.pid)/'stat').read_text().rsplit(')',1)[1].split()[19]);pgid=os.getpgid(p.pid);sid=os.getsid(p.pid)
 except (OSError,ValueError,IndexError):tick=None;pgid=None;sid=None
 put(here/'DETACHED_WRAPPER_START.json',{'schema':'SI_U1_DETACHED_WRAPPER_START_V1','pid':p.pid,'start_tick':tick,'pgid':pgid,'sid':sid,'utc':datetime.now(timezone.utc).isoformat(),'argv':argv,'detached_dispatcher_waits_for_wrapper':False,'process_identity_observed':tick is not None})
print(json.dumps({'detached_wrapper_pid':p.pid,'start_tick':tick,'claim_created':True,'automatic_retry':False,'supervisor_launch_not_yet_proven':True}))
