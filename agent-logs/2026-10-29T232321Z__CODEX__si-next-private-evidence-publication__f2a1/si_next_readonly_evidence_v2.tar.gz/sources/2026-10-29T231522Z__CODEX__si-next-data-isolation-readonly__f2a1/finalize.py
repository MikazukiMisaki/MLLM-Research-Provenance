import collections,hashlib,json,os
from pathlib import Path
HERE=Path(__file__).parent
N=Path('/home/lizening/research-notes/agent-logs')
sources={
 'first_engineering_candidate':N/'2026-10-29T121500Z__CODEX__si-eval-engineering-task-metadata/ENGINEERING_CANDIDATE_PRIVATE.json',
 'second_engineering_candidate':N/'2026-10-29T132000Z__LUNA__si-eval-remediation-candidate__metadata/ENGINEERING_CANDIDATE_PRIVATE.json',
 'adopted_reservation':N/'2026-10-25T084517Z__SOL__si-p3-controlled-experience-design__si3_7d91/ADOPTED_METADATA_RESERVATIONS.json',
 'schedule82':N/'2026-10-29T113523Z__ASTRA__three-arm-prospective-design__a55d1af9/PILOT82_PROPOSED_SCHEDULE_PRIVATE.json',
 'baseline_candidates':HERE/'CANDIDATE_WITHOUT_RESERVATION_METADATA_PRIVATE.json',
 'conservative_candidates':HERE/'CANDIDATE_METADATA_PRIVATE.json',
 'baseline_counts':HERE/'ISOLATION_COUNTS_WITHOUT_RESERVATION.json',
 'conservative_counts':HERE/'ISOLATION_COUNTS.json'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(k):return json.loads(sources[k].read_bytes())
before={k:sha(p) for k,p in sources.items()}
assert before['first_engineering_candidate']=='7672feaaa6ccf83652ed85759dd4ff954ca2fa533b007daa7f82a643edb430d0'
assert before['second_engineering_candidate']=='660ef3fec2480db0f65514a8468c92d25a1b5084d5252d4dbfa3fa7475719c06'
assert before['adopted_reservation']=='6ce8a32a2345b59ecdef9c28c3a341e9c0801b8105f79895f9b2cb9545a4937e'
engineering=[rd(k)['candidate'] for k in ('first_engineering_candidate','second_engineering_candidate')]
ep={x['parent'] for x in engineering};ei={x['task_id'] for x in engineering};eg={x['game']['sha256'] for x in engineering};et={x['traj_data']['sha256'] for x in engineering}
assert len(ep)==len(ei)==2
schedule=rd('schedule82')['rows']; parents={x['parent'] for x in schedule}
adopted=rd('adopted_reservation')['rows'];reserve=[x for x in adopted if x['partition']=='unallocated_nonlight_reserve' and x['identity'].split('/')[0] in parents]
assert len(reserve)==49 and len({x['identity'].split('/')[0] for x in reserve})==40
sets={}
for typ,src in [('used_and_excluded_only','baseline_candidates'),('also_exclude_prior_proposal','conservative_candidates')]:
 old=rd(src)['rows'];removed=[r for r in old if r['parent'] in ep or r['task'] in ei or r['game'] in eg or r['traj'] in et]
 rows=[r for r in old if r not in removed]
 bysplit={}
 for split in ('train','valid_train','valid_seen','valid_unseen'):
  rr=[r for r in rows if r['split']==split];byparent={r['parent'] for r in rr}
  bysplit[split]={'trials':len(rr),'parents':len(byparent),'distinct_game_sha256':len({r['game'] for r in rr}),'distinct_trajectory_sha256':len({r['traj'] for r in rr}),'families_by_parent':dict(collections.Counter(r.split('-')[0] for r in byparent))}
 sets[typ]={'splits':bysplit,'union_parents':len({r['parent'] for r in rows}),'remove_engineering_rows_by_split':dict(collections.Counter(r['split'] for r in removed))}
 a={r['parent'] for r in rows if r['split']=='train'};b={r['parent'] for r in rows if r['split']=='valid_train'};sets[typ]['train_valid_train_same_parent_intersection']=len(a&b)
assert before=={k:sha(p) for k,p in sources.items()}
out={'schema':'SI_NEXT_ISOLATION_TWO_POLICY_SUMMARY_V1','input_hashes':before,'first_probe_failed_after_reset':True,'second_probe_successful':True,'independently_recorded_engineering_tasks':2,'shared_reserve':{'trials':49,'parents':40},'methods':'Full exact-identity, conservative parent, and available file-byte SHA join; old proposal reserve excluded only in second policy; subtract the two later engineering tasks and their parents/hashes in both policies.','two_separate_policies':sets,'caveats':['Candidate means only unlisted in the checked history and no same-byte hit in checked inputs; historical exposure can be missing, other artifact bytes can be unavailable, and task name does not establish disjoint semantic scene.', 'At most one per parent for parent-independent sampling; distinct parent across groups cannot be summed if intersection exists. Hash uniqueness does not guarantee executable compatibility or layout independence.', 'Directory inventory rather than a schedule; no candidate selected, task outcomes read, model called, or ALFWorld constructed.', 'Excluded registry includes both historical uses and explicit exclusions; do not equate every registered identity with a completed run.']}
with (HERE/'TWO_POLICY_SUMMARY.json').open('x') as f:json.dump(out,f,indent=2,sort_keys=True);f.write('\n')
os.chmod(HERE/'TWO_POLICY_SUMMARY.json',0o600)
print(json.dumps(out,sort_keys=True))
