import json,hashlib,pathlib,subprocess,datetime
p=pathlib.Path(__file__).resolve().parent;o=p/'stage1';refpath=pathlib.Path('/home/lizening/research-notes/agent-logs/2026-10-29T143500Z__SOL__si-u1-final-construction-plan__616f1e4/REFS_FROZEN.json')
def sha(x):return hashlib.sha256(x).hexdigest()
def read(x):return json.loads(x.read_bytes())
refs=read(refpath); assert all(sha(pathlib.Path(v['path']).read_bytes())==v['sha256'] for v in refs.values())
m=read(o/'manifest.json');r=read(o/'runtime_draft.json');plan=read(o/'plan.json');rec=read(o/'stage1_receipt.json');schedule=read(pathlib.Path(refs['schedule']['path']))['rows'];byte=read(pathlib.Path(refs['byte']['path']))
assert all((o/n).read_bytes()==json.dumps(read(o/n),sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode() for n in ('manifest.json','runtime_draft.json','plan.json','stage1_receipt.json'))
assert rec['status']=='CANDIDATE_FOR_INDEPENDENT_REVIEW_ONLY' and rec['refs_sha256']==sha(refpath.read_bytes()) and all(rec[k+'_sha256']==sha((o/n).read_bytes()) for k,n in [('manifest','manifest.json'),('runtime_draft','runtime_draft.json'),('plan','plan.json')])
assert len(m['tasks'])==len(schedule)==len(byte)==82 and len({t['task_id'].split('/')[0] for t in m['tasks']})==82 and m['heldout'] is False
assert all((t['task_id'],t['family'],t['seed'])==(s['task_id'],s['family'],2000000+i) and s['schedule_index']==i and s['parent']==t['task_id'].split('/')[0] and t['game_sha256']==bb['game']['sha256'] for i,(t,s,bb) in enumerate(zip(m['tasks'],schedule,byte)))
assert m['adapters']=={'A':'6b13612c33d96ae9bbda041c08d33e0e1888406c4782670e90c8ebd27467b5a5','B':'9d8ce785c635db80ddd17999a981f0cee478ccf92d0aeb12eb7812978e441a36','C':'40202cade31425b823ae4b153f2c975487d64b48461b47b922aebda226dd4c57'}
assert r['status']=='NOT_EXECUTION_RELEASE' and r['manifest_sha256']==rec['manifest_sha256'] and r['template']['isolation_proof'] is None and all(r['template']['adapters'][a]['sha256']==m['adapters'][a] for a in 'ABC')
assert all(r['template']['packages'][x]['version']=='' for x in ('alfworld','alfworld.agents.environment.alfred_tw_env','textworld.gym'))
assert plan['schema']=='SI_U1_EVALUATION_PLAN_V1' and plan['horizon']==50 and plan['max_new_tokens']==16 and plan['arm_order']==['A','B','C'] and plan['schedule_sha256']==refs['schedule']['sha256']
for root,commit in [('/home/lizening/wt-si-u1-eval-artifact-builder','3da63f4e3b0150c3ebb681a0d66dd87c22f7c3aa'),('/home/lizening/wt-si-u1-finalizer-bootstrap','2060cc8a20dfc6dafa3b4053043f6eab67ef7410'),('/home/lizening/wt-si-self-imitation-evaluator','8532275932dabddc498c23a2b6d9a045647542f0')]:
 assert subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=root,text=True).strip()==commit
 assert subprocess.check_output(['/usr/bin/git','status','--porcelain','--untracked-files=normal'],cwd=root,text=True).strip()==''
result={'schema':'SI_U1_STAGE1_LOCAL_METADATA_AUDIT_V1','status':'CANDIDATE_ONLY_NOT_ISOLATION_PASS','time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':rec['manifest_sha256'],'runtime_draft_sha256':rec['runtime_draft_sha256'],'plan_sha256':rec['plan_sha256'],'candidate_receipt_sha256':sha((o/'stage1_receipt.json').read_bytes()),'canonical_json_and_output_hashes_verified':True,'all_15_input_metadata_hashes_unchanged':True,'task_count':82,'unique_parents':82,'frozen_order_family_seed_and_byte_metadata_match':True,'adapter_lineage_metadata_match':True,'unversioned_module_strings_preserved':True,'source_checkouts_exact_clean_after':True,'runtime_not_execution_release':True,'independent_isolation_review_not_yet_completed':True,'no_scientific_execution_or_preflight':True}
with open(p/'CANDIDATE_METADATA_AUDIT.json','x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(result,sort_keys=True))
