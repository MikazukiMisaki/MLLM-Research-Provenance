"""Isolated reviewed SI-U1 finalizer bootstrap; no science/preflight launch.

Run exactly with the frozen interpreter `-I -S`. This module has no production
mock or test mode. Tests may import load_reviewed_modules in a separate synthetic
harness; the real entrypoint invokes the verified finalizer unmodified.
"""
from __future__ import annotations
import hashlib,os,subprocess,sys,types
from pathlib import Path

PYTHON=Path('/home/lizening/miniconda3/envs/alfworld-self-improve/bin/python3.10')
PY_SHA='560aa01150e792ac8efc5f0e55db51e7175623437a2c2d7e62b2ec2cd9973449'
BUILDER_ROOT=Path('/home/lizening/wt-si-u1-eval-artifact-builder')
BUILDER_COMMIT='3da63f4e3b0150c3ebb681a0d66dd87c22f7c3aa'
BUILDER_SHA='75f2b98b79f31148af288452c0f6804255056ea1208b35f9d920c1cdaf1357cb'
FINALIZER_SHA='6e07f70053a1d9709d419395a91ece8edb86db3a06f489354fc60aba0a25af3a'
EVAL_ROOT=Path('/home/lizening/wt-si-self-imitation-evaluator')
EVAL_COMMIT='8532275932dabddc498c23a2b6d9a045647542f0'
PREFIX='/home/lizening/miniconda3/envs/alfworld-self-improve'
TRUSTED_PATH=[PREFIX+'/lib/python310.zip',PREFIX+'/lib/python3.10',PREFIX+'/lib/python3.10/lib-dynload']

class BootstrapError(ValueError): pass

def require(v,msg):
    if not v:raise BootstrapError(msg)

def _file(path,expected):
    require(path.is_absolute() and path.is_file() and not path.is_symlink(),'trusted source path')
    raw=path.read_bytes();require(hashlib.sha256(raw).hexdigest()==expected,'trusted source digest');return raw

def _git(root,commit):
    require(root.is_absolute() and root.is_dir() and not root.is_symlink(),'trusted source root')
    env={'PATH':'/usr/bin:/bin','LC_ALL':'C','HOME':'/nonexistent','GIT_CONFIG_NOSYSTEM':'1'}
    def get(*args):return subprocess.check_output(['/usr/bin/git',*args],cwd=root,env=env,text=True).strip()
    require(get('rev-parse','--show-toplevel')==str(root) and get('rev-parse','HEAD')==commit and not get('status','--porcelain','--untracked-files=normal'),'trusted clean exact source')

def load_reviewed_modules():
    require(sys.flags.isolated==1 and sys.flags.no_site==1 and Path(sys.executable).resolve()==PYTHON.resolve() and hashlib.sha256(PYTHON.read_bytes()).hexdigest()==PY_SHA,'isolated frozen interpreter')
    require(sys.path==TRUSTED_PATH and 'builder' not in sys.modules and 'si_u1_reviewed_finalizer' not in sys.modules,'untrusted Python path or preloaded modules')
    _git(BUILDER_ROOT,BUILDER_COMMIT);_git(EVAL_ROOT,EVAL_COMMIT)
    bp=BUILDER_ROOT/'builder.py';fp=BUILDER_ROOT/'finalizer.py';builder_raw=_file(bp,BUILDER_SHA);finalizer_raw=_file(fp,FINALIZER_SHA)
    bm=types.ModuleType('builder');bm.__file__=str(bp);bm.__package__='';sys.modules['builder']=bm;exec(compile(builder_raw,str(bp),'exec'),bm.__dict__)
    fm=types.ModuleType('si_u1_reviewed_finalizer');fm.__file__=str(fp);fm.__package__='';sys.modules[fm.__name__]=fm;exec(compile(finalizer_raw,str(fp),'exec'),fm.__dict__)
    require(sys.modules['builder'] is bm and fm.b is bm and Path(bm.__file__)==bp and Path(fm.__file__)==fp and sys.path==TRUSTED_PATH,'verified module origin')
    _git(BUILDER_ROOT,BUILDER_COMMIT);_git(EVAL_ROOT,EVAL_COMMIT)
    return fm

def main():
    finalizer=load_reviewed_modules();finalizer.main()

if __name__=='__main__':main()
