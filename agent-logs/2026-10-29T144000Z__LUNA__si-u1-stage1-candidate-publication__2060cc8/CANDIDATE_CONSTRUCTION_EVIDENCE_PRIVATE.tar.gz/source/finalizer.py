"""Two-stage SI-U1 artifact finalizer. Does not grant review/preflight/launch.

Only synthetic tests have run. Real stage 1 requires genuine independently
reviewed B/C evidence; stage 2 requires independently issued isolation proof
and previously frozen analysis. No model/CUDA/ALFWorld is invoked.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,os,re,subprocess
from pathlib import Path
import builder as b

C_ACCEPT_DECISION='ACCEPT_C_FIXED_FINAL_CHECKPOINT_AND_EVALUATION_CONSTRUCTION_ONLY'
EXTRACTOR_SHA='c0827b923f518b5d8ddefb73974994d8a445f352fc8bc8b6e99abb88b3df0f7d'
EXTRACTOR_REVIEW_SHA='e1061aeb9551d2d4540063baab1f20574ce0cb5476b1e5a2d6895eb30beafc25'
EXTRACTOR_COMMIT='b442aa811bcec2fa4eba2cfabb2ed28719cc38dc'
STATS_SHA='dc65a06fda495517bc76357022a90a0622d1b17c11ee101e19d958aebb5e3251'

class Rejected(ValueError):pass

def need(v,msg):
    if not v:raise Rejected(msg)
def wire(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read_ref(ref):
    need(type(ref) is dict and set(ref)=={'path','sha256'} and type(ref['path']) is str and type(ref['sha256']) is str and re.fullmatch('[0-9a-f]{64}',ref['sha256']) is not None,'reference schema')
    p=Path(ref['path']);need(p.is_absolute() and p.is_file() and not p.is_symlink(),'ordinary absolute input file');raw=p.read_bytes();need(sha(raw)==ref['sha256'],'input drift');return b.parse(raw)
def exact(x,fields):need(type(x) is dict and set(x)==set(fields),'exact input fields')

def check_c(c,refs,training,expected,b_exit):
    review,accepted,result,supervisor,manifest=(c[k] for k in ('review','acceptance','result','exit','manifest'))
    fields=['schema','decision','source_sha','acceptance_sha256','training_result_sha256','supervisor_sha256','manifest_sha256','final_adapter_path','final_adapter_sha256','run_id','reviewer']
    exact(review,fields)
    need(review['schema']=='SI_U1_C_REVIEW_BINDING_V1' and review['decision']=='PASS_C_TRAINING_INDEPENDENT_ONLY' and review['source_sha']==b.TRAIN_SOURCE and type(review['reviewer']) is str and bool(review['reviewer']) and review['acceptance_sha256']==refs['c_accept']['sha256'] and review['training_result_sha256']==refs['c_result']['sha256'] and review['supervisor_sha256']==refs['c_exit']['sha256'] and review['manifest_sha256']==expected['c_manifest_sha'],'independent C binding')
    need(type(accepted) is dict and accepted.get('schema')=='SI_U1_INDEPENDENT_C_REAL_ACCEPTANCE_V1' and accepted.get('decision')==C_ACCEPT_DECISION and accepted.get('source_sha')==b.TRAIN_SOURCE and type(accepted.get('actual_launcher_worker_exit')) is int and accepted['actual_launcher_worker_exit']==0 and accepted.get('process_cleanup_established') is True and accepted.get('training_result_sha256')==refs['c_result']['sha256'] and accepted.get('supervisor_sha256')==refs['c_exit']['sha256'] and accepted.get('final_adapter_tree_sha256')==review['final_adapter_sha256'] and accepted.get('final_adapter_path')==review['final_adapter_path'],'C actual independent acceptance')
    h=review['final_adapter_sha256'];need(type(h) is str and re.fullmatch('[0-9a-f]{64}',h) is not None,'C tree hash')
    need(result.get('schema')=='SI_CONTINUATION_RESULT_V1' and result.get('status')=='COMPLETED' and result.get('arm')=='C' and result.get('base_sha256')==b.BASE and result.get('p0_adapter_sha256')==b.P0 and result.get('final_adapter_sha256')==h and result.get('manifest_sha256')==expected['c_manifest_sha'] and result.get('config')==training['training_config'] and result.get('error') is None,'C result lineage')
    counts=result.get('counts',{});need(counts.get('input_tokens')==695872 and counts.get('supervised_tokens')==6240 and counts.get('microbatches_started')==counts.get('microbatches_completed')==1248 and counts.get('optimizer_steps')==78 and all(type(counts.get(k)) is int for k in ('input_tokens','supervised_tokens','microbatches_started','microbatches_completed','optimizer_steps')),'C actual training dose')
    sb=supervisor.get('binding',{});bb=b_exit.get('binding',{})
    need(supervisor.get('schema')=='SI_CONTINUATION_SUPERVISOR_EXIT_V1' and supervisor.get('status')=='EXIT_RECORDED' and type(supervisor.get('authentic_returncode')) is int and supervisor['authentic_returncode']==0 and supervisor.get('training_result_sha256')==refs['c_result']['sha256'] and supervisor.get('cleanup_established') is True and supervisor.get('within_time_cap') is True and supervisor.get('retry_authorized') is False,'C real supervisor')
    need(sb.get('source_sha')==b.TRAIN_SOURCE and sb.get('arm')=='C' and sb.get('manifest_sha256')==expected['c_manifest_sha'] and sb.get('paired_manifest_sha256')==expected['b_manifest_sha'] and sb.get('protocol_sha256')==expected['train_sha'] and sb.get('evidence_class')=='live' and sb.get('run_id')==review['run_id'] and sb.get('run_id')!=bb.get('run_id') and sb.get('output_path')!=bb.get('output_path') and str(Path(sb.get('output_path',''))/'training'/'final_adapter')==review['final_adapter_path'],'C distinct live identity and adapter path')
    need(manifest.get('schema')=='SI_CONTINUATION_DATA_V1' and manifest.get('arm')=='C' and manifest.get('p0_adapter_sha256')==b.P0 and manifest.get('base_sha256')==b.BASE and manifest.get('training_config')==training['training_config'],'C training manifest')
    return h

def stage1(inputs,refs,expected):
    """Produce manifest bytes and review-only runtime candidate, not approval."""
    prepared=b.assemble(inputs['manifest_draft'],inputs['runtime_draft'],inputs['plan_draft'],inputs['schedule'],inputs['byte'],inputs['training'],inputs['b_accept'],inputs['b_result'],inputs['b_exit'],inputs['b_manifest'],refs,expected=expected)
    c_hash=check_c({k:inputs['c_'+k] for k in ('review','acceptance','result','exit','manifest')},refs,inputs['training'],expected,inputs['b_exit'])
    m=prepared['manifest']['template'];m['adapters']['C']=c_hash;mb=wire(m);h=sha(mb)
    r=prepared['runtime']['template'];r['manifest_sha256']=h;r['adapters']['C']={'path':inputs['c_review']['final_adapter_path'],'sha256':c_hash,'training_evidence':{'training_result':refs['c_result'],'supervisor_exit':refs['c_exit'],'manifest':refs['c_manifest']}}
    need(r['isolation_proof'] is None and all(r['adapters'][a]['sha256']==m['adapters'][a] for a in ('A','B','C')),'draft runtime isolated')
    return {'manifest_bytes':mb,'runtime_draft':{'schema':'SI_U1_FINALIZER_RUNTIME_DRAFT_V1','status':'NOT_EXECUTION_RELEASE','manifest_sha256':h,'template':r},'plan_bytes':wire(prepared['plan']['template'])}

def check_isolation(review,manifest_sha,schedule_sha,runtime):
    keys=['schema','decision','evaluation_manifest_sha256','metadata_schedule_sha256','b_dataset_sha256','c_dataset_sha256','known_use_registry_sha256','source_usage_sha256','reservation_sha256','checks','artifact_identity','limits'];exact(review,keys)
    i=runtime['isolation_inputs'];need(review['schema']=='SI_U1_ISOLATION_REVIEW_V1' and review['decision']=='PASS_REPRESENTED_IDENTITY_ISOLATION' and review['evaluation_manifest_sha256']==manifest_sha and review['metadata_schedule_sha256']==schedule_sha and all(review[k+'_sha256']==i[k]['sha256'] for k in ('b_dataset','c_dataset','known_use_registry','source_usage','reservation')),'represented identity input bindings')
    need(review['checks']=={'unique_parent_count':82,'all_original_final':True,'history_parent_overlap':0,'source_parent_overlap':0,'engineering_parent_overlap':0,'B_parent_overlap':0,'C_parent_overlap':0,'one_trial_per_parent':True},'represented parent isolation')
    need(review['artifact_identity']=={'game_manifest_sha256':i['game_manifest']['sha256'],'training_game_overlap':0,'source_game_overlap':0,'registered_expert_game_overlap':0,'source_traj_overlap':0,'registered_expert_traj_overlap':0,'duplicate_eval_game':0,'duplicate_eval_traj':0},'represented byte isolation')
    need(review['limits']=={'lifetime_registry_complete':False,'unseen_layout_proven':False,'byte_comparison_covers_all_historical_use':False,'reserve_sibling_parents':40},'isolation caveats')
    for value in list(review['checks'].values())+list(review['artifact_identity'].values())+list(review['limits'].values()):need(type(value) in (bool,int,str),'isolation value type')
    for k in ('unique_parent_count','history_parent_overlap','source_parent_overlap','engineering_parent_overlap','B_parent_overlap','C_parent_overlap'):need(type(review['checks'][k]) is int,'numeric parent checks')
    for k in ('all_original_final','one_trial_per_parent'):need(type(review['checks'][k]) is bool,'boolean parent checks')
    for k in ('training_game_overlap','source_game_overlap','registered_expert_game_overlap','source_traj_overlap','registered_expert_traj_overlap','duplicate_eval_game','duplicate_eval_traj'):need(type(review['artifact_identity'][k]) is int,'numeric byte checks')
    for k in ('lifetime_registry_complete','unseen_layout_proven','byte_comparison_covers_all_historical_use'):need(type(review['limits'][k]) is bool,'boolean caveats')
    need(type(review['limits']['reserve_sibling_parents']) is int,'reserve count')

def validate_analysis(plan):
    exact(plan,['schema','status','statistics_source_sha256','primary_contrasts','paired_test','multiple_testing','interval_method','outcome_rule','green_min_gain_pp','warning_drop_pp','green_condition','warning_condition','post_result_rule','extractor_source_sha256','extractor_review_sha256'])
    need(plan['schema']=='SI_U1_ANALYSIS_PLAN_V1' and plan['status']=='FROZEN_FOR_REVIEW' and plan['statistics_source_sha256']=='dc65a06fda495517bc76357022a90a0622d1b17c11ee101e19d958aebb5e3251' and plan['primary_contrasts']==['C-A','C-B'] and plan['paired_test']=='EXACT_TWO_SIDED_MCNEMAR' and plan['multiple_testing']=='HOLM_FWER_0_05' and plan['interval_method']=='SIMULTANEOUS_95_CP_COMPONENT_98_75' and plan['outcome_rule']=='COMPLETE_82_PAIRED_ONLY_NO_NA' and type(plan['green_min_gain_pp']) is int and plan['green_min_gain_pp']==10 and type(plan['warning_drop_pp']) is int and plan['warning_drop_pp']==10 and plan['green_condition']=='BOTH_POSITIVE_HOLM_AND_GAIN_GE_10PP_NO_FAMILY_CA_DROP_GE_10PP' and plan['warning_condition']=='PRIMARY_DROP_GE_10PP_OR_FAMILY_CA_DROP_GE_10PP' and plan['post_result_rule']=='NO_AUTOMATIC_RETRY_OR_THRESHOLD_SELECTION','frozen statistical analysis')
    need(plan['extractor_source_sha256']==EXTRACTOR_SHA and plan['extractor_review_sha256']==EXTRACTOR_REVIEW_SHA,'reviewed extractor source/review binding')

def stage2(stage,proof_raw,proof_ref,analysis_raw,analysis_ref,extractor_raw,extractor_review_raw):
    """Bind an independently issued proof; result is FOR_REVIEW, not clearance."""
    need(type(proof_raw) is bytes and type(proof_ref) is dict and set(proof_ref)=={'path','sha256'} and proof_ref['sha256']==sha(proof_raw) and type(analysis_raw) is bytes and type(analysis_ref) is dict and set(analysis_ref)=={'path','sha256'} and type(analysis_ref['sha256']) is str and re.fullmatch('[0-9a-f]{64}',analysis_ref['sha256']) is not None and analysis_ref['sha256']==sha(analysis_raw),'proof/analysis byte binding')
    need(type(extractor_raw) is bytes and sha(extractor_raw)==EXTRACTOR_SHA and type(extractor_review_raw) is bytes and sha(extractor_review_raw)==EXTRACTOR_REVIEW_SHA,'extractor and independent review actual bytes')
    extractor_review=b.parse(extractor_review_raw)
    need(type(extractor_review) is dict and extractor_review.get('schema')=='ASTRA_INDEPENDENT_EXTRACTOR_REVIEW_V1' and extractor_review.get('decision')=='PASS_SOFTWARE_ONLY_NOT_ANALYSIS_RELEASE' and extractor_review.get('source_sha')==EXTRACTOR_COMMIT and extractor_review.get('extractor_sha256')==EXTRACTOR_SHA and extractor_review.get('evaluator_sha')==b.EVAL_SOURCE and extractor_review.get('statistics_sha256')==STATS_SHA,'extractor independent review contents')
    proof=b.parse(proof_raw);analysis=b.parse(analysis_raw)
    validate_analysis(analysis)
    mraw=stage['manifest_bytes'];m=b.parse(mraw);rd=stage['runtime_draft'];r=copy.deepcopy(rd['template']);p=b.parse(stage['plan_bytes']);mh=sha(mraw);ph=sha(stage['plan_bytes'])
    need(rd['schema']=='SI_U1_FINALIZER_RUNTIME_DRAFT_V1' and rd['status']=='NOT_EXECUTION_RELEASE' and rd['manifest_sha256']==mh and r['manifest_sha256']==mh and m['schema']=='SI_TRANSFER_EVAL_V1','stage1 byte binding')
    need(p['schema']=='SI_U1_EVALUATION_PLAN_V1' and p['status']=='FROZEN_FIXED_SCIENCE' and p['schedule_sha256']==b.SCHEDULE and p['horizon']==50 and p['max_new_tokens']==16 and p['arm_order']==['A','B','C'] and p['limits']==m['limits']==b.TOTAL and p['arm_limits']==m['arm_limits']==b.ARM and p['resource']==b.RESOURCE and all(type(x) is int for x in p['limits'].values()) and all(type(x) is int for x in p['arm_limits'].values()),'fixed plan')
    check_isolation(proof,mh,b.SCHEDULE,r)
    r['isolation_proof']=proof_ref
    protocol={'schema':'SI_U1_EVALUATION_PROTOCOL_V1','status':'FROZEN_FOR_REVIEW','plan_sha256':ph,'schedule_sha256':b.SCHEDULE,'manifest_sha256':mh,'limits':p['limits'],'arm_limits':p['arm_limits'],'resource':p['resource'],'isolation_review_sha256':proof_ref['sha256'],'analysis_sha256':analysis_ref['sha256']}
    return {'runtime_bytes':wire(r),'protocol_bytes':wire(protocol),'manifest_sha256':mh,'plan_sha256':ph,'status':'FOR_INDEPENDENT_REVIEW_NOT_A_LAUNCH_CLEARANCE'}

EXPECTED={'schedule_sha':b.SCHEDULE,'train_sha':b.TRAIN,'b_final':b.B_FINAL,'b_result_sha':b.B_RESULT,'b_exit_sha':b.B_EXIT,'b_manifest_sha':b.B_MANIFEST,'c_manifest_sha':b.C_MANIFEST}
PINNED={'manifest_draft':'f66cfc3abe2db6128fe18282783e8d0cc5e8fa6294b3160fc1f871180cae62ed','runtime_draft':'d5093589b7b41b9e6c4139564b3062383fc7c77a2c88710de1f1db59493b75be','plan_draft':'912fa3f81784db122e14c6d0ec9067f1cc887628d2d3917251fdaefd8d790f42','schedule':b.SCHEDULE,'byte':b.BYTE,'training':b.TRAIN,'b_accept':b.B_REVIEW,'b_result':b.B_RESULT,'b_exit':b.B_EXIT,'b_manifest':b.B_MANIFEST,'c_manifest':b.C_MANIFEST}
REF_FIELDS=['manifest_draft','runtime_draft','plan_draft','schedule','byte','training','b_accept','b_result','b_exit','b_manifest','c_review','c_accept','c_result','c_exit','c_manifest']

def stage1_from_refs(refs):
    exact(refs,REF_FIELDS)
    for k,h in PINNED.items():need(refs[k]['sha256']==h,'frozen input reference')
    inputs={k:read_ref(v) for k,v in refs.items()}
    inputs.update({'c_acceptance':inputs.pop('c_accept')})
    return stage1(inputs,refs,EXPECTED)

def mkdir_fresh(path):
    p=Path(path);need(p.is_absolute() and p.parent.is_dir() and not p.exists() and not p.is_symlink(),'fresh absolute output directory');p.mkdir(mode=0o700);return p

def fresh(path,raw):
    with Path(path).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())

def verify_evaluator_source():
    root=Path('/home/lizening/wt-si-self-imitation-evaluator')
    need(root.is_dir() and not root.is_symlink(),'evaluation source checkout')
    def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
    need(git('rev-parse','--show-toplevel')==str(root) and git('rev-parse','HEAD')==b.EVAL_SOURCE and not git('status','--porcelain','--untracked-files=normal'),'exact clean evaluation source')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stage',required=True,choices=('one','two'));ap.add_argument('--refs',required=True);ap.add_argument('--refs-sha256',required=True);ap.add_argument('--output-dir',required=True);ap.add_argument('--proof');ap.add_argument('--proof-sha256');ap.add_argument('--analysis');ap.add_argument('--analysis-sha256');ap.add_argument('--extractor');ap.add_argument('--extractor-sha256');ap.add_argument('--extractor-review');ap.add_argument('--extractor-review-sha256');args=ap.parse_args()
    verify_evaluator_source();refs=read_ref({'path':args.refs,'sha256':args.refs_sha256});stage=stage1_from_refs(refs)
    if args.stage=='one':
        need(all(v is None for v in (args.proof,args.proof_sha256,args.analysis,args.analysis_sha256,args.extractor,args.extractor_sha256,args.extractor_review,args.extractor_review_sha256)),'stage one does not accept proof or analysis')
        verify_evaluator_source();out=mkdir_fresh(args.output_dir);fresh(out/'manifest.json',stage['manifest_bytes']);fresh(out/'runtime_draft.json',wire(stage['runtime_draft']));fresh(out/'plan.json',stage['plan_bytes'])
        receipt={'schema':'SI_U1_FINALIZER_STAGE1_V1','status':'CANDIDATE_FOR_INDEPENDENT_REVIEW_ONLY','refs_sha256':args.refs_sha256,'manifest_sha256':sha(stage['manifest_bytes']),'runtime_draft_sha256':sha(wire(stage['runtime_draft'])),'plan_sha256':sha(stage['plan_bytes'])};fresh(out/'stage1_receipt.json',wire(receipt));print(json.dumps(receipt,sort_keys=True))
    else:
        need(all(v is not None for v in (args.proof,args.proof_sha256,args.analysis,args.analysis_sha256,args.extractor,args.extractor_sha256,args.extractor_review,args.extractor_review_sha256)),'stage two requires independent proof and frozen analysis')
        proof_ref={'path':args.proof,'sha256':args.proof_sha256};analysis_ref={'path':args.analysis,'sha256':args.analysis_sha256};proof=read_ref(proof_ref);read_ref(analysis_ref)
        raw=Path(args.proof).read_bytes();need(sha(raw)==args.proof_sha256 and b.parse(raw)==proof,'proof drift')
        analysis_raw=Path(args.analysis).read_bytes();need(sha(analysis_raw)==args.analysis_sha256,'analysis drift')
        extractor_ref={'path':args.extractor,'sha256':args.extractor_sha256};extractor_review_ref={'path':args.extractor_review,'sha256':args.extractor_review_sha256}
        need(args.extractor_sha256==EXTRACTOR_SHA and args.extractor_review_sha256==EXTRACTOR_REVIEW_SHA,'reviewed extractor reference')
        for ref in (extractor_ref,extractor_review_ref):
            path=Path(ref['path']);need(path.is_absolute() and path.is_file() and not path.is_symlink() and sha(path.read_bytes())==ref['sha256'],'extractor source/review file binding')
        final=stage2(stage,raw,proof_ref,analysis_raw,analysis_ref,Path(args.extractor).read_bytes(),Path(args.extractor_review).read_bytes());verify_evaluator_source();out=mkdir_fresh(args.output_dir)
        fresh(out/'manifest.json',stage['manifest_bytes']);fresh(out/'plan.json',stage['plan_bytes']);fresh(out/'runtime.json',final['runtime_bytes']);fresh(out/'protocol.json',final['protocol_bytes']);receipt={'schema':'SI_U1_FINALIZER_STAGE2_V1','status':final['status'],'refs_sha256':args.refs_sha256,'manifest_sha256':final['manifest_sha256'],'plan_sha256':final['plan_sha256'],'runtime_sha256':sha(final['runtime_bytes']),'protocol_sha256':sha(final['protocol_bytes']),'proof_sha256':args.proof_sha256,'analysis_sha256':args.analysis_sha256,'extractor_sha256':args.extractor_sha256,'extractor_review_sha256':args.extractor_review_sha256};fresh(out/'stage2_receipt.json',wire(receipt));print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__':main()
