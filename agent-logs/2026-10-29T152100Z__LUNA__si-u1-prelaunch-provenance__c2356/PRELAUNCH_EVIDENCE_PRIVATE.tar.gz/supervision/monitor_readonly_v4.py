"""One metadata-only monitor sample, never reads scientific event payloads."""
import json,os,subprocess
from datetime import datetime,timezone
from pathlib import Path
here=Path(__file__).resolve().parent;output=Path('/home/lizening/research-notes/agent-logs/2026-10-29T145200Z__LUNA__si-u1-production-preflight-proposal__853/run_parent/evaluation_c2356bbda2b44159a333e7c9d24fc2d4')
def identity(name):
 p=here/name
 if not p.is_file():return None
 x=json.loads(p.read_text());pid=x['pid'];path=Path('/proc')/str(pid)/'stat'
 try:
  fields=path.read_text().rsplit(')',1)[1].split();return {'pid':pid,'expected_tick':x.get('start_tick'),'actual_tick':int(fields[19]),'alive_identity_matches':int(fields[19])==x.get('start_tick'),'state':fields[0],'running':fields[0] != 'Z','zombie':fields[0] == 'Z'}
 except (OSError,ValueError,IndexError):return {'pid':pid,'expected_tick':x.get('start_tick'),'alive_identity_matches':False}
def size(path):return path.stat().st_size if path.is_file() else None
r=subprocess.run(['nvidia-smi','--query-gpu=uuid,memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=15)
row={'utc':datetime.now(timezone.utc).isoformat(),'detached_wrapper':identity('DETACHED_WRAPPER_START.json'),'production_supervisor':identity('SUPERVISOR_START_V4.json'),'wrapper_exit_record_present':(here/'OUTER_EXIT_V4.json').is_file(),'production_exit_record_present':(output/'supervisor_exit.json').is_file(),'event_journal_bytes':size(output/'evaluation/events.jsonl'),'resource_journal_bytes':size(output/'resource.jsonl'),'gpu_returncode':r.returncode,'gpu_devicewide':r.stdout.strip(),'no_outcome_read':True,'no_retry':True}
with (here/'online_monitor_samples.jsonl').open('a') as f:f.write(json.dumps(row,sort_keys=True)+'\n');f.flush();os.fsync(f.fileno())
print(json.dumps(row,sort_keys=True))
