"""One bounded supervised three-arm run; no outcome inspection or retries.

Requires independent live clearance and pre-outcome extraction approval.
The supervisor is a new session. Survival across container/tool shutdown is not assumed.
"""
import hashlib,json,os,signal,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
here=Path(__file__).resolve().parent;root=Path('/home/lizening/wt-si-self-imitation-evaluator');astra=Path('/home/lizening/research-notes/agent-logs/2026-10-29T113523Z__ASTRA__three-arm-prospective-design__a55d1af9');prep=Path('/home/lizening/research-notes/agent-logs/2026-10-29T145200Z__LUNA__si-u1-production-preflight-proposal__853');auth=Path('/home/lizening/wt-si-self-imitation-evaluator/configs/local/si_pilot82_evaluation_authorization_c2356bbda2b44159a333e7c9d24fc2d4.json');review=astra/'PREFLIGHT_C2356_NATIVE_INDEPENDENT_REVIEW.json'
AUTH_SHA='88c28ca282405a6bcfca6452a7b361b09a01d397d4ed8b32f33d4175cf6c5366'; REVIEW_SHA='fd47536759eafe843c2684913265f5c4b79aaeff92a1e613e4b6fb1eba5ea409'; NATIVE_SHA='3c39c2c0b49f400213bc2d4713b575b0b3f13779311e16e5501c4f2aeb7f3e7e'; RECEIPT_SHA='8b948ecdaba08225012ea522cd0309377ab1ffe537931f88e1af91e1e99ffd49';SOURCE='8532275932dabddc498c23a2b6d9a045647542f0'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def put(p,o):
 with Path(p).open('x') as f:json.dump(o,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def utc():return datetime.now(timezone.utc).isoformat()
def call(args,cwd=None):
 p=subprocess.run(args,cwd=cwd,text=True,capture_output=True,timeout=15);return {'argv':args,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'utc':utc()}
def must(v,m):
 if not v:raise SystemExit(m)
must(len(sys.argv)==7,'clearance path/hash, extraction spec path/hash, extraction approval path/hash required')
clear=Path(sys.argv[1]);clear_sha=sys.argv[2];spec=Path(sys.argv[3]);spec_sha=sys.argv[4];approval=Path(sys.argv[5]);approval_sha=sys.argv[6]
must(all(p.is_absolute() for p in (clear,spec,approval)) and sha(clear)==clear_sha and sha(spec)==spec_sha and sha(approval)==approval_sha and sha(auth)==AUTH_SHA and sha(review)==REVIEW_SHA,'authority or review hash mismatch')
a=json.loads(auth.read_text());c=json.loads(clear.read_text());s=json.loads(spec.read_text());ap=json.loads(approval.read_text());rv=json.loads(review.read_text())
must(rv['decision']=='PASS_AUTHENTIC_NATIVE_ZERO_EFFECT_PREFLIGHT_ONLY' and rv['authorization_sha256']==AUTH_SHA and rv['native_execution_sha256']==NATIVE_SHA and rv['preflight_receipt_sha256']==RECEIPT_SHA,'native preflight independent review mismatch')
native=Path(rv['native_execution_path']);receipt=Path(a['receipt_path']);must(sha(native)==NATIVE_SHA and sha(receipt)==RECEIPT_SHA,'native preflight drift')
must(c['schema']=='SI_U1_EVAL_CLEARANCE_V1' and c['decision']=='RELEASE_ONE_THREE_ARM_EVALUATION' and c['authorization_sha256']==AUTH_SHA and c['preflight_receipt_sha256']==RECEIPT_SHA and c['preflight_execution']=={'path':str(native),'sha256':NATIVE_SHA} and c['source_sha']==SOURCE and c['run_id']=='c2356bbda2b44159a333e7c9d24fc2d4' and c['maximum_launches']==1 and c['retry_authorized'] is False,'clearance scope mismatch')
must(all(c[k+'_sha256']==a[k]['sha256'] for k in ('manifest','runtime_spec','review','plan','protocol')),'clearance binding mismatch')
must(s['schema']=='SI_U1_EXTRACTION_SPEC_V1' and s['source_sha']==SOURCE and s['run_output']==a['output_path'] and s['authorization']=={'path':str(auth),'sha256':AUTH_SHA} and s['clearance']=={'path':str(clear),'sha256':clear_sha} and all(s[k]==a[k] for k in ('manifest','runtime_spec','plan','protocol','schedule','analysis')),'extraction spec does not bind exact live artifacts')
must(ap=={'schema':'SI_U1_EXTRACTION_APPROVAL_V1','decision':'APPROVED_FOR_POSTRUN_AUDIT_AND_EXTRACTION','spec_sha256':spec_sha,'extractor_sha256':'c0827b923f518b5d8ddefb73974994d8a445f352fc8bc8b6e99abb88b3df0f7d','source_sha':SOURCE,'stats_sha256':'dc65a06fda495517bc76357022a90a0622d1b17c11ee101e19d958aebb5e3251','reviewer':ap.get('reviewer')} and isinstance(ap['reviewer'],str) and bool(ap['reviewer']),'independent extraction approval missing')
must(sha('/home/lizening/wt-si-u1-result-extractor/si_u1_extract.py')==ap['extractor_sha256'] and sha(s['stats']['path'])==ap['stats_sha256']==s['stats']['sha256'],'extractor or stats drift')
for k in ('manifest','runtime_spec','review','plan','protocol','schedule','analysis'):must(sha(a[k]['path'])==a[k]['sha256'],'frozen binding drift')
head=call(['git','rev-parse','HEAD'],root);status=call(['git','status','--porcelain'],root);must(head['returncode']==0 and head['stdout'].strip()==SOURCE and status['returncode']==0 and not status['stdout'].strip(),'source dirty or changed')
now=datetime.now(timezone.utc); parse=lambda x:datetime.fromisoformat(x.replace('Z','+00:00'));must(parse(c['not_before'])<=now<parse(c['expires'])<=parse(a['expires']),'clearance window');remaining=(min(parse(c['expires']),parse(a['expires']))-now).total_seconds();must(remaining>=43320,'insufficient 12 hour plus 120 second time margin')
output=Path(a['output_path']);claim=output.parent/(output.name+'.launch_claim.json');must(not output.exists() and not output.is_symlink() and not claim.exists() and not claim.is_symlink(),'consumed output or production claim; no retry')
gpu=call(['nvidia-smi','--query-gpu=uuid,memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits']);apps=call(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader,nounits']);rows=[x.split(', ') for x in gpu['stdout'].strip().splitlines() if x.startswith('GPU-b08bc603-ebdb-787d-b5b6-ec796ea3022a,')];must(gpu['returncode']==0 and apps['returncode']==0 and len(rows)==1 and int(rows[0][2])*1048576>=30064771072 and int(rows[0][3])==0 and not apps['stdout'].strip(),'fresh GPU resource check failed')
template=[a['interpreter'],'-I',str(root/'scripts/run_si_transfer_eval.py'),'--live','--authorization',str(auth),'--authorization-sha256','@AUTHORIZATION_SHA256@','--clearance',str(clear),'--clearance-sha256','@CLEARANCE_SHA256@'];must(c['live_argv']==template,'live argv template mismatch');argv=[AUTH_SHA if v=='@AUTHORIZATION_SHA256@' else clear_sha if v=='@CLEARANCE_SHA256@' else v for v in template]

helper_path=here/'process_control_v4.py';helper_bytes=helper_path.read_bytes()
must(hashlib.sha256(helper_bytes).hexdigest()=='716b87f2b6fe301c7cacd63861c163a97339d51a8e6f30f45b0ada75dd0fb1ce','process-control module changed')
import types
helper=types.ModuleType('si_u1_bound_process_control_v4');helper.__file__=str(helper_path)
sys.modules[helper.__name__]=helper
exec(compile(helper_bytes,str(helper_path),'exec'),helper.__dict__)
establish_supervisor=helper.establish_supervisor;bounded_cleanup=helper.bounded_cleanup;supervise_bounded=helper.supervise_bounded;completed_status=helper.completed_status
put(here/'LIVE_DISPATCH_ONCE_V4.json',{'schema':'SI_U1_LUNA_EVALUATION_DISPATCH_V4','utc':utc(),'cwd':str(root),'argv':argv,'environment':a['environment'],'authorization_sha256':AUTH_SHA,'clearance_sha256':clear_sha,'extraction_spec_sha256':spec_sha,'extraction_approval_sha256':approval_sha,'independent_preflight_review_sha256':REVIEW_SHA,'gpu_before':gpu,'compute_apps_before':apps,'remaining_seconds':remaining,'total_cap_seconds':43200,'cleanup_reserve_seconds':10,'arm_cap_seconds':14400,'prior_training_seconds':1800.0549747627228,'prior_engineering_seconds_separate':455.8560599721968,'retry_authorized':False,'automatic_result_extraction':False})
start=time.monotonic();hard_deadline=start+43200;cleanup_start=hard_deadline-10;p=None;rc=None;error=None;cleanup=None;known={};supervisor=None;wrapper_timeout=False;supervisor_receipt=None;receipt_error=None
with (here/'supervisor_v4.stdout').open('xb') as out,(here/'supervisor_v4.stderr').open('xb') as err:
 try:
  p=subprocess.Popen(argv,cwd=root,env=a['environment'],stdout=out,stderr=err,start_new_session=True)
  candidate=establish_supervisor(p.pid,os.getuid(),os.getpid())
  if candidate is None:raise RuntimeError('supervisor identity not proven; no cleanup anchor')
  supervisor=candidate
  put(here/'SUPERVISOR_START_V4.json',{'pid':supervisor.pid,'start_tick':supervisor.start_tick,'pgid':supervisor.pgid,'sid':supervisor.sid,'uid':supervisor.uid,'ppid':supervisor.ppid,'utc':utc(),'argv':argv})
  control=supervise_bounded(p,supervisor,output,hard_deadline,cleanup_start)
  rc=control['returncode'];error=control['error'];wrapper_timeout=control['timed_out'];cleanup=control['cleanup'];known=control['known']
 except BaseException as exc:
  error={'type':type(exc).__name__,'message':str(exc)}
  if supervisor is not None and time.monotonic()<hard_deadline:
   cleanup=bounded_cleanup(supervisor,known,hard_deadline,soft_grace=3.0)
  if p is not None:rc=p.poll()
 if p is not None and supervisor is not None and rc is None and time.monotonic()<hard_deadline:
  try:rc=p.wait(timeout=max(0,hard_deadline-time.monotonic()))
  except subprocess.TimeoutExpired:rc=None
native_exit=output/'supervisor_exit.json'
if native_exit.is_file():
 try:supervisor_receipt=json.loads(native_exit.read_text())
 except (OSError,ValueError) as exc:receipt_error=type(exc).__name__
else:receipt_error='missing'
completed,native_success=completed_status(rc,error,wrapper_timeout,cleanup,supervisor_receipt,AUTH_SHA,time.monotonic()<=hard_deadline)
end={'schema':'SI_U1_LUNA_EVALUATION_OUTER_EXIT_V4','status':'OBSERVED_COMPLETED_AWAIT_INDEPENDENT_AUDIT' if completed else 'INCONCLUSIVE','end_utc':utc(),'elapsed_seconds':time.monotonic()-start,'supervisor_pid':p.pid if p else None,'authentic_returncode':rc,'wrapper_error':error,'outer_deadline_triggered':wrapper_timeout,'bounded_cleanup':cleanup,'native_exit_sha256':sha(native_exit) if native_exit.is_file() else None,'native_exit_read_error':receipt_error,'native_exit_success_verified':native_success,'supervisor_stdout_sha256':sha(here/'supervisor_v4.stdout'),'supervisor_stderr_sha256':sha(here/'supervisor_v4.stderr'),'known_descendants':[vars(i) for i in known.values()],'retry_authorized':False,'automatic_result_extraction':False,'limitations':['OS filesystem/signal operations and container shutdown are not hard real-time guaranteed; missing process or receipt evidence is inconclusive.']}
put(here/'OUTER_EXIT_V4.json',end);print(json.dumps(end));raise SystemExit(0 if completed else 1)
