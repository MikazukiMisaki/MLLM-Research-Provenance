import hashlib,json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
here=Path(__file__).resolve().parent
repo=Path('/home/lizening/wt-si-self-imitation-evaluator')
auth=repo/'configs/local/si_u1_eval_engineering_preflight_53cb282cb1dc472da46dc53fe52a7ff9.json'
clear=Path('/home/lizening/research-notes/agent-logs/2026-10-29T125300Z__CODEX__si-eval-engineering-release__9112/ENGINEERING_CLEARANCE_ONE_SHOT.json')
authhash='5d9845eaecc5732af320b13137bd77d8ce1b174c800064f8760dd286b8f83702';clearhash='115bf68e4337391321e4f9f04da2b603dd4a8f0cffba388dbbb4aa87709647ca'
previous=Path('/home/lizening/research-notes/agent-logs/2026-10-29T122500Z__SOL__si-training-engineering-draft__15e2e62/run_parent/engineering_run_342daf138bc741188ce18550a05f97ed/supervisor_exit.json')
remediation=Path('/home/lizening/research-notes/agent-logs/2026-10-29T124000Z__LUNA__si-u1-remediation-draft__9bbaa12/run_parent/engineering_run_db9c2a798f8a41719cd595ebff05dfb0/supervisor_exit.json')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return h.hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def call(args):
 p=subprocess.run(args,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=15);return {'argv':args,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'utc':now()}
def write(path,obj):
 with path.open('x') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
assert sha(auth)==authhash and sha(clear)==clearhash
A=json.loads(auth.read_text());C=json.loads(clear.read_text());assert A['source_sha']==C['source_sha']=='9112a48df70994ead5df89d8b01d0bde12a4160f' and C['decision']=='RELEASE_ONE_ENGINEERING_ONLY' and C['maximum_launches']==1 and C['retry_authorized'] is False and C['run_id']=='53cb282cb1dc472da46dc53fe52a7ff9'
assert C['authorization_sha256']==authhash and sha(Path(A['receipt_path']))==C['preflight_receipt_sha256']=='54cf1f5fbd4202f331db6fafe1b4d5fc024d4da9671b4d70b3112131a258c53f' and sha(Path(C['preflight_execution']['path']))==C['preflight_execution']['sha256']=='f361a1077ce5247bc715d550e73207f62ebe4423fa372bec3b4f2ad6aeb2ad9f'
assert (datetime.fromisoformat(C['expires'].replace('Z','+00:00'))-datetime.now(timezone.utc)).total_seconds()>=630
assert sha(previous)=='b9c3559966da806b2f25effa4a1478abbe9c30333a490983036f109c48f977ba' and sha(remediation)=='9f11162ae91e3db9505518ee871c97b1c378acd68c5a5f853973e8fe8d5c1e65'
cost=json.loads(previous.read_text())['elapsed_seconds']+json.loads(remediation.read_text())['elapsed_seconds'];assert cost==250.73030943144113 and cost<=1200
assert all(sha(Path(A[k]['path']))==A[k]['sha256']==C[k+'_sha256'] for k in ('candidate','plan','runtime','review'))
plan=json.loads(Path(A['plan']['path']).read_text());assert plan['limits']=={'elapsed_seconds':600,'environment_operations':2,'generations':1,'input_tokens':8192,'output_tokens':16,'per_call_input':8192} and plan['aggregate_engineering_seconds']==1800 and plan['training_reserved_seconds']==1200
candidate=json.loads(Path(A['candidate']['path']).read_text());assert all(sha(Path(p))==v for p,v in candidate['inputs'].items());assert all(sha(Path(candidate['candidate'][k]['path']))==candidate['candidate'][k]['sha256'] for k in ('game','traj_data'))
output=Path(A['output_path']);claim=output.parent/(output.name+'.launch_claim.json');assert not output.exists() and not output.is_symlink() and not claim.exists() and not claim.is_symlink()
head=call(['git','rev-parse','HEAD']);status=call(['git','status','--porcelain']);assert head['returncode']==0 and head['stdout'].strip()==A['source_sha'] and status['returncode']==0 and not status['stdout'].strip()
gpu=call(['nvidia-smi','--query-gpu=uuid,memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits']);apps=call(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader,nounits']);rows=[s.split(', ') for s in gpu['stdout'].strip().splitlines() if s.startswith(A['environment']['CUDA_VISIBLE_DEVICES']+',')];assert gpu['returncode']==apps['returncode']==0 and len(rows)==1 and int(rows[0][2])*1048576>=30064771072 and int(rows[0][3])==0 and not apps['stdout'].strip()
argv=[authhash if s=='@AUTHORIZATION_SHA256@' else clearhash if s=='@CLEARANCE_SHA256@' else s for s in C['live_argv']]
expected=[A['interpreter'],'-I',str(repo/'scripts/run_si_transfer_engineering.py'),'--live','--authorization',str(auth),'--authorization-sha256',authhash,'--clearance',str(clear),'--clearance-sha256',clearhash];assert argv==expected
write(here/'ONE_SHOT_DISPATCH.json',{'schema':'SI_U1_LUNA_EVAL_ENGINEERING_DISPATCH_V1','utc':now(),'cwd':str(repo),'argv':argv,'environment':A['environment'],'source_sha':A['source_sha'],'authorization_sha256':authhash,'clearance_sha256':clearhash,'prior_training_engineering_seconds':cost,'evaluation_allocation_seconds':600,'candidate_inputs_and_game_hashes_match':True,'gpu_before_devicewide':gpu,'compute_apps_before':apps,'retry_authorized':False})
start=time.monotonic();proc=None;rc=None;err=None
with (here/'launcher.stdout').open('xb') as out,(here/'launcher.stderr').open('xb') as stderr,(here/'gpu_samples.jsonl').open('x') as monitor:
 try:
  proc=subprocess.Popen(argv,cwd=repo,env=A['environment'],stdout=out,stderr=stderr,start_new_session=True);write(here/'LAUNCHER_START.json',{'pid':proc.pid,'utc':now(),'argv':argv})
  while proc.poll() is None:
   sample=call(['nvidia-smi','--query-gpu=uuid,memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits']);monitor.write(json.dumps(sample,sort_keys=True)+'\n');monitor.flush();time.sleep(10)
  rc=proc.wait()
 except BaseException as exc:
  err={'type':type(exc).__name__,'message':str(exc)}
  if proc is not None and proc.poll() is None:
   proc.terminate()
   try:rc=proc.wait(timeout=10)
   except subprocess.TimeoutExpired:proc.kill();rc=proc.wait()
receipt={'schema':'SI_U1_LUNA_EVAL_ENGINEERING_LAUNCHER_V1','end_utc':now(),'elapsed_seconds':time.monotonic()-start,'supervisor_pid':proc.pid if proc else None,'authentic_returncode':rc,'wrapper_error':err,'launcher_stdout_sha256':sha(here/'launcher.stdout'),'launcher_stderr_sha256':sha(here/'launcher.stderr'),'gpu_samples_sha256':sha(here/'gpu_samples.jsonl'),'gpu_after':call(['nvidia-smi','--query-gpu=uuid,memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits']),'compute_apps_after':call(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader,nounits']),'retry_authorized':False}
write(here/'LAUNCHER_EXIT.json',receipt);print(json.dumps(receipt));raise SystemExit(0 if rc==0 and err is None else 1)
