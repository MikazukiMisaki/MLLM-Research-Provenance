"""Single full DEV episode with explicit policy-format failure outcomes.

Derived from the prior authored DEV episode interface. It does not construct a
model or environment on import, and it leaves the frozen parser and actor as
supplied by the caller.
"""

import json


def episode(*, arm, controller, env_factory, load_producer, source_worker,
            projection, parser, parse_value, state_factory, expected_game,
            expected_eos, expected_pad, previous_initial=None):
    env = producer = None
    history = []
    steps = 0
    try:
        def construct_owned():
            nonlocal env
            env = env_factory()
            return env

        env = controller.effect("env_construct", construct_owned, lambda _: {"arm": arm})
        controller.effect("env_init", env.initialize, lambda _: {"arm": arm})
        reset = controller.effect("reset", env.reset, lambda x: {
            "arm": arm, "state": x[0].to_dict(), "gamefile": x[1],
            "candidate_native_reset": x[2].get("candidate_native_reset")
            if len(x) == 3 and type(x[2]) is dict else None,
        })
        if type(reset) is not tuple or len(reset) != 3 or type(reset[2]) is not dict:
            raise ValueError("native reset unknown")
        state, game = reset[:2]
        native = reset[2].get("candidate_native_reset")
        if (type(native) is not dict or native.get("won_batch") != [False]
                or type(native["won_batch"][0]) is not bool):
            raise ValueError("native reset won unknown")
        if game != expected_game or state.ended:
            raise ValueError("evaluation game identity")
        initial = state.to_dict()
        if previous_initial is not None and json.dumps(
                initial, sort_keys=True, separators=(",", ":"), allow_nan=False
        ) != json.dumps(previous_initial, sort_keys=True, separators=(",", ":"),
                        allow_nan=False):
            raise ValueError("public initial state mismatch; hidden state unproven")

        def load_owned():
            nonlocal producer
            producer = load_producer(arm)
            return producer

        producer = controller.effect("model_load", load_owned, lambda _: {"arm": arm})

        def finish(*, won, termination, decisions, failure=None):
            result = {"arm": arm, "initial_public": initial, "won": won,
                      "steps": steps, "decisions": decisions,
                      "termination": termination}
            if failure is not None:
                result["policy_failure"] = failure
            controller.journal.emit("pilot_episode_result", result)
            return result

        while steps < 50:
            public = projection(state, history)
            valid = state.valid_actions
            mapping = public["action_map"]
            if not valid or len(set(valid)) != len(valid) or list(mapping.values()) != list(valid):
                raise ValueError("ambiguous action mapping")
            try:
                generated = source_worker._generation(producer, public, controller,
                                                      expected_eos, expected_pad)
            except ValueError as error:
                # These two exact cases arise after the generation return and
                # sequence have been journaled by the unchanged source port.
                # All other producer, device, logging, and shape errors remain
                # technical UNKNOWN and stop the batch.
                if str(error) not in ("earlier EOS in output",
                                      "padding or ambiguous EOS/padding in output"):
                    raise
                return finish(won=False, termination="POLICY_FAILURE",
                              decisions=steps + 1,
                              failure={"generation_output_error": str(error)})
            selection = parse_value(parser(generated["raw"], valid))
            controller.journal.emit("dev_parser_returned", {
                "arm": arm, "index": steps, "result": selection,
                "eos_last": generated["eos_last"],
                "output_ids": generated["output_ids"], "raw": generated["raw"],
                "decoder_stop_reason": "NOT_OBSERVED",
            })
            status = selection.get("selection_status")
            action = selection.get("action")
            action_id = selection.get("action_id")
            if status == "selected":
                if mapping.get(action_id) != action:
                    raise ValueError("selected action disagrees with saved action mapping")
            elif status not in ("action_format_violation", "action_out_of_range"):
                raise ValueError("parser or environment mapping failure")
            if not generated["eos_last"] or status != "selected":
                return finish(won=False, termination="POLICY_FAILURE", decisions=steps + 1,
                              failure={"eos_last": generated["eos_last"],
                                       "selection_status": status})
            transition = controller.effect("step", lambda: env.step(action), lambda value: {
                "arm": arm, "index": steps, "action_id": action_id, "action": action,
                "transition": source_worker._transition_wire(value),
            })
            wire = source_worker._transition_wire(transition)
            steps += 1
            history.append((state.observation, action))
            controller.journal.emit("dev_decision_committed", {
                "arm": arm, "index": steps - 1, "action": action, "transition": wire,
            })
            if wire["truncated"] or (wire["won"] and not wire["done"]):
                raise ValueError("unknown or inconsistent terminal")
            if wire["done"]:
                return finish(won=wire["won"], termination="TERMINAL", decisions=steps)
            if wire["valid_actions"] is None:
                raise ValueError("missing next action map")
            state = state_factory(state, wire)
        return finish(won=False, termination="HORIZON", decisions=steps)
    finally:
        errors = []
        for name, obj in (("environment", env), ("producer", producer),
                          ("resource", getattr(producer, "resource", None))):
            if obj is None:
                continue
            try:
                controller.journal.emit(name + "_close_started", {"arm": arm})
            except BaseException as error:
                errors.append(error)
            try:
                obj.close()
                try:
                    controller.journal.emit(name + "_close_returned", {"arm": arm})
                except BaseException as error:
                    errors.append(error)
            except BaseException as error:
                errors.append(error)
                try:
                    controller.journal.emit(name + "_close_unknown", {"arm": arm})
                except BaseException:
                    pass
        if errors:
            raise RuntimeError("one or more cleanup operations UNKNOWN") from errors[0]
