import ast,copy,dataclasses,hashlib,importlib.machinery,os,py_compile,signal,subprocess,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
from process_control_v4 import Identity,read_identity,state,snapshot_descendants,signal_scoped,bounded_cleanup,completed_status,supervise_bounded,establish_supervisor

class GuardTests(unittest.TestCase):
 def test_pid_reused_or_disappeared_never_signalled(self):
  old=Identity(1234,11,2000,1234,1234,1);new=Identity(1234,12,2000,1234,1234,1);sent=[];events=[]
  with patch('process_control_v4.read_identity',return_value=(new,'S')):self.assertFalse(signal_scoped(old,signal.SIGKILL,events,lambda *a:sent.append(a)))
  with patch('process_control_v4.read_identity',return_value=(None,'gone')):self.assertFalse(signal_scoped(old,signal.SIGKILL,events,lambda *a:sent.append(a)))
  self.assertEqual(sent,[]);self.assertEqual([x['state_before'] for x in events],['mismatch','gone'])
 def test_uid_session_or_group_mismatch_never_signalled(self):
  old=Identity(1234,11,2000,1234,1234,1)
  for i in (Identity(1234,11,2001,1234,1234,1),Identity(1234,11,2000,999,1234,1),Identity(1234,11,2000,1234,999,1)):
   with patch('process_control_v4.read_identity',return_value=(i,'S')):self.assertFalse(signal_scoped(old,signal.SIGKILL,[],lambda *a:self.fail('must not signal')))
 def test_identity_changes_after_pidfd_open_no_signal(self):
  old=Identity(1234,11,2000,1234,1234,1);events=[]
  with patch('process_control_v4.state',side_effect=['alive','mismatch']),patch('process_control_v4.pidfd_open',side_effect=lambda p:os.open('/dev/null',os.O_RDONLY)):
   self.assertFalse(signal_scoped(old,signal.SIGKILL,events,lambda *a:self.fail('must not signal'))) 
  self.assertEqual(events[0]['state_before'],'mismatch')
 def test_pidfd_unavailable_refuses_signal(self):
  old=Identity(1234,11,2000,1234,1234,1);events=[]
  with patch('process_control_v4.state',return_value='alive'),patch('process_control_v4.pidfd_open',side_effect=OSError('unsupported')):
   self.assertFalse(signal_scoped(old,signal.SIGKILL,events,lambda *a:self.fail('must not signal')))
  self.assertEqual(events[0]['state_before'],'pidfd_unavailable_or_gone')
 def test_zombie_is_not_running_nor_success_wait_code(self):
  i=Identity(1234,11,2000,1234,1234,1)
  with patch('process_control_v4.read_identity',return_value=(i,'Z')):
   self.assertEqual(state(i),'zombie');self.assertFalse(signal_scoped(i,signal.SIGKILL,[],lambda *a:self.fail('must not signal')))
 def test_expired_deadline_returns_unknown_without_signalling(self):
  i=Identity(1234,11,2000,1234,1234,1)
  with patch('process_control_v4.snapshot_descendants',return_value={}),patch('process_control_v4.state',return_value='alive'),patch('process_control_v4.os.kill') as kill:
   r=bounded_cleanup(i,{},time.monotonic()-1);self.assertTrue(r['unknown_or_unresolved']);kill.assert_not_called()
 def test_missing_receipt_never_reports_completed(self):
  self.assertEqual(completed_status(0,None,False,None,None,'a',True),(False,False))
  receipt={'execution_status':'EXIT_RECORDED','authentic_returncode':0,'cleanup_established':True,'within_time_cap':True,'retry_authorized':False,'authorization_sha256':'a'}
  self.assertEqual(completed_status(None,None,False,None,receipt,'a',True),(False,True))
  self.assertEqual(completed_status(0,None,True,None,receipt,'a',True),(False,True))
  self.assertEqual(completed_status(0,None,False,None,receipt,'a',True),(True,True))
  self.assertEqual(completed_status(False,None,False,None,receipt,'a',True),(False,True))
  receipt['authentic_returncode']=False
  self.assertEqual(completed_status(0,None,False,None,receipt,'a',True),(False,False))
  for malformed in ([],[1],1,False,'text',None,{}):self.assertEqual(completed_status(0,None,False,None,malformed,'a',True),(False,False))
 def test_actual_wrapper_execs_hashed_bytes_ignores_poisoned_matching_pyc(self):
  wrapper=ast.parse((Path(__file__).parent/'launch_three_arm_v4.py').read_text());start=next(i for i,n in enumerate(wrapper.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='helper_path' for t in n.targets));nodes=copy.deepcopy(wrapper.body[start:start+8]);compiled=compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'actual-bound-loader','exec')
  real=(Path(__file__).parent/'process_control_v4.py').read_bytes();evil=b'raise RuntimeError("PYC_POISON_EXECUTED")\n';self.assertLess(len(evil),len(real));evil=evil+b' '*(len(real)-len(evil))
  with tempfile.TemporaryDirectory() as tmp:
   helper=Path(tmp)/'process_control_v4.py';helper.write_bytes(evil);os.utime(helper,(1700000000,1700000000));py_compile.compile(str(helper),doraise=True,invalidation_mode=py_compile.PycInvalidationMode.TIMESTAMP);helper.write_bytes(real);os.utime(helper,(1700000000,1700000000))
   # Demonstrate that the matching timestamp/size pyc would poison ordinary loading.
   with self.assertRaisesRegex(RuntimeError,'PYC_POISON_EXECUTED'):exec(importlib.machinery.SourceFileLoader('poison_demo',str(helper)).get_code('poison_demo'),{})
   before=list(sys.path);ns={'here':Path(tmp),'hashlib':hashlib,'sys':sys,'must':lambda value,msg:None if value else self.fail(msg)};name='si_u1_bound_process_control_v4';previous=sys.modules.get(name)
   try:exec(compiled,ns);self.assertTrue(callable(ns['helper'].completed_status));self.assertEqual(sys.path,before);self.assertFalse(ns['helper'].completed_status(0,None,False,None,[1],'a',True)[0])
   finally:
    if previous is None:sys.modules.pop(name,None)
    else:sys.modules[name]=previous
  print('POISONED_MATCHING_PYC_RECEIPT standard_loader_poisoned=true bound_bytes_loader_safe=true sys_path_unchanged=true')
 def test_control_exception_returns_inconclusive_with_cleanup(self):
  p=type('FakeProcess',(),{'poll':lambda self:None,'wait':lambda self,timeout:None})()
  i=Identity(1234,11,2000,1234,1234,1)
  with tempfile.TemporaryDirectory() as tmp,patch('process_control_v4.snapshot_descendants',side_effect=OSError('proc unavailable')),patch('process_control_v4.bounded_cleanup',return_value={'cleanup_confirmed':False,'unknown_or_unresolved':True}):
   r=supervise_bounded(p,i,Path(tmp),time.monotonic()+.2,time.monotonic()+.1)
  self.assertEqual(r['error']['type'],'OSError');self.assertTrue(r['cleanup']['unknown_or_unresolved']);self.assertFalse(completed_status(r['returncode'],r['error'],r['timed_out'],r['cleanup'],None,'a',True)[0])
 def test_no_runtime_gpu_sampling_or_unbounded_wait(self):
  source=(Path(__file__).parent/'launch_three_arm_v4.py').read_text();tail=source.split('start=time.monotonic();hard_deadline=',1)[1];self.assertNotIn('nvidia-smi',tail)
  tree=ast.parse(tail); waits=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='wait'];self.assertTrue(waits);self.assertTrue(all(any(k.arg=='timeout' for k in n.keywords) for n in waits))
 def test_prelaunch_sampling_timeout_cannot_launch(self):
  source=(Path(__file__).parent/'launch_three_arm_v4.py').read_text();m=ast.parse(source);fn=next(n for n in m.body if isinstance(n,ast.FunctionDef) and n.name=='call');mod=ast.Module(body=[fn],type_ignores=[]);ns={'subprocess':subprocess,'utc':lambda:'test'};exec(compile(mod,'call-only','exec'),ns)
  with patch('subprocess.run',side_effect=subprocess.TimeoutExpired('nvidia-smi',15)),patch('subprocess.Popen') as launch:
   with self.assertRaises(subprocess.TimeoutExpired):ns['call'](['nvidia-smi'])
   launch.assert_not_called()

class RealProcessTests(unittest.TestCase):
 def wait_ready(self,p,path):
  until=time.monotonic()+5
  while time.monotonic()<until and not path.exists():
   if p.poll() is not None:self.fail('fixture terminated early')
   time.sleep(.02)
  self.assertTrue(path.exists())
 def test_actual_wrapper_initialization_bad_owner_never_cleans_real_cpu_process(self):
  source=ast.parse((Path(__file__).parent/'launch_three_arm_v4.py').read_text())
  t=next(n for n in ast.walk(source) if isinstance(n,ast.Try) and any(isinstance(z,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='candidate' for v in z.targets) for z in n.body))
  # Exercise the actual wrapper's candidate/validation/anchor nodes and exception handler.
  tiny=copy.deepcopy(t);tiny.body=tiny.body[1:4];tiny.orelse=[];tiny.finalbody=[];module=ast.fix_missing_locations(ast.Module(body=[tiny],type_ignores=[]));compiled=compile(module,'actual-wrapper-initialization','exec')
  p=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)'],start_new_session=True)
  try:
   original,status=read_identity(p.pid);self.assertIsNotNone(original)
   for field in ('uid','ppid','pgid','sid'):
    invalid=dataclasses.replace(original,**{field:getattr(original,field)+1});calls=[]
    ns={'p':p,'os':os,'time':time,'hard_deadline':time.monotonic()+2,'supervisor':None,'known':{},'rc':None,'cleanup':None,'error':None,'establish_supervisor':establish_supervisor,'bounded_cleanup':lambda *a,**k:calls.append(a)}
    with patch('process_control_v4.read_identity',return_value=(invalid,'S')):exec(compiled,ns)
    self.assertIsNone(ns['supervisor']);self.assertEqual(calls,[]);self.assertEqual(ns['error']['type'],'RuntimeError');self.assertIsNone(p.poll())
   print('INVALID_WRAPPER_OWNERSHIP_RECEIPT cases=4 cleanup_calls=0 process_still_alive=true')
  finally:
   p.terminate();p.wait(timeout=2)
 def test_three_sessions_supervisor_ignores_sigint_and_bounded_cleanup(self):
  with tempfile.TemporaryDirectory() as tmp:
   ready=Path(tmp)/'ready'; code='''import os,signal,subprocess,sys,time\nsignal.signal(signal.SIGINT,signal.SIG_IGN);signal.signal(signal.SIGTERM,signal.SIG_IGN)\nworker="import os,signal,subprocess,sys,time; signal.signal(signal.SIGINT,signal.SIG_IGN); signal.signal(signal.SIGTERM,signal.SIG_IGN); g=subprocess.Popen([sys.executable,\\\"-c\\\",\\\"import time; time.sleep(60)\\\"],start_new_session=True); open(sys.argv[1],\\\"w\\\").write(str(g.pid)); time.sleep(60)"\nsubprocess.Popen([sys.executable,"-c",worker,sys.argv[1]],start_new_session=True)\ntime.sleep(60)'''
   p=subprocess.Popen([sys.executable,'-c',code,str(ready)],start_new_session=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
   try:
    self.wait_ready(p,ready);root,_=read_identity(p.pid);self.assertIsNotNone(root);known={};snapshot_descendants([root],known);self.assertGreaterEqual(len(known),2);self.assertGreaterEqual(len({i.sid for i in [root,*known.values()]}),3)
    began=time.monotonic();r=supervise_bounded(p,root,Path(tmp),began+2,began+.1,poll_interval=.01,soft_grace=.1,term_grace=.1);self.assertLess(time.monotonic()-began,2.3);self.assertTrue(r['timed_out']);self.assertIsNotNone(r['returncode']);self.assertTrue(r['cleanup']['cleanup_confirmed'],r);self.assertTrue(any(x['signal']==signal.SIGKILL and x['sent'] for x in r['cleanup']['signals']));print('THREE_SESSION_CONTROL_RECEIPT',r['returncode'],r['timed_out'],r['cleanup']['cleanup_confirmed'],len(r['known']))
   finally:
    if p.poll() is None:p.kill();p.wait(timeout=2)
    p.stderr.close()
 def test_supervisor_already_dead_known_worker_still_cleaned(self):
  with tempfile.TemporaryDirectory() as tmp:
   ready=Path(tmp)/'ready';code='''import subprocess,sys,time\np=subprocess.Popen([sys.executable,"-c","import time;time.sleep(60)"],start_new_session=True)\nopen(sys.argv[1],"w").write(str(p.pid))\ntime.sleep(1)'''
   p=subprocess.Popen([sys.executable,'-c',code,str(ready)],start_new_session=True)
   try:
    self.wait_ready(p,ready);root,_=read_identity(p.pid);known={};snapshot_descendants([root],known);self.assertTrue(known);p.wait(timeout=3)
    started=time.monotonic();r=bounded_cleanup(root,known,started+2,soft_grace=.05,poll_interval=.01);self.assertLess(time.monotonic()-started,2.3);self.assertTrue(r['cleanup_confirmed'],r);self.assertTrue(any(x['pid']==root.pid and not x['sent'] for x in r['signals']))
   finally:
    if p.poll() is None:p.kill();p.wait(timeout=2)

if __name__=='__main__':unittest.main(verbosity=2)
