#!/usr/bin/env python3
"""One-shot evidence wrapper; never invokes science or an automatic retry."""
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/home/lizening/wt-si-self-imitation-train')
HERE = Path(__file__).resolve().parent
AUTH = ROOT / 'configs/local/si_u1_train_engineering_342daf138bc741188ce18550a05f97ed.json'
AUTH_HASH = 'd2dd951b2b139d5859d22083afb4cee627a075a011c811e2914bf9e8910b2099'
SOURCE = '15e2e62ec5be4817622be5538ee2b657faae7928'
PREFLIGHT_HASH = '788c2e51546ae0ff3dee657f8058e1735708a38a84e65b1b022017dcfe7f33f0'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def now():
    return datetime.now(timezone.utc).isoformat()

def run_readonly(argv):
    p = subprocess.run(argv, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
    return {'argv': argv, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr, 'utc': now()}

def fresh_json(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())

def main():
    if len(sys.argv) != 3:
        raise SystemExit('expected clearance path and SHA256')
    clearance_path = Path(sys.argv[1])
    clearance_hash = sys.argv[2]
    if not clearance_path.is_absolute() or sha(clearance_path) != clearance_hash or sha(AUTH) != AUTH_HASH:
        raise SystemExit('bound clearance or authorization hash mismatch')
    auth = json.loads(AUTH.read_text())
    clearance = json.loads(clearance_path.read_text())
    preflight = Path(auth['preflight_path'])
    preflight_value = json.loads(preflight.read_text())
    expected = {'schema': 'SI_CONTINUATION_ENGINEERING_CLEARANCE_V1', 'decision': 'RELEASE_ONE_ENGINEERING_RUN', 'binding': preflight_value['binding'], 'preflight_sha256': PREFLIGHT_HASH, 'maximum_launches': 1, 'retry_authorized': False}
    if clearance != expected or sha(preflight) != PREFLIGHT_HASH or preflight_value['status'] != 'PREFLIGHT_ONLY_PASS':
        raise SystemExit('clearance or preflight binding mismatch')
    if auth['source_sha'] != SOURCE or auth['allocation_seconds'] != 1200 or auth['maximum_launches'] != 1:
        raise SystemExit('scope drift')
    output = Path(auth['output_path'])
    if output.exists() or output.with_name(output.name + '.claim.json').exists():
        raise SystemExit('output or claim already exists; no retry')
    head = run_readonly(['git', 'rev-parse', 'HEAD'])
    status = run_readonly(['git', 'status', '--porcelain'])
    gpu = run_readonly(['nvidia-smi', '--query-gpu=uuid,memory.used,memory.free,utilization.gpu', '--format=csv,noheader,nounits'])
    apps = run_readonly(['nvidia-smi', '--query-compute-apps=pid,process_name,used_gpu_memory', '--format=csv,noheader,nounits'])
    if head['returncode'] or head['stdout'].strip() != SOURCE or status['returncode'] or status['stdout'].strip():
        raise SystemExit('source checkout drift')
    matches = [r.strip().split(', ') for r in gpu['stdout'].splitlines() if r.startswith(auth['gpu']['uuid'] + ',')]
    if gpu['returncode'] or apps['returncode'] or len(matches) != 1 or int(matches[0][2]) * 1048576 < auth['gpu']['preweight_free_bytes']:
        raise SystemExit('fresh shared GPU preweight headroom check failed')
    argv = [auth['interpreter'], '-I', str(ROOT / 'scripts/run_si_continuation_engineering.py'), '--live', '--authorization', str(AUTH), '--authorization-sha256', AUTH_HASH, '--clearance', str(clearance_path), '--clearance-sha256', clearance_hash]
    start = {'schema': 'SI_U1_LUNA_ONE_SHOT_DISPATCH_V1', 'started_utc': now(), 'cwd': str(ROOT), 'argv': argv, 'environment': auth['environment'], 'auth_sha256': AUTH_HASH, 'clearance_sha256': clearance_hash, 'preflight_sha256': PREFLIGHT_HASH, 'source_sha': SOURCE, 'gpu_before': gpu, 'compute_apps_before': apps, 'maximum_launches': 1, 'retry_authorized': False, 'evidence_class': 'engineering_only'}
    fresh_json(HERE / 'ONE_SHOT_DISPATCH.json', start)
    t0 = time.monotonic()
    process = None
    error = None
    rc = None
    with (HERE / 'launcher.stdout').open('xb') as stdout, (HERE / 'launcher.stderr').open('xb') as stderr, (HERE / 'gpu_samples.jsonl').open('x') as samples:
        try:
            process = subprocess.Popen(argv, cwd=ROOT, env=auth['environment'], stdout=stdout, stderr=stderr, start_new_session=True)
            fresh_json(HERE / 'LAUNCHER_START.json', {'pid': process.pid, 'started_utc': now(), 'argv': argv})
            while process.poll() is None:
                snapshot = run_readonly(['nvidia-smi', '--query-gpu=uuid,memory.used,memory.free,utilization.gpu', '--format=csv,noheader,nounits'])
                samples.write(json.dumps(snapshot, sort_keys=True) + '\n')
                samples.flush()
                time.sleep(10)
            rc = process.wait()
        except BaseException as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    rc = process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    rc = process.wait()
        finally:
            stdout.flush(); stderr.flush(); samples.flush()
    done = {'schema': 'SI_U1_LUNA_ONE_SHOT_PROCESS_RECEIPT_V1', 'ended_utc': now(), 'elapsed_seconds': time.monotonic() - t0, 'supervisor_pid': process.pid if process else None, 'authentic_returncode': rc, 'wrapper_error': error, 'retry_authorized': False, 'launcher_stdout_sha256': sha(HERE / 'launcher.stdout'), 'launcher_stderr_sha256': sha(HERE / 'launcher.stderr'), 'gpu_samples_sha256': sha(HERE / 'gpu_samples.jsonl'), 'gpu_after': run_readonly(['nvidia-smi', '--query-gpu=uuid,memory.used,memory.free,utilization.gpu', '--format=csv,noheader,nounits']), 'compute_apps_after': run_readonly(['nvidia-smi', '--query-compute-apps=pid,process_name,used_gpu_memory', '--format=csv,noheader,nounits'])}
    fresh_json(HERE / 'LAUNCHER_EXIT.json', done)
    print(json.dumps(done))
    return 0 if rc == 0 and error is None else 1

if __name__ == '__main__':
    raise SystemExit(main())
