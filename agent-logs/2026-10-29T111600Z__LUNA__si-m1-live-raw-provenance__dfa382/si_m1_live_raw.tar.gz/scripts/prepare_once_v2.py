#!/usr/bin/env python3
"""Create static, one-use SI-M1 authorization only after authentic review.
Does not run preflight, supervisor, CUDA, models, or environment. """
import argparse, hashlib, json, os, secrets, subprocess, tempfile
from pathlib import Path
from datetime import datetime, timedelta, timezone

ROOT = Path('/home/lizening/wt-si-five-case-probe')
SOURCE_SHA = 'dfa382ad0ab604746690e96537dc4009cfeeefd0'
CONTRACT_SHA = 'a0a17e9f28217e10d6913a9de1050b52be68be9c0b6c6ea27f627e820c1755ae'
DESIGN_SHA = 'c1c8e3eca3b812f633c4cb2531533fc5a2785bc3870ae5c7f5095deb5f4abeb2'
RESOURCE_SHA = 'd908573f0c6d9518aec0a9b6b0a48c24648a26c3c708652b185a7cfe7b7e2489'
PROPOSAL = ROOT/'configs/local/si_m1_single_step_proposal_draft.json'
PROPOSAL_SHA = 'caf6325dcb2498508c5988588210d8d074895bee95443a0f15b3755aed0d15c7'
ENV_FILE = ROOT/'configs/local/si_m1_environment_draft.json'
ENV_SHA = 'cdf54a787e67a7b3acf5f95fd25b87cff53599578d16cce836a5b13fe82ab7d6'
LIMITS = {'generations':10,'environment_operations':65,'generated_tokens':280,'input_tokens':81920,'per_call_input':8192,'device_hours':0.5}
CLAIMS = {'scientific_execution_behavior_changed':True,'offline_evidence_validation_behavior_changed':True,'source_treatment_semantics_changed':False,'exclusive_gpu':False,'NVML_to_local_PID_mapping':'UNPROVEN_NOT_ASSERTED','whole_process_vram_cap':False,'device_wide_delta_attribution':False}

def sha(path):
 return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(condition, message):
 if not condition: raise ValueError(message)
def raw_json(path,expected):
 require(sha(path)==expected, f'bytes differ: {path}')
 return json.loads(Path(path).read_bytes())
def iso(t): return t.strftime('%Y-%m-%dT%H:%M:%SZ')
def fresh(path, obj):
 raw=(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 try:
  with os.fdopen(fd,'wb') as h: h.write(raw);h.flush();os.fsync(h.fileno())
 except BaseException:
  raise
 return hashlib.sha256(raw).hexdigest()

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--review',required=True,type=Path)
 parser.add_argument('--review-sha256',required=True)
 args=parser.parse_args(); os.umask(0o077)
 require(args.review.is_absolute() and args.review==args.review.resolve(),'canonical absolute review path')
 sha_now=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
 clean=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)==''
 require(sha_now==SOURCE_SHA and clean,'candidate changed or dirty')
 raw_json(ROOT/'configs/experiments/si_m1_single_step_v1.json',CONTRACT_SHA)
 policy=raw_json(ROOT/'configs/experiments/si_s01_shared_resource_v1.json',RESOURCE_SHA)
 resource={'policy':'SHARED_CONTAINER_CUDA_V1','contract_sha256':RESOURCE_SHA,'proposal_sha256':policy['proposal_sha256'],**CLAIMS}
 expected_review={'schema':'SI_M1_INDEPENDENT_REVIEW_V1','source_sha':SOURCE_SHA,'contract_sha256':CONTRACT_SHA,'design_sha256':DESIGN_SHA,'decision':'PASS_SOFTWARE_ONLY','reviewer_role':'ASTRA_MAIN','resource_policy':resource}
 require(raw_json(args.review,args.review_sha256)==expected_review,'review artifact does not pass exact gate schema')
 proposal=raw_json(PROPOSAL,PROPOSAL_SHA);environment=raw_json(ENV_FILE,ENV_SHA)['environment']
 require(proposal['case_bindings_sha256']=='b9c41266ae153600571a139e1ae14128ff28417114b68102fb51b854a94be864','frozen cases')
 require(environment['CUDA_VISIBLE_DEVICES']=='GPU-b08bc603-ebdb-787d-b5b6-ec796ea3022a','frozen current GPU identity must still be checked at execution')
 require(not any(x in environment for x in ('PYTHONPATH','PYTHONHOME','LD_PRELOAD','PYTORCH_NO_CUDA_MEMORY_CACHING','PYTORCH_NO_HIP_MEMORY_CACHING')),'forbidden env keys')
 aid,runid=secrets.token_hex(16),secrets.token_hex(16)
 parent=Path(tempfile.mkdtemp(prefix=f'si_m1_uid-{os.getuid()}_run-{runid}_',dir='/tmp')).resolve()
 parent.chmod(0o700);control=parent/'control';control.mkdir(mode=0o700)
 auth=(ROOT/'configs/local'/f'si_m1_authorization_{aid}.json').resolve()
 output=parent/'output';receipt=control/'preflight_receipt.json'
 script=(ROOT/'scripts/run_si_m1_probe.py').resolve()
 prefix=[proposal['interpreter']['path'],'-I',str(script)]
 def argv(flag): return prefix+[flag,'--authorization',str(auth),'--authorization-sha256','@AUTHORIZATION_SHA256@','--proposal',str(PROPOSAL)]
 now=datetime.now(timezone.utc)
 a={'schema':'SI_M1_AUTHORIZATION_V1','status':'PREFLIGHT_ONLY','purpose':'FIVE_SINGLE_STEP_PROBE','contract_sha256':CONTRACT_SHA,'design_sha256':DESIGN_SHA,'source_sha':SOURCE_SHA,'review':{'path':str(args.review),'sha256':args.review_sha256},'proposal_sha256':PROPOSAL_SHA,'authorization_id':aid,'run_id':runid,'evidence_class':'live_single_step_probe','execution_uid':os.getuid(),'output_path':str(output),'ceilings':LIMITS,'gpu_uuid':environment['CUDA_VISIBLE_DEVICES'],'environment':environment,'not_before_utc':iso(now-timedelta(seconds=5)),'expires_utc':iso(now+timedelta(hours=2)),'preflight_receipt_path':str(receipt),'preflight_argv':argv('--preflight-only'),'launch_argv':argv('--live'),'maximum_launches':1,'resource_policy':resource}
 digest=fresh(auth,a)
 metadata={'status':'STATIC_AUTHORIZATION_CREATED_NOT_PREFLIGHT_OR_LIVE','authorization_path':str(auth),'authorization_sha256':digest,'run_id':runid,'private_parent':str(parent),'control_path':str(control),'output_path':str(output),'preflight_receipt_path':str(receipt),'expires_utc':a['expires_utc'],'next_step':'independent review then production preflight; no live clearance yet'}
 fresh(control/'preparation_receipt.json',metadata)
 print(json.dumps(metadata,sort_keys=True))
if __name__=='__main__': main()
