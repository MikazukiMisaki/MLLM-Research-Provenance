import hashlib,json,os,pathlib,subprocess,datetime,time
E=pathlib.Path(__file__).resolve().parent
A=pathlib.Path('/home/lizening/research-notes/agent-logs/2026-10-29T113523Z__ASTRA__three-arm-prospective-design__a55d1af9')
R=pathlib.Path('/home/lizening/research-notes/agent-logs/2026-10-29T143500Z__SOL__si-u1-final-construction-plan__616f1e4/REFS_FROZEN.json')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,d):
 with open(p,'x',encoding='utf-8') as f: json.dump(d,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def verify(p,h):
 p=pathlib.Path(p);assert p.is_file() and not p.is_symlink() and sha(p)==h,str(p);return json.loads(p.read_text())
review=verify(A/'CONSTRUCTION_REPAIR3DA_206_INDEPENDENT_REVIEW.json','f03e559f931fba3ab5791b12b40f5c6951e73f9ddb2fe4339b914b9a26e37e9b')
assert review['schema']=='ASTRA_CONSTRUCTION_REPAIR_REVIEW_V1' and review['decision']=='PASS_CANDIDATE_CONSTRUCTION_SOFTWARE_ONLY' and review['builder_commit']=='3da63f4e3b0150c3ebb681a0d66dd87c22f7c3aa' and review['bootstrap_commit']=='2060cc8a20dfc6dafa3b4053043f6eab67ef7410'
assert sha('/home/lizening/wt-si-u1-finalizer-bootstrap/bootstrap.py')==review['bootstrap_sha256']
assert sha('/home/lizening/wt-si-u1-eval-artifact-builder/builder.py')==review['builder_sha256']
assert sha('/home/lizening/wt-si-u1-eval-artifact-builder/finalizer.py')==review['finalizer_unchanged_sha256']
assert sha('/home/lizening/miniconda3/envs/alfworld-self-improve/bin/python3.10')=='560aa01150e792ac8efc5f0e55db51e7175623437a2c2d7e62b2ec2cd9973449'
refs=verify(R,'e0288ff4e0e3c93ac411cc36c98ae6308acb1931dea66c9454eb35097c186237')
assert set(refs)=={'b_accept','b_exit','b_manifest','b_result','byte','c_accept','c_exit','c_manifest','c_result','c_review','manifest_draft','plan_draft','runtime_draft','schedule','training'}
objs={k:verify(v['path'],v['sha256']) for k,v in refs.items()};c=objs['c_accept'];b=objs['c_review']
assert c['schema']=='SI_U1_INDEPENDENT_C_REAL_ACCEPTANCE_V1' and c['decision']=='ACCEPT_C_FIXED_FINAL_CHECKPOINT_AND_EVALUATION_CONSTRUCTION_ONLY' and type(c['actual_launcher_worker_exit']) is int and c['actual_launcher_worker_exit']==0 and c['process_cleanup_established'] is True
assert b['schema']=='SI_U1_C_REVIEW_BINDING_V1' and b['decision']=='PASS_C_TRAINING_INDEPENDENT_ONLY' and b['acceptance_sha256']==refs['c_accept']['sha256'] and b['final_adapter_sha256']==c['final_adapter_tree_sha256'] and b['training_result_sha256']==c['training_result_sha256']==refs['c_result']['sha256'] and b['supervisor_sha256']==c['supervisor_sha256']==refs['c_exit']['sha256'] and b['manifest_sha256']==refs['c_manifest']['sha256'] and b['source_sha']==c['source_sha']
assert not (E/'stage1').exists() and not (E/'stage1').is_symlink()
write(E/'INPUT_REVIEW.json',{'status':'HASH_BOUND_INPUTS_FOR_REPAIRED_STAGE1_ONLY','independent_review_sha256':'f03e559f931fba3ab5791b12b40f5c6951e73f9ddb2fe4339b914b9a26e37e9b','refs_sha256':sha(R),'refs':{k:v['sha256'] for k,v in refs.items()},'c_review_and_acceptance_consistent':True,'previous_failed_run_receipt_sha256':'5f325412a1113c349fde4e59dd79e2252392740026d3204af3abfdeb943fd720'})
cmd=['/home/lizening/miniconda3/envs/alfworld-self-improve/bin/python3.10','-I','-S','/home/lizening/wt-si-u1-finalizer-bootstrap/bootstrap.py','--stage','one','--refs',str(R),'--refs-sha256',sha(R),'--output-dir',str(E/'stage1')]
env={'PATH':'/usr/bin:/bin','HOME':'/home/lizening','LC_ALL':'C.UTF-8','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1'}
write(E/'ONE_SHOT_CLAIM.json',{'argv':cmd,'env':env,'cwd':'/home/lizening/wt-si-u1-finalizer-bootstrap','created':utc(),'retry_allowed':False,'class':'REPAIRED_NEW_ATTEMPT_NOT_PRIOR_SUCCESS'})
start=utc();t=time.monotonic();error=None;rc=None;pid=None
try:
 with open(E/'stdout.log','xb') as out,open(E/'stderr.log','xb') as err:
  proc=subprocess.Popen(cmd,cwd='/home/lizening/wt-si-u1-finalizer-bootstrap',env=env,stdout=out,stderr=err);pid=proc.pid;rc=proc.wait()
except Exception as ex:error=repr(ex)
write(E/'PROCESS_RECEIPT.json',{'argv':cmd,'env':env,'cwd':'/home/lizening/wt-si-u1-finalizer-bootstrap','start_utc':start,'end_utc':utc(),'duration_seconds':time.monotonic()-t,'pid':pid,'returncode':rc,'launch_error':error,'retry':False,'refs_sha256':sha(R)})
print(json.dumps({'returncode':rc,'launch_error':error,'output_exists':(E/'stage1').exists()}))
if rc!=0:raise SystemExit(1)
