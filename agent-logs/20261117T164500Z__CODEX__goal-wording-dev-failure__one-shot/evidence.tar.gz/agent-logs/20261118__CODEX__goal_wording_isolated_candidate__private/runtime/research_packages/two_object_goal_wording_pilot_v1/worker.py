"""One-pair worker for the fixed goal-wording DEV protocol.

This file is inert on import. A new external supervisor must provide a fresh
output directory, an authenticated budget socket, and an exact private config.
It does not create or grant those resources itself.
"""

import argparse
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import sys


def read_bound(path, digest, *, limit=16 * 1024 * 1024):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if not 0 < before.st_size <= limit:
            raise ValueError("bound file size")
        parts = []
        remaining = before.st_size
        while remaining:
            block = os.read(fd, min(remaining, 65536))
            if not block:
                raise ValueError("short bound file")
            parts.append(block)
            remaining -= len(block)
        after = os.fstat(fd)
        if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
             before.st_ctime_ns) != (after.st_dev, after.st_ino, after.st_size,
                                      after.st_mtime_ns, after.st_ctime_ns)):
            raise ValueError("bound file changed while read")
        data = b"".join(parts)
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError("bound file digest mismatch")
        return data
    finally:
        os.close(fd)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--config-sha256", required=True)
    ap.add_argument("--budget-fd", required=True, type=int)
    args = ap.parse_args()
    config = json.loads(read_bound(args.config, args.config_sha256))
    manifest = json.loads(read_bound(config["manifest_path"], config["manifest_sha256"]))
    if manifest["schema"] != "PARALLEL_TWO_OBJECT_GOAL_WORDING_DEV_V1":
        raise ValueError("protocol manifest schema")
    cases = [row for row in manifest["cases"] if row["case"] == config["case"]]
    if len(cases) != 1 or config["seed"] != manifest["env_seed"]:
        raise ValueError("case or seed binding")
    if config["limits"] != manifest["limits"]:
        raise ValueError("batch limits binding")
    output = Path(config["output"])
    if not output.is_absolute() or not output.is_dir() or list(output.iterdir()):
        raise ValueError("fresh private pair output required")

    legacy = Path(config["legacy_dir"])
    source = Path(config["source_root"])
    if not legacy.is_absolute() or not source.is_absolute():
        raise ValueError("absolute code roots required")
    for item in config["code_files"]:
        read_bound(item["path"], item["sha256"], limit=2 * 1024 * 1024)
    project_root = Path(__file__).resolve().parents[2]
    sys.path[:0] = [str(project_root), str(legacy), str(source / "src")]

    from research_packages.two_object_goal_wording_pilot_v1.stage import run_stage
    from research_packages.two_object_goal_wording_pilot_v1.episode import episode
    from effect_ipc import Journal, EffectOwner, Controller
    from eprime_ports import materialize, verify_materialized, EPrimeEnvironment
    from environment_step import StepEnabledAuthoredEnv
    import source_worker
    from producer_port import ProducerPort
    from production_loader import load_frozen_adapter
    from self_improvement.si_p3.contract import PublicState, projection
    from self_improvement.si_transfer_eval.resource import SharedGPU
    from models.protocol_stability import parse_p2_selection

    runtime = config["runtime"]
    loads = 0

    def load_p0():
        nonlocal loads
        loads += 1
        if loads > 2:
            raise ValueError("pair model load limit")
        receipts = output / ("p0-load-%d" % loads)
        receipts.mkdir(mode=0o700)
        resource = SharedGPU(expected_uuid=runtime["gpu_uuid"],
                             journal_path=receipts / "resource.jsonl",
                             engineering_only=True)
        producer = None
        try:
            producer = load_frozen_adapter(
                arm="A", adapter_path=runtime["adapter_path"],
                adapter_sha256=runtime["adapter_tree_sha256"],
                base_path=runtime["base_path"],
                base_sha256=runtime["base_tree_sha256"], resource=resource,
                packages=runtime["packages"],
                runtime_identity=runtime["runtime_identity"],
                import_receipt_dir=receipts,
            )
            return ProducerPort(producer, resource)
        except BaseException:
            if producer is not None:
                try:
                    producer.close()
                except BaseException:
                    pass
            try:
                resource.close()
            except BaseException:
                pass
            raise

    def parser(raw, actions):
        return parse_p2_selection(raw, actions, reflection_required=False)

    def state_factory(old, after):
        return PublicState(old.task_id, old.family, old.goal, after["observation"],
                           tuple(after["valid_actions"]), after["done"],
                           after["reward"], after["truncated"])

    run_stage(
        output=output, budget_fd=args.budget_fd, case=cases[0],
        inputs=config["inputs"], seed=config["seed"], journal_class=Journal,
        owner_class=EffectOwner, controller_class=Controller,
        materialize=materialize, verify_materialized=verify_materialized,
        environment_class=EPrimeEnvironment, step_wrapper=StepEnabledAuthoredEnv,
        episode=episode, projection=projection, source_worker=source_worker,
        load_p0=load_p0, parser=parser, parse_value=dataclasses.asdict,
        state_factory=state_factory, expected_eos=config["expected_eos"],
        expected_pad=config["expected_pad"],
    )


if __name__ == "__main__":
    main()
