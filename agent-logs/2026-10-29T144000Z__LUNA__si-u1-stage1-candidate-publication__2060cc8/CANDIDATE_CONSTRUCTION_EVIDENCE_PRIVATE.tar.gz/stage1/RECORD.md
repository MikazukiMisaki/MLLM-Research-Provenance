# SI-U1 repaired first-stage candidate construction

Status: CANDIDATE_FOR_INDEPENDENT_REVIEW_ONLY. This is a fresh, separately recorded attempt with repaired exact-reviewed source. The earlier real stage-one invocation returned 1, created no output and remains unchanged at ../2026-10-29T144500Z__SOL__si-u1-stage1-manifest__616f1e4/.

Astra repair independent review SHA256 f03e559f931fba3ab5791b12b40f5c6951e73f9ddb2fe4339b914b9a26e37e9b. Clean builder 3da63f4e3b0150c3ebb681a0d66dd87c22f7c3aa; clean bootstrap 2060cc8a20dfc6dafa3b4053043f6eab67ef7410; clean evaluator 8532275932dabddc498c23a2b6d9a045647542f0. All 15 real metadata references, including authentic B/C acceptance, C binding, training receipts and frozen schedule, matched their input hashes before and after the construction. Reused immutable reference file SHA256 e0288ff4e0e3c93ac411cc36c98ae6308acb1931dea66c9454eb35097c186237.

The sole new process used the frozen Python with -I -S and sanitized environment; actual argv, environment, PID, stdout, stderr and return code are recorded here. Authentic return code 0. No automatic retry. The process produced only a candidate manifest, runtime draft, plan and receipt under stage1/.

Local metadata check verified canonical encodings, output hash links, all 82 represented parent/task/family/seed/game-hash entries against frozen metadata, A/B/C checkpoint lineage metadata, empty module version preservation, and clean source states. The runtime is explicitly NOT_EXECUTION_RELEASE and isolation_proof is null. These are local construction checks, not an independent proof of task isolation or evidence of scientific effect; the review must preserve stated historical-use and layout caveats.

No stage two, preflight, model loading, CUDA, environment, held-out task contents, or scientific evaluation was run. The candidate is handed to Astra for independent represented-identity review. Further protocol/runtime/analysis review remains necessary.
