"""Pure planning and conservative paired summaries for a four-case DEV batch.

This module neither identifies the registered cases nor establishes whether an
episode receipt is authentic. A caller must bind both before setting verified.
"""

from dataclasses import dataclass
from typing import Iterable, Optional, Sequence


ARMS = ("P0", "CANDIDATE")
CASE_COUNT = 4
HORIZON = 50
MAX_EPISODES = 8
MAX_RESETS = 8
MAX_STEPS = 400


@dataclass(frozen=True)
class Slot:
    case_id: str
    arm: str
    sequence: int
    horizon: int = HORIZON


@dataclass(frozen=True)
class EpisodeResult:
    case_id: str
    arm: str
    status: str
    success: Optional[bool]
    verified: bool


def make_plan(case_ids: Sequence[str]) -> tuple[Slot, ...]:
    """Preserve registered order; alternate which arm runs first by case."""
    if isinstance(case_ids, (str, bytes)) or len(case_ids) != CASE_COUNT:
        raise ValueError("exactly four ordered case IDs are required")
    if any(not isinstance(case, str) or not case.strip() or case != case.strip()
           for case in case_ids):
        raise ValueError("case IDs must be nonempty, trimmed strings")
    if len(set(case_ids)) != CASE_COUNT:
        raise ValueError("duplicate case ID")
    slots = []
    for index, case in enumerate(case_ids):
        order = ARMS if index % 2 == 0 else ARMS[::-1]
        for arm in order:
            slots.append(Slot(case, arm, len(slots) + 1))
    return tuple(slots)


def _outcome(row: EpisodeResult) -> str:
    # Terminal outcomes may only be read from a verified completed receipt.
    # In particular, a missing record, error, or partial run is not failure.
    if row.status != "COMPLETED" or row.verified is not True or type(row.success) is not bool:
        return "UNKNOWN"
    return "SUCCESS" if row.success else "FAILURE"


def summarize(case_ids: Sequence[str], results: Iterable[EpisodeResult]) -> dict:
    """Summarize registered slots, with unknown results bounded over all cases.

    Duplicate or unregistered case/arm receipts raise rather than selecting a
    preferred receipt. The caller remains responsible for receipt verification.
    """
    plan = make_plan(case_ids)
    expected = {(slot.case_id, slot.arm) for slot in plan}
    by_key = {}
    for row in results:
        if not isinstance(row, EpisodeResult):
            raise ValueError("results must be EpisodeResult instances")
        key = (row.case_id, row.arm)
        if key not in expected:
            raise ValueError("unregistered case/arm receipt")
        if key in by_key:
            raise ValueError("duplicate case/arm receipt")
        by_key[key] = row

    counts = {arm: {"success": 0, "failure": 0, "unknown": 0,
                    "missing": 0, "unverified_or_incomplete": 0}
              for arm in ARMS}
    pairs = []
    wins = losses = ties = 0
    for case_id in case_ids:
        outcomes = {}
        for arm in ARMS:
            row = by_key.get((case_id, arm))
            outcome = "UNKNOWN" if row is None else _outcome(row)
            outcomes[arm] = outcome
            counts[arm][outcome.lower()] += 1
            if row is None:
                counts[arm]["missing"] += 1
            elif outcome == "UNKNOWN":
                counts[arm]["unverified_or_incomplete"] += 1
        if "UNKNOWN" not in outcomes.values():
            if outcomes["CANDIDATE"] == outcomes["P0"]:
                ties += 1
            elif outcomes["CANDIDATE"] == "SUCCESS":
                wins += 1
            else:
                losses += 1
        pairs.append({"case_id": case_id, **outcomes})

    rates = {}
    for arm in ARMS:
        success, unknown = counts[arm]["success"], counts[arm]["unknown"]
        rates[arm] = {"lower": success / CASE_COUNT,
                      "upper": (success + unknown) / CASE_COUNT}
    return {
        "planned_cases": CASE_COUNT,
        "planned_episodes": MAX_EPISODES,
        "observed_receipts": len(by_key),
        "counts": counts,
        "success_rate_bounds": rates,
        "candidate_minus_p0_bounds": {
            "lower": rates["CANDIDATE"]["lower"] - rates["P0"]["upper"],
            "upper": rates["CANDIDATE"]["upper"] - rates["P0"]["lower"],
        },
        "complete_pairs": wins + losses + ties,
        "candidate_wins": wins,
        "candidate_losses": losses,
        "ties": ties,
        "pairs": pairs,
    }
