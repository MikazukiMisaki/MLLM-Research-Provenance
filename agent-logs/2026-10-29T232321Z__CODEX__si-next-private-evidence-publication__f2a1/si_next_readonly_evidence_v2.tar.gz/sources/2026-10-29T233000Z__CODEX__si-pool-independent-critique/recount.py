import collections,hashlib,json,os
from pathlib import Path
base=Path('/home/lizening/research-notes/agent-logs')
out=Path(__file__).parent
src=base/'2026-10-29T231522Z__CODEX__si-next-data-isolation-readonly__f2a1'
root=Path('/home/lizening/alfworld_data/json_2.1.1')
files={
'registry':base/'2026-10-25T065200Z__LUNA__si-p1-isolation-budget__caae4c/KNOWN_USE_IDENTITIES.json',
'proposal':base/'2026-10-25T084517Z__LUNA__si-p3-isolation-budget-design__si3_7d91/partition_proposal.json',
'expert':Path('/home/lizening/Alfworld-Self-Improvement-Project/artifacts/runtime/sft-policy-bootstrap/sft_expert_dataset_balanced.jsonl'),
'schedule':base/'2026-10-29T113523Z__ASTRA__three-arm-prospective-design__a55d1af9/PILOT82_PROPOSED_SCHEDULE_PRIVATE.json',
'bindings':base/'2026-10-29T120900Z__SOL__si-pilot82-game-byte-isolation/EVAL_BYTE_BINDINGS_PRIVATE.json',
'b':base/'2026-10-29T115700Z__SOL__si-pilot82-dataset-materialization/B_manifest_candidate_PRIVATE.json',
'c':base/'2026-10-29T115700Z__SOL__si-pilot82-dataset-materialization/C_manifest_candidate_PRIVATE.json',
'engineering1':base/'2026-10-29T121500Z__CODEX__si-eval-engineering-task-metadata/ENGINEERING_CANDIDATE_PRIVATE.json',
'engineering2':base/'2026-10-29T132000Z__LUNA__si-eval-remediation-candidate__metadata/ENGINEERING_CANDIDATE_PRIVATE.json',
'summary':src/'TWO_POLICY_SUMMARY.json',
'used_candidates':src/'CANDIDATE_WITHOUT_RESERVATION_METADATA_PRIVATE.json',
'conservative_candidates':src/'CANDIDATE_METADATA_PRIVATE.json'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def rd(k):return json.loads(files[k].read_bytes())
inputsha={k:sha(v) for k,v in files.items()}
reg=rd('registry'); known=set().union(*(set(v) for v in reg['registered_identity_members'].values() if isinstance(v,list)))
prop={r['identity'] for r in rd('proposal')['rows']}
schedule=rd('schedule')['rows'];ev_ids={r['task_id'] for r in schedule};ev_parent={r['parent'] for r in schedule};bind=rd('bindings')
evg={r['game']['sha256'] for r in bind};evt={r['traj_data']['sha256'] for r in bind}
B=set(rd('b')['task_exposures']);C=set(rd('c')['task_exposures'])
eng=[rd('engineering1')['candidate'],rd('engineering2')['candidate']]
ep={r['parent'] for r in eng};ei={r['task_id'] for r in eng};eg={r['game']['sha256'] for r in eng};et={r['traj_data']['sha256'] for r in eng}
xids=set();xg=set();xt=set();n=0
with files['expert'].open('rb') as f:
 for line in f:
  x=json.loads(line);n+=1;xids.add(x['task_id']);xg.add(x['source_game_sha256']);xt.add(x['source_traj_data_sha256'])
F={'look_at_obj_in_light','pick_and_place_simple','pick_clean_then_place_in_recep','pick_cool_then_place_in_recep','pick_heat_then_place_in_recep','pick_two_obj_and_place'}
rows=[]
for split in ('train','valid_train','valid_seen','valid_unseen'):
 for parent in root.joinpath(split).iterdir():
  if not parent.is_dir():continue
  for trial in parent.iterdir():
   if not trial.is_dir():continue
   game=trial/'game.tw-pddl';traj=trial/'traj_data.json'
   rows.append({'split':split,'task':parent.name+'/'+trial.name,'parent':parent.name,'family':parent.name.split('-')[0],'game':sha(game) if game.is_file() else None,'traj':sha(traj) if traj.is_file() else None,'game_symlink':game.is_symlink(),'traj_symlink':traj.is_symlink()})
summary=rd('summary');results={}
for pol,with_res,key in [('used_and_excluded_only',False,'used_candidates'),('also_exclude_prior_proposal',True,'conservative_candidates')]:
 ids=known|xids|ev_ids|(prop if with_res else set());parents={s.split('/')[0] for s in ids}|ev_parent|B|C
 old=[r for r in rows if r['task'] in ids or r['parent'] in parents]
 oldg=xg|evg|{r['game'] for r in old if r['game']};oldt=xt|evt|{r['traj'] for r in old if r['traj']}
 selected=[r for r in rows if r['family'] in F and r['game'] and r['traj'] and r['parent'] not in parents and r['game'] not in oldg and r['traj'] not in oldt]
 final=[r for r in selected if r['parent'] not in ep and r['task'] not in ei and r['game'] not in eg and r['traj'] not in et]
 # Additional conservative check: every installed sibling of either engineering parent as a protected byte source.
 engsiblings=[r for r in rows if r['parent'] in ep]
 egall={r['game'] for r in engsiblings if r['game']}|eg;etall={r['traj'] for r in engsiblings if r['traj']}|et
 sibling_aliases=[r for r in final if r['game'] in egall or r['traj'] in etall]
 reference=rd(key)['rows'];reference_final=[r for r in reference if r['parent'] not in ep and r['task'] not in ei and r['game'] not in eg and r['traj'] not in et]
 def idskey(rr):return {(r['split'],r['task'],r['game'],r['traj']) for r in rr}
 # candidate rows at different parents may have colliding byte identities, undermining simply taking one per parent.
 collisions={}
 for field in ('game','traj'):
  groups=collections.defaultdict(set)
  for r in final:groups[r[field]].add(r['parent'])
  collisions[field]=sum(len(v)>1 for v in groups.values())
 splitcounts={s:{'trials':len(rr),'parents':len({r['parent'] for r in rr}),'game':len({r['game'] for r in rr}),'traj':len({r['traj'] for r in rr})} for s in ('train','valid_train','valid_seen','valid_unseen') for rr in [[r for r in final if r['split']==s]]}
 byset={s:{r['parent'] for r in final if r['split']==s} for s in ('train','valid_train','valid_seen','valid_unseen')}
 results[pol]={'reproduced_reference_exact_set':idskey(final)==idskey(reference_final),'splits':splitcounts,'parents_union':len({r['parent'] for r in final}),'train_valid_train_overlap':len(byset['train']&byset['valid_train']),'cross_parent_candidate_hash_collision_groups':collisions,'additional_parent_sibling_byte_alias_candidates':len(sibling_aliases),'engineering_parent_installed_trials':len(engsiblings),'summary_counts_match':all(splitcounts[s]['trials']==summary['two_separate_policies'][pol]['splits'][s]['trials'] and splitcounts[s]['parents']==summary['two_separate_policies'][pol]['splits'][s]['parents'] for s in splitcounts)}
assert inputsha=={k:sha(v) for k,v in files.items()}
report={'independent_scope':'No candidate file contents parsed, only raw SHA; historical expert metadata parsed solely for identifiers and already recorded hashes; no model, CUDA, ALFWorld or new outcomes.', 'input_sha256':inputsha,'inventory':{'expert_rows':n,'expert_ids':len(xids),'expert_parents':len({s.split('/')[0] for s in xids}),'schedule_ids':len(ev_ids),'schedule_parents':len(ev_parent),'B_parents':len(B),'C_parents':len(C),'BC_overlap':len(B&C),'engineering_distinct_tasks':len(ei),'engineering_distinct_parents':len(ep),'registry_identity_count':len(known),'proposal_ids':len(prop),'filesystem_trial_dirs':len(rows),'game_missing':sum(r['game'] is None for r in rows),'traj_missing':sum(r['traj'] is None for r in rows),'game_or_traj_symlinks':sum(r['game_symlink'] or r['traj_symlink'] for r in rows)},'results':results,'limitations':['Observed candidate inventory is an upper bound for admissible truly isolated units under the checked metadata-based scope, because history could be incomplete or inexact, or physical artifacts missing; it is not a guaranteed minimum count of scientifically valid tasks.','Policy excluding all prior proposal parents is more restrictive than excluding only known/excluded identities; old proposal membership is not proof of actual execution.','Unidentified semantic or scenario-level prior exposure, exposure history omissions, and unavailable historical artifacts cannot be ruled out; byte uniqueness cannot prove unseen layout or random sampling.','Directory aliases and cross-split identities are deduplicated by operational parent; process-level isolation and ALFWorld behavior are not checked.']}
(out/'INDEPENDENT_RECOUNT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'inventory':report['inventory'],'results':results},sort_keys=True))
