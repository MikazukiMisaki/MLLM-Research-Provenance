# SI-U1 follow-up: read-only resource and budget feasibility

No model, CUDA initialization, environment, training, inference or new scientific execution was invoked. This artifact is an estimate, not a preflight or authorization.

## Snapshot and limitations

Read-only NVIDIA management and filesystem observations are in OBSERVATION.json. The GPU is shared; no visible compute PID is not proof of exclusivity and cannot reserve future resources. Host processes may be invisible in this container. Historical evaluation engineering left 8,519,680 allocated / 20,971,520 reserved worker allocator bytes at model closure; eventual process cleanup was verified. Do not equate device-wide memory with a worker allocation or treat a prior success as guaranteed fit for seven sequential model identities.

## Budget

BUDGET_EVIDENCE.json provides auditable old record hashes, historical completed cost, exact arithmetic and examples. N is the number of new distinct tasks, not established available or statistically adequate. Seven trajectories per task (A once and B/C three seeds) yield at most 350N model generations and 357N environment operations including 7N resets; a complete reset for all requires 7N resets. E.g. N=82 yields 28,700 generations / 29,274 operations, N=164 yields 57,400 / 58,548, N=328 yields 114,800 / 117,096. Other operation types are separate.

With the old training dose and 5400 second per-training ceiling, six training runs imply 7,488 microbatches, 468 updates, 37,440 supervised tokens and 32,400 supervised device seconds upper cap. If exactly the two old B/C seeds are pre-specified as eligible and reuse survives independent review, four newly trained runs add 4,992 microbatches, 312 updates, 24,960 supervised tokens and 21,600 seconds cap; old B/C cost remains in cumulative physical cost. Neither scenario permits cherry-picking seeds.

Seven times the old 14,400 seconds per evaluation arm gives 100,800 seconds; old per-arm cap might fail to accommodate larger N. These caps and support for seven arms are not frozen or granted for any new protocol. Prior real B/C training 883.224/916.831 sec and 82-by-three evaluation 4263.281 sec are historical observations, not future lower bounds or forecasts. Engineering 455.856 sec is additional and must not be folded into science cost or forgotten.

## Stop/prepare

Proceed only after separate identity and isolated-task/parent/byte/historical contact audits, multi-seed design and joint power/precision review, immutable budget ledger with separate science/engineering and all prior spent/open operations, fixed distinct output identities, validated seven-arm implementation and independent exact-SHA review. Before each load verify shared GPU free space, fixed identity, disk for checkpoints and evidence with realistic margin; recheck at runtime. Stop on resource guard breach, OOM/retry, failed or partial unit, unknown ownership or drift, clock/budget overrun, missing record or misbinding; retain raw evidence and physical cost, no automatic retry. Avoid changing baseline or old evidence.
