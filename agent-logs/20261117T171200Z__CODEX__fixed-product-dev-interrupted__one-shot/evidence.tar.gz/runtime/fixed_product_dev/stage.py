"""Pair-stage adapter for the existing authored-task episode ports.

This is a composition function, not a supervisor or CLI. An external batch
owner must enforce cumulative limits, process/device admission and identities.
"""

from pathlib import Path

from .pair import run_pair


PAIR_CAPS = {"materialize": 1, "env_construct": 2, "env_init": 2,
             "reset": 2, "model_load": 2, "generation": 100, "step": 100}


def run_stage(*, output, budget_fd, case, inputs, seed, journal_class,
              owner_class, controller_class, materialize, verify_materialized,
              environment_class, step_wrapper, episode, projection,
              source_worker, load_producer, parser, parse_value, state_factory,
              expected_eos, expected_pad):
    """Use existing ports for one pair, with a mandatory external budget owner."""
    if set(inputs) != {"game", "routing", "config"}:
        raise ValueError("exact task inputs required")
    if {k: v["sha256"] for k, v in inputs.items()} != case["input_sha256"]:
        raise ValueError("case input hash mismatch")
    if type(seed) is not int or seed != case["seed"]:
        raise ValueError("case seed mismatch")
    order = tuple(case["order"])
    if order not in (("P0", "CANDIDATE"), ("CANDIDATE", "P0")):
        raise ValueError("case arm order mismatch")
    output = Path(output)
    if not output.is_absolute() or not output.is_dir() or any(output.iterdir()):
        raise ValueError("fresh pair output required")
    journal = journal_class(output / "worker_events.jsonl", 64 * 1024 * 1024)
    owner = owner_class(budget_fd, journal, PAIR_CAPS)
    controller = controller_class(owner)
    materialized = None
    post_verified = False
    finished = False
    try:
        journal.emit("fixed_product_pair_started", {
            "case": case["case"], "order": list(order), "seed": seed,
            "scope": "EXPOSED_AUTHORED_DEV", "horizon": 50,
        })
        game, config, data_root = controller.effect(
            "materialize", lambda: materialize(output, inputs, journal.emit, family="two"),
            lambda values: {"game": str(values[0]), "config": str(values[1]),
                            "data_root": str(values[2])})
        materialized = (game, config, data_root)
        verify_materialized(game, config, data_root, inputs, journal.emit, "pre")

        class BoundEnvironment:
            def __init__(self):
                self.inner = step_wrapper(environment_class(
                    game, config, data_root, seed, family="two", case_id=case["case"]))

            def initialize(self):
                return self.inner.initialize()

            def reset(self):
                result = self.inner.reset()
                if (type(result) is not tuple or len(result) != 3
                        or getattr(result[0], "goal", None) != case["public_goal"]
                        or getattr(result[0], "family", None) != "pick_two_obj_and_place"):
                    raise ValueError("public goal or family mismatch")
                return result

            def step(self, action):
                return self.inner.step(action)

            def close(self):
                return self.inner.close()

        pair = run_pair(
            episode=episode, projection=projection, arm_order=order,
            load_producer=load_producer, controller=controller,
            env_factory=BoundEnvironment, source_worker=source_worker,
            parser=parser, parse_value=parse_value, state_factory=state_factory,
            expected_game=str(game), expected_eos=expected_eos, expected_pad=expected_pad)
        verify_materialized(game, config, data_root, inputs, journal.emit, "post")
        post_verified = True
        journal.emit("fixed_product_pair_result", pair)
        owner.finish("COMPLETED")
        finished = True
        return pair
    except BaseException as error:
        if materialized is not None and not post_verified:
            try:
                verify_materialized(*materialized, inputs, journal.emit, "post")
            except BaseException as verification_error:
                try:
                    journal.emit("input_post_verification_failed", {
                        "type": type(verification_error).__name__})
                except BaseException:
                    pass
        try:
            journal.emit("fixed_product_pair_stopped", {
                "type": type(error).__name__, "effects": "UNKNOWN_AS_NEEDED"})
        except BaseException:
            pass
        if not finished:
            try:
                owner.finish("STOPPED")
            except BaseException:
                pass
        raise
    finally:
        try:
            owner.close()
        finally:
            journal.close()
